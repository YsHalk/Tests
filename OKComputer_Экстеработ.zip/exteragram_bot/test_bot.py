#!/usr/bin/env python3
"""
Простые тесты для бота
"""

import asyncio
import sys
import os
from pathlib import Path

# Добавляем путь к проекту
sys.path.insert(0, str(Path(__file__).parent))

from database import Database


async def test_database():
    """Тестирование базы данных"""
    print("🧪 Тестирование базы данных...")
    
    db = Database()
    await db.initialize()
    
    # Тест добавления пользователя
    print("  ✓ Инициализация БД")
    
    # Тест добавления пользователя
    await db.add_user(123456789, "testuser", "Test User")
    user = await db.get_user(123456789)
    assert user is not None
    assert user['display_name'] == "Test User"
    print("  ✓ Добавление и получение пользователя")
    
    # Тест обновления пользователя
    await db.update_user(123456789, display_name="Updated Name")
    user = await db.get_user(123456789)
    assert user['display_name'] == "Updated Name"
    print("  ✓ Обновление пользователя")
    
    print("✅ База данных работает корректно\n")


async def test_search():
    """Тестирование поиска"""
    print("🧪 Тестирование поиска...")
    
    db = Database()
    await db.initialize()
    
    # Добавляем тестового пользователя
    await db.add_user(1, "author", "Plugin Author")
    
    # Добавляем тестовый плагин
    plugin_id = await db.add_plugin(
        user_id=1,
        file_id="test_file_id",
        file_name="test.py",
        name="Test Plugin",
        description="This is a test plugin",
        category="tools",
        status="completed",
        tags="test plugin tools",
        photo_file_id=None
    )
    
    # Одобряем плагин
    await db.update_plugin(plugin_id, approved=True)
    
    # Тест поиска
    results = await db.search_plugins("test", limit=5)
    assert len(results) > 0
    print("  ✓ Поиск работает")
    
    # Тест популярных плагинов
    popular = await db.get_popular_plugins(limit=5)
    assert len(popular) > 0
    print("  ✓ Получение популярных плагинов")
    
    print("✅ Поиск работает корректно\n")


async def test_subscriptions():
    """Тестирование подписок"""
    print("🧪 Тестирование подписок...")
    
    db = Database()
    await db.initialize()
    
    # Добавляем пользователей
    await db.add_user(1, "author1", "Author One")
    await db.add_user(2, "subscriber", "Subscriber User")
    
    # Добавляем плагин
    plugin_id = await db.add_plugin(
        user_id=1,
        file_id="test_file_id",
        file_name="test.py",
        name="Test Plugin",
        description="Test",
        category="tools",
        status="completed"
    )
    
    # Тест подписки на автора
    await db.add_subscription(2, target_user_id=1)
    is_subscribed = await db.is_subscribed(2, target_user_id=1)
    assert is_subscribed
    print("  ✓ Подписка на автора")
    
    # Тест подписки на плагин
    await db.add_subscription(2, plugin_id=plugin_id)
    is_subscribed = await db.is_subscribed(2, plugin_id=plugin_id)
    assert is_subscribed
    print("  ✓ Подписка на плагин")
    
    # Тест получения подписчиков
    subscribers = await db.get_subscribers(target_user_id=1)
    assert 2 in subscribers
    print("  ✓ Получение подписчиков")
    
    # Тест отписки
    await db.remove_subscription(2, target_user_id=1)
    is_subscribed = await db.is_subscribed(2, target_user_id=1)
    assert not is_subscribed
    print("  ✓ Отписка")
    
    print("✅ Подписки работают корректно\n")


async def test_ratings():
    """Тестирование оценок"""
    print("🧪 Тестирование оценок...")
    
    db = Database()
    await db.initialize()
    
    # Добавляем пользователей
    await db.add_user(1, "author", "Author")
    await db.add_user(2, "rater1", "Rater One")
    await db.add_user(3, "rater2", "Rater Two")
    
    # Добавляем плагин
    plugin_id = await db.add_plugin(
        user_id=1,
        file_id="test_file_id",
        file_name="test.py",
        name="Test Plugin",
        description="Test",
        category="tools",
        status="completed"
    )
    
    # Ставим оценки
    await db.add_rating(2, plugin_id, 5)
    await db.add_rating(3, plugin_id, 4)
    
    # Получаем плагин
    plugin = await db.get_plugin(plugin_id)
    assert plugin['rating'] == 4.5
    assert plugin['rating_count'] == 2
    print("  ✓ Добавление оценок")
    print("  ✓ Расчет среднего рейтинга")
    
    # Обновляем оценку
    await db.add_rating(2, plugin_id, 3)
    plugin = await db.get_plugin(plugin_id)
    assert plugin['rating'] == 3.5
    print("  ✓ Обновление оценки")
    
    print("✅ Оценки работают корректно\n")


async def run_all_tests():
    """Запуск всех тестов"""
    print("🚀 Запуск тестов бота\n")
    
    try:
        await test_database()
        await test_search()
        await test_subscriptions()
        await test_ratings()
        
        print("🎉 Все тесты пройдены успешно!")
        return True
        
    except Exception as e:
        print(f"❌ Тесты провалены: {e}")
        return False


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)
