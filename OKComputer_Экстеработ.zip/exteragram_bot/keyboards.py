from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from config import CATEGORIES, STATUSES

# ===== REPLY KEYBOARDS (Главное меню) =====

def get_main_menu() -> ReplyKeyboardMarkup:
    """Главное меню пользователя"""
    kb = ReplyKeyboardBuilder()
    kb.button(text="🔍 Найти")
    kb.button(text="📤 Загрузить")
    kb.button(text="🔥 Популярное")
    kb.button(text="📂 Категории")
    kb.button(text="⭐ Подписки")
    kb.button(text="👤 Мой профиль")
    kb.adjust(2, 2, 2)  # 2 кнопки в ряд
    return kb.as_markup(resize_keyboard=True)


def get_cancel_menu() -> ReplyKeyboardMarkup:
    """Меню отмены действия"""
    kb = ReplyKeyboardBuilder()
    kb.button(text="❌ Отмена")
    return kb.as_markup(resize_keyboard=True)


def get_back_menu() -> ReplyKeyboardMarkup:
    """Меню с кнопкой Назад"""
    kb = ReplyKeyboardBuilder()
    kb.button(text="⬅️ Назад")
    return kb.as_markup(resize_keyboard=True)


# ===== INLINE KEYBOARDS =====

# --- Поиск и результаты ---
def get_search_results_plugins(plugin_ids: list) -> InlineKeyboardMarkup:
    """Клавиатура с результатами поиска"""
    kb = InlineKeyboardBuilder()
    for plugin_id, name in plugin_ids:
        kb.button(text=name, callback_data=f"plugin_{plugin_id}")
    kb.adjust(1)
    return kb.as_markup()


# --- Страница плагина ---
def get_plugin_page_keyboard(
    plugin_id: int,
    user_id: int,
    plugin_user_id: int,
    is_subscribed: bool = False,
    is_owner: bool = False,
    is_admin: bool = False
) -> InlineKeyboardMarkup:
    """Клавиатура для страницы плагина"""
    kb = InlineKeyboardBuilder()
    
    # Первая строка: Скачать и Подписаться/Отписаться
    kb.button(text="⬇️ Скачать", callback_data=f"download_{plugin_id}")
    sub_text = "❌ Отписаться" if is_subscribed else "✅ Подписаться"
    kb.button(text=sub_text, callback_data=f"toggle_sub_{plugin_id}")
    
    # Вторая строка: Автор
    kb.button(text="👤 Автор", callback_data=f"author_{plugin_user_id}")
    
    # Третья строка: Отзывы и Оценить
    kb.button(text="💬 Отзывы", callback_data=f"reviews_{plugin_id}")
    kb.button(text="⭐ Оценить", callback_data=f"rate_{plugin_id}")
    
    # Четвертая строка: Управление (для владельца и админов)
    if is_owner or is_admin:
        kb.button(text="⚙️ Управление", callback_data=f"manage_{plugin_id}")
    
    # Пятая строка: Назад
    kb.button(text="⬅️ Назад", callback_data="back_to_search")
    
    kb.adjust(2, 1, 2, 1, 1)
    return kb.as_markup()


# --- Управление плагином ---
def get_manage_plugin_keyboard(plugin_id: int, is_archived: bool = False) -> InlineKeyboardMarkup:
    """Клавиатура управления плагином"""
    kb = InlineKeyboardBuilder()
    
    if is_archived:
        kb.button(text="📥 Вернуть из архива", callback_data=f"unarchive_{plugin_id}")
    else:
        kb.button(text="📦 В архив", callback_data=f"archive_{plugin_id}")
    
    kb.button(text="🗑️ Удалить", callback_data=f"delete_{plugin_id}")
    kb.button(text="🔄 Обновить", callback_data=f"update_{plugin_id}")
    kb.button(text="⬅️ Вернуться", callback_data=f"plugin_{plugin_id}")
    kb.button(text="🏠 Меню", callback_data="main_menu")
    
    kb.adjust(1, 2, 1, 1)
    return kb.as_markup()


# --- Категории ---
def get_categories_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура выбора категории"""
    kb = InlineKeyboardBuilder()
    for key, name in CATEGORIES:
        kb.button(text=name, callback_data=f"category_{key}")
    kb.button(text="⬅️ Назад", callback_data="main_menu")
    kb.adjust(1)
    return kb.as_markup()


# --- Статусы плагина ---
def get_statuses_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура выбора статуса плагина"""
    kb = InlineKeyboardBuilder()
    for key, name in STATUSES.items():
        if key != 'archived':  # Архив только через управление
            kb.button(text=name, callback_data=f"status_{key}")
    kb.button(text="⬅️ Назад", callback_data="back_upload")
    kb.adjust(1)
    return kb.as_markup()


# --- Оценка ---
def get_rating_keyboard(plugin_id: int) -> InlineKeyboardMarkup:
    """Клавиатура оценки плагина"""
    kb = InlineKeyboardBuilder()
    for i in range(1, 6):
        kb.button(text=f"{'⭐' * i}", callback_data=f"rate_set_{plugin_id}_{i}")
    kb.button(text="⬅️ Отмена", callback_data=f"plugin_{plugin_id}")
    kb.adjust(1)
    return kb.as_markup()


# --- Профиль автора ---
def get_author_profile_keyboard(
    author_user_id: int,
    is_subscribed: bool = False,
    has_plugins: bool = True
) -> InlineKeyboardMarkup:
    """Клавиатура профиля автора"""
    kb = InlineKeyboardBuilder()
    
    sub_text = "❌ Отписаться" if is_subscribed else "✅ Подписаться на автора"
    kb.button(text=sub_text, callback_data=f"sub_author_{author_user_id}")
    
    if has_plugins:
        kb.button(text="📦 Плагины автора", callback_data=f"author_plugins_{author_user_id}")
    
    kb.button(text="👤 Управление страницей", callback_data=f"author_manage_{author_user_id}")
    kb.button(text="🏠 Меню", callback_data="main_menu")
    
    kb.adjust(1, 1, 1)
    return kb.as_markup()


# --- Мой профиль ---
def get_my_profile_keyboard(is_author: bool = False) -> InlineKeyboardMarkup:
    """Клавиатура моего профиля"""
    kb = InlineKeyboardBuilder()
    
    kb.button(text="✉️ Отправить сообщение подписчикам", callback_data="broadcast_to_subs")
    kb.button(text="✏️ Изменить профиль", callback_data="edit_profile")
    kb.button(text="🖼️ Баннер", callback_data="edit_banner")
    
    if is_author:
        kb.button(text="📦 Мои плагины", callback_data="my_plugins")
    
    kb.button(text="⭐ Мои подписки", callback_data="my_subscriptions")
    kb.button(text="🏠 Меню", callback_data="main_menu")
    
    kb.adjust(1, 2, 1, 1)
    return kb.as_markup()


# --- Редактирование профиля ---
def get_edit_profile_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура редактирования профиля"""
    kb = InlineKeyboardBuilder()
    kb.button(text="📝 Никнейм", callback_data="edit_nickname")
    kb.button(text="🔗 Юзернейм", callback_data="edit_username")
    kb.button(text="⬅️ Назад", callback_data="my_profile")
    kb.adjust(2, 1)
    return kb.as_markup()


# --- Подписки ---
def get_subscriptions_list(subscriptions: list) -> InlineKeyboardMarkup:
    """Клавиатура списка подписок"""
    kb = InlineKeyboardBuilder()
    for sub_type, sub_id, name in subscriptions:
        if sub_type == 'author':
            kb.button(text=f"👤 {name}", callback_data=f"author_{sub_id}")
        else:  # plugin
            kb.button(text=f"📦 {name}", callback_data=f"plugin_{sub_id}")
    kb.button(text="⬅️ Назад", callback_data="my_profile")
    kb.adjust(1)
    return kb.as_markup()


# --- Загрузка плагина (шаги) ---
def get_upload_continue_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура продолжения загрузки"""
    kb = InlineKeyboardBuilder()
    kb.button(text="➡️ Продолжить", callback_data="upload_continue")
    kb.button(text="🔄 Заменить файл", callback_data="upload_replace_file")
    kb.button(text="❌ Отмена", callback_data="main_menu")
    kb.adjust(1)
    return kb.as_markup()


def get_upload_confirm_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура подтверждения загрузки"""
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Все верно", callback_data="upload_confirm")
    kb.button(text="✏️ Изменить", callback_data="upload_edit")
    kb.button(text="❌ Отмена", callback_data="main_menu")
    kb.adjust(1, 2)
    return kb.as_markup()


# --- Администрирование ---
def get_moderation_keyboard(request_id: int) -> InlineKeyboardMarkup:
    """Клавиатура модерации заявки"""
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Одобрить", callback_data=f"approve_{request_id}")
    kb.button(text="✏️ Изменить", callback_data=f"modify_{request_id}")
    kb.button(text="❌ Отклонить", callback_data=f"reject_{request_id}")
    kb.adjust(1, 2)
    return kb.as_markup()


def get_request_decision_keyboard(request_id: int) -> InlineKeyboardMarkup:
    """Клавиатура решения пользователя по изменениям"""
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Принять изменения", callback_data=f"accept_changes_{request_id}")
    kb.button(text="❌ Отклонить", callback_data=f"decline_changes_{request_id}")
    kb.button(text="💬 Связаться с поддержкой", callback_data="support")
    kb.adjust(1, 2)
    return kb.as_markup()


# --- Навигация ---
def get_pagination_keyboard(current_page: int, total_pages: int, base_callback: str) -> InlineKeyboardMarkup:
    """Клавиатура пагинации"""
    kb = InlineKeyboardBuilder()
    
    if current_page > 1:
        kb.button(text="⬅️ Предыдущая", callback_data=f"{base_callback}_page_{current_page - 1}")
    
    kb.button(text=f"{current_page}/{total_pages}", callback_data="noop")
    
    if current_page < total_pages:
        kb.button(text="Следующая ➡️", callback_data=f"{base_callback}_page_{current_page + 1}")
    
    kb.button(text="🏠 Меню", callback_data="main_menu")
    kb.adjust(3, 1)
    return kb.as_markup()


# --- Простые клавиатуры для навигации ---
BACK_TO_MENU_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🏠 Меню", callback_data="main_menu")]
])

BACK_TO_PLUGIN_KB = lambda plugin_id: InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="⬅️ К плагину", callback_data=f"plugin_{plugin_id}")]
])

CONFIRM_CANCEL_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="✅ Подтвердить", callback_data="confirm")],
    [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel")]
])
