from aiogram import Router, F
from aiogram.types import CallbackQuery

from database import Database
import keyboards as kb

router = Router()
db = Database()


@router.callback_query(F.data.startswith("sub_author_"))
async def subscriptions_toggle_author(callback: CallbackQuery):
    """Переключение подписки на автора"""
    try:
        author_user_id = int(callback.data.replace("sub_author_", ""))
    except ValueError:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    user_id = callback.from_user.id
    
    if author_user_id == user_id:
        await callback.answer("Нельзя подписаться на себя.", show_alert=True)
        return
    
    author = await db.get_user(author_user_id)
    if not author:
        await callback.answer("Пользователь не найден.", show_alert=True)
        return
    
    is_subscribed = await db.is_subscribed(user_id, target_user_id=author_user_id)
    
    if is_subscribed:
        await db.remove_subscription(user_id, target_user_id=author_user_id)
        await callback.answer(f"Вы отписались от {author['display_name']}")
    else:
        await db.add_subscription(user_id, target_user_id=author_user_id)
        await callback.answer(f"Вы подписались на {author['display_name']}!")
    
    # Обновляем клавиатуру
    author_plugins = await db.get_user_plugins(author_user_id, include_archived=False)
    has_plugins = len(author_plugins) > 0
    keyboard = kb.get_author_profile_keyboard(author_user_id, not is_subscribed, has_plugins)
    
    await callback.message.edit_reply_markup(reply_markup=keyboard)


@router.callback_query(F.data.startswith("toggle_sub_"))
async def subscriptions_toggle_plugin(callback: CallbackQuery):
    """Переключение подписки на плагин"""
    try:
        plugin_id = int(callback.data.replace("toggle_sub_", ""))
    except ValueError:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("Плагин не найден.", show_alert=True)
        return
    
    is_subscribed = await db.is_subscribed(user_id, plugin_id=plugin_id)
    
    if is_subscribed:
        await db.remove_subscription(user_id, plugin_id=plugin_id)
        await callback.answer("Вы отписались от плагина.")
    else:
        await db.add_subscription(user_id, plugin_id=plugin_id)
        await callback.answer("Вы подписались на плагин!")
    
    # Обновляем клавиатуру
    is_owner = plugin['user_id'] == user_id
    from config import is_admin
    is_admin = is_admin(user_id)
    keyboard = kb.get_plugin_page_keyboard(
        plugin_id, user_id, plugin['user_id'],
        not is_subscribed, is_owner, is_admin
    )
    
    await callback.message.edit_reply_markup(reply_markup=keyboard)
