from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
import asyncio

from database import Database
from keyboards import get_main_menu, BACK_TO_MENU_KB
from states import EditProfileStates, PluginUpdateStates, BroadcastStates
import keyboards as kb

router = Router()
db = Database()


@router.callback_query(F.data == "my_profile")
async def profile_show(callback: CallbackQuery):
    """Показ своего профиля"""
    user_id = callback.from_user.id
    user = await db.get_user(user_id)
    stats = await db.get_user_stats(user_id)
    
    is_author = stats['plugin_count'] > 0
    
    # Формируем текст профиля
    text = f"👤 <b>Ваш профиль:</b>\n\n"
    text += f"📝 <b>Никнейм:</b> {user['display_name']}\n"
    
    if user.get('username'):
        text += f"🔗 <b>Юзернейм:</b> @{user['username']}\n"
    
    text += f"\n📊 <b>Статистика:</b>\n"
    text += f"👥 Подписчиков: {stats['subscriber_count']}\n"
    
    if is_author:
        text += f"\n📦 <b>Ваши плагины:</b>\n"
        text += f"   Всего: {stats['plugin_count']}\n"
        text += f"   ⬇️ Скачиваний: {stats['total_downloads']}\n"
        text += f"   👁 Просмотров: {stats['total_views']}\n"
        text += f"   ⭐ Средний рейтинг: {stats['avg_rating']:.1f}\n"
    
    keyboard = kb.get_my_profile_keyboard(is_author)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data == "my_plugins")
async def profile_my_plugins(callback: CallbackQuery):
    """Мои плагины"""
    user_id = callback.from_user.id
    
    # Показываем включая архивные
    plugins = await db.get_user_plugins(user_id, include_archived=True)
    
    if not plugins:
        await callback.answer("У вас еще нет плагинов.", show_alert=True)
        return
    
    text = "📦 <b>Ваши плагины:</b>\n\n"
    
    active_plugins = [p for p in plugins if not p['archived']]
    archived_plugins = [p for p in plugins if p['archived']]
    
    if active_plugins:
        text += "📋 <b>Активные:</b>\n"
        for plugin in active_plugins:
            status_emoji = {"development": "🔧", "updates": "🔄", "completed": "✅"}.get(plugin['status'], "")
            approved = "✅" if plugin['approved'] else "⏳"
            text += f"• {approved} <b>{plugin['name']}</b> {status_emoji}\n"
            text += f"  ⬇️ {plugin['downloads']} | 👁 {plugin['views']}\n\n"
    
    if archived_plugins:
        text += "📦 <b>В архиве:</b>\n"
        for plugin in archived_plugins:
            text += f"• <b>{plugin['name']}</b>\n"
            text += f"  ⬇️ {plugin['downloads']} | 👁 {plugin['views']}\n\n"
    
    # Формируем клавиатуру
    kb = InlineKeyboardBuilder()
    
    for plugin in plugins:
        status = "📦" if plugin['archived'] else "📋"
        kb.button(text=f"{status} {plugin['name']}", callback_data=f"plugin_{plugin['plugin_id']}")
    
    kb.button(text="⬅️ Назад", callback_data="my_profile")
    kb.adjust(1)
    
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data == "my_subscriptions")
async def profile_my_subscriptions(callback: CallbackQuery):
    """Мои подписки"""
    user_id = callback.from_user.id
    
    # Получаем подписки
    author_subs = await db.get_user_subscriptions_on_authors(user_id)
    plugin_subs = await db.get_user_subscriptions_on_plugins(user_id)
    
    if not author_subs and not plugin_subs:
        await callback.answer("У вас нет подписок.", show_alert=True)
        return
    
    text = "⭐ <b>Ваши подписки:</b>\n\n"
    
    if author_subs:
        text += "👤 <b>Авторы:</b>\n"
        for author in author_subs:
            text += f"• {author['display_name']}"
            if author.get('username'):
                text += f" (@{author['username']})"
            text += "\n"
        text += "\n"
    
    if plugin_subs:
        text += "📦 <b>Плагины:</b>\n"
        for plugin in plugin_subs:
            text += f"• {plugin['name']}\n"
    
    # Клавиатура
    subscriptions = []
    for author in author_subs:
        subscriptions.append(('author', author['user_id'], author['display_name']))
    for plugin in plugin_subs:
        subscriptions.append(('plugin', plugin['plugin_id'], plugin['name']))
    
    keyboard = kb.get_subscriptions_list(subscriptions)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("manage_"))
async def profile_manage_plugin(callback: CallbackQuery):
    """Управление плагином"""
    try:
        plugin_id = int(callback.data.replace("manage_", ""))
    except ValueError:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("Плагин не найден.", show_alert=True)
        return
    
    if plugin['user_id'] != user_id:
        await callback.answer("Вы не можете управлять этим плагином.", show_alert=True)
        return
    
    keyboard = kb.get_manage_plugin_keyboard(plugin_id, plugin['archived'])
    
    text = f"⚙️ <b>Управление плагином:</b>\n\n" f"📦 <b>{plugin['name']}</b>\n\n" f"Выберите действие:"
    
    await callback.message.answer(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("archive_"))
async def profile_archive_plugin(callback: CallbackQuery):
    """Архивирование плагина"""
    try:
        plugin_id = int(callback.data.replace("archive_", ""))
    except ValueError:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin or plugin['user_id'] != user_id:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    await db.update_plugin(plugin_id, archived=True)
    await callback.answer(f"Плагин '{plugin['name']}' отправлен в архив.")
    
    # Обновляем клавиатуру
    keyboard = kb.get_manage_plugin_keyboard(plugin_id, True)
    await callback.message.edit_reply_markup(reply_markup=keyboard)


@router.callback_query(F.data.startswith("unarchive_"))
async def profile_unarchive_plugin(callback: CallbackQuery):
    """Возврат плагина из архива"""
    try:
        plugin_id = int(callback.data.replace("unarchive_", ""))
    except ValueError:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin or plugin['user_id'] != user_id:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    await db.update_plugin(plugin_id, archived=False)
    await callback.answer(f"Плагин '{plugin['name']}' возвращен из архива.")
    
    # Обновляем клавиатуру
    keyboard = kb.get_manage_plugin_keyboard(plugin_id, False)
    await callback.message.edit_reply_markup(reply_markup=keyboard)


@router.callback_query(F.data.startswith("delete_"))
async def profile_delete_plugin(callback: CallbackQuery):
    """Удаление плагина"""
    await callback.answer("Функция удаления в разработке.", show_alert=True)


@router.callback_query(F.data.startswith("update_"))
async def profile_update_plugin(callback: CallbackQuery, state: FSMContext):
    """Обновление плагина"""
    try:
        plugin_id = int(callback.data.replace("update_", ""))
    except ValueError:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin or plugin['user_id'] != user_id:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    await state.set_state(PluginUpdateStates.waiting_file)
    await state.update_data(update_plugin_id=plugin_id)
    
    await callback.message.answer(
        f"🔄 <b>Обновление плагина:</b> {plugin['name']}\n\n"
        "Отправьте новый файл плагина:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@router.message(PluginUpdateStates.waiting_file)
async def profile_update_receive_file(message: Message, state: FSMContext):
    """Получение нового файла плагина"""
    data = await state.get_data()
    plugin_id = data['update_plugin_id']
    
    file_id = message.document.file_id
    file_name = message.document.file_name
    
    await state.update_data(file_id=file_id, file_name=file_name)
    await state.set_state(PluginUpdateStates.waiting_description)
    
    await message.answer(
        "✅ Файл получен!\n\n"
        "Теперь отправьте описание обновления:",
        reply_markup=kb.BACK_TO_MENU_KB
    )


@router.message(PluginUpdateStates.waiting_description)
async def profile_update_receive_description(message: Message, state: FSMContext):
    """Получение описания обновления"""
    data = await state.get_data()
    plugin_id = data['update_plugin_id']
    file_id = data['file_id']
    
    description = message.text.strip()
    
    # Обновляем плагин
    await db.update_plugin(plugin_id, file_id=file_id, updated_at='now')
    
    # Получаем подписчиков и отправляем уведомление
    subscribers = await db.get_subscribers(plugin_id=plugin_id)
    plugin = await db.get_plugin(plugin_id)
    
    from main import bot
    
    for subscriber_id in subscribers:
        try:
            await bot.send_message(
                subscriber_id,
                f"📢 <b>Плагин обновлен!</b>\n\n"
                f"📦 <b>{plugin['name']}</b>\n\n"
                f"📝 <b>Что нового:</b>\n{description}\n\n"
                f"👤 Автор: {plugin['display_name']}",
                reply_markup=kb.BACK_TO_PLUGIN_KB(plugin_id)
            )
        except Exception:
            pass
        await asyncio.sleep(0.1)
    
    await state.clear()
    await message.answer(
        "✅ Плагин обновлен!\n\n"
        f"Уведомления отправлены {len(subscribers)} подписчикам.",
        reply_markup=get_main_menu()
    )


@router.callback_query(F.data == "edit_profile")
async def callback_edit_profile(callback: CallbackQuery):
    """Редактирование профиля"""
    await callback.message.edit_text(
        "Что хотите изменить?",
        reply_markup=kb.get_edit_profile_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data == "edit_nickname")
async def callback_edit_nickname(callback: CallbackQuery, state: FSMContext):
    """Изменение никнейма"""
    await state.set_state(EditProfileStates.waiting_nickname)
    await callback.message.edit_text(
        "📝 Отправьте новый никнейм:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@router.message(EditProfileStates.waiting_nickname)
async def profile_receive_nickname(message: Message, state: FSMContext):
    """Получение нового никнейма"""
    nickname = message.text.strip()
    if len(nickname) < 2 or len(nickname) > 50:
        await message.answer("Никнейм должен быть от 2 до 50 символов.", reply_markup=kb.get_cancel_menu())
        return
    
    await db.update_user(message.from_user.id, display_name=nickname)
    await state.clear()
    await message.answer("✅ Никнейм обновлен!", reply_markup=kb.get_main_menu())


@router.callback_query(F.data == "edit_username")
async def callback_edit_username(callback: CallbackQuery, state: FSMContext):
    """Изменение юзернейма"""
    await state.set_state(EditProfileStates.waiting_username)
    await callback.message.edit_text(
        "🔗 Отправьте новый юзернейм (без @) или отправьте '-' чтобы удалить:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@router.message(EditProfileStates.waiting_username)
async def profile_receive_username(message: Message, state: FSMContext):
    """Получение нового юзернейма"""
    username = message.text.strip()
    if username == "-":
        username = None
    elif username and (len(username) < 3 or not username.replace('_', '').isalnum()):
        await message.answer("Некорректный юзернейм.", reply_markup=kb.get_cancel_menu())
        return
    
    await db.update_user(message.from_user.id, username=username)
    await state.clear()
    await message.answer("✅ Юзернейм обновлен!", reply_markup=kb.get_main_menu())


@router.callback_query(F.data == "edit_banner")
async def callback_edit_banner(callback: CallbackQuery):
    """Редактирование баннера (заглушка)"""
    await callback.answer("Функция баннера в разработке.", show_alert=True)


@router.callback_query(F.data == "broadcast_to_subs")
async def callback_broadcast(callback: CallbackQuery, state: FSMContext):
    """Начало рассылки подписчикам"""
    user_id = callback.from_user.id
    stats = await db.get_user_stats(user_id)
    
    if stats['subscriber_count'] == 0:
        await callback.answer("У вас нет подписчиков.", show_alert=True)
        return
    
    await state.set_state(BroadcastStates.waiting_message)
    await callback.message.edit_text(
        f"✉️ У вас {stats['subscriber_count']} подписчиков.\n\n"
        "Отправьте сообщение для рассылки:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@router.message(BroadcastStates.waiting_message)
async def broadcast_receive_message(message: Message, state: FSMContext):
    """Получение сообщения для рассылки"""
    user_id = message.from_user.id
    subscribers = await db.get_subscribers(target_user_id=user_id)
    
    if not subscribers:
        await message.answer("У вас больше нет подписчиков.", reply_markup=kb.get_main_menu())
        await state.clear()
        return
    
    # Отправляем сообщение подписчикам
    sent = 0
    failed = 0
    for subscriber_id in subscribers:
        try:
            await message.bot.copy_message(
                chat_id=subscriber_id,
                from_chat_id=message.chat.id,
                message_id=message.message_id,
                caption=f"📢 <b>Новое сообщение от {message.from_user.full_name}</b>"
            )
            sent += 1
        except Exception as e:
            # logger.error(f"Failed to send broadcast to {subscriber_id}: {e}")
            failed += 1
        await asyncio.sleep(0.1)  # Задержка чтобы не попасть в лимиты
    
    await state.clear()
    await message.answer(
        f"✅ Рассылка завершена!\n"
        f"Отправлено: {sent}\n"
        f"Не удалось: {failed}",
        reply_markup=kb.get_main_menu()
    )


@router.callback_query(F.data.startswith("author_manage_"))
async def profile_author_manage(callback: CallbackQuery):
    """Управление страницей автора (заглушка)"""
    await callback.answer("Функция в разработке.", show_alert=True)
