"""Утилиты для бота"""

import asyncio
from typing import List


async def broadcast_message(bot, user_ids: List[int], text: str, **kwargs):
    """Рассылка сообщений пользователям"""
    sent = 0
    failed = 0
    
    for user_id in user_ids:
        try:
            await bot.send_message(user_id, text, **kwargs)
            sent += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.1)  # Задержка чтобы не попасть в лимиты
    
    return sent, failed


def format_file_size(size_bytes: int) -> str:
    """Форматирование размера файла"""
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB"]
    i = 0
    size = size_bytes
    
    while size >= 1024.0 and i < len(size_names) - 1:
        size /= 1024.0
        i += 1
    
    return f"{size:.1f} {size_names[i]}"


def escape_html(text: str) -> str:
    """Экранирование HTML специальных символов"""
    return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
