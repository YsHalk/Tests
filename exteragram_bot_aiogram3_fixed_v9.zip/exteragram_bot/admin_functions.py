import os
from typing import Dict, List, Optional, Any
from aiogram import types, F, Router, Bot
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardMarkup,
    KeyboardButton,
)
from datetime import datetime
import asyncio

try:
    from . import buttons
except ImportError:
    import buttons
try:
    from .database import Database, Plugin
except ImportError:
    from database import Database, Plugin
try:
    from .config import (
        DATABASE_PATH,
        ADMIN_IDS,
        ADMIN_GROUP_ID,
        TOPIC_SUBMISSIONS,
        TOPIC_STORAGE,
        TOPIC_SECURITY,
        MESSAGES,
        CATEGORIES,
        DEV_STATUSES,
    )
except ImportError:
    from config import (
        DATABASE_PATH,
        ADMIN_IDS,
        ADMIN_GROUP_ID,
        TOPIC_SUBMISSIONS,
        TOPIC_STORAGE,
        TOPIC_SECURITY,
        MESSAGES,
        CATEGORIES,
        DEV_STATUSES,
    )

db = Database(DATABASE_PATH)
router = Router()

async def _edit_or_send(callback_query: types.CallbackQuery, text: str, reply_markup=None):
    """Для inline-кнопок: редактируем текущее сообщение, иначе шлем новое."""
    msg = callback_query.message
    try:
        await msg.edit_text(text, reply_markup=reply_markup)
    except Exception:
        await msg.answer(text, reply_markup=reply_markup)


class EditSubmissionStates(StatesGroup):
    waiting_field = State()
    waiting_value = State()

class BroadcastStates(StatesGroup):
    waiting_message = State()

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

def create_admin_menu() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=buttons.ADMIN["pending_submissions"], callback_data="admin_submissions")],
        [InlineKeyboardButton(text=buttons.ADMIN["pending_updates"], callback_data="admin_updates")],
        [InlineKeyboardButton(text=buttons.ADMIN["broadcast"], callback_data="admin_broadcast")],
        [InlineKeyboardButton(text=buttons.ADMIN["stats"], callback_data="admin_stats")]
    ])
    return keyboard

def create_submission_review_menu(submission_id: int) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=buttons.ADMIN["approve"], callback_data=f"approve_sub_{submission_id}"),
            InlineKeyboardButton(text=buttons.ADMIN["edit"], callback_data=f"edit_sub_{submission_id}"),
            InlineKeyboardButton(text=buttons.ADMIN["reject"], callback_data=f"reject_sub_{submission_id}")
        ]
    ])
    return keyboard

def create_update_review_menu(update_id: int) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=buttons.ADMIN["approve"], callback_data=f"approve_upd_{update_id}"),
            InlineKeyboardButton(text=buttons.ADMIN["reject"], callback_data=f"reject_upd_{update_id}")
        ]
    ])
    return keyboard

def create_edit_field_menu(submission_id: int) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Название", callback_data=f"edit_field_{submission_id}_name")],
        [InlineKeyboardButton(text="Описание", callback_data=f"edit_field_{submission_id}_description")],
        [InlineKeyboardButton(text="Категория", callback_data=f"edit_field_{submission_id}_category")],
        [InlineKeyboardButton(text="Статус", callback_data=f"edit_field_{submission_id}_status")],
        [InlineKeyboardButton(text="Теги", callback_data=f"edit_field_{submission_id}_tags")],
        [InlineKeyboardButton(text=buttons.COMMON["back"], callback_data=f"back_to_sub_{submission_id}")]
    ])
    return keyboard

async def send_to_topic(bot, topic_id: int, text: str, file_id: str = None, 
                       reply_markup: InlineKeyboardMarkup = None) -> Optional[int]:
    try:
        # Если админ-группа/топики не настроены, просто не отправляем (чтобы бот не падал)
        if not ADMIN_GROUP_ID:
            return None

        if file_id:
            kwargs = dict(chat_id=ADMIN_GROUP_ID, document=file_id, caption=text, reply_markup=reply_markup)
            # message_thread_id допустим только для forum topics
            if topic_id:
                kwargs["message_thread_id"] = topic_id
            message = await bot.send_document(**kwargs)
        else:
            kwargs = dict(chat_id=ADMIN_GROUP_ID, text=text, reply_markup=reply_markup)
            if topic_id:
                kwargs["message_thread_id"] = topic_id
            message = await bot.send_message(**kwargs)
        return message.message_id
    except Exception as e:
        print(f"Error sending to topic: {e}")
        return None


def format_submission_message(sub: Dict[str, Any]) -> str:
    return (
        "📥 <b>Новая заявка на загрузку</b>\n\n"
        f"<b>ID:</b> {sub.get('submission_id')}\n"
        f"<b>Плагин:</b> {sub.get('plugin_name')}\n"
        f"<b>Автор:</b> @{sub.get('username')} ({sub.get('display_name')})\n"
        f"<b>Категория:</b> {buttons.CATEGORIES.get(sub.get('category'), sub.get('category'))}\n"
        f"<b>Статус:</b> {buttons.DEV_STATUSES.get(sub.get('status'), sub.get('status'))}\n"
        f"<b>Теги:</b> {sub.get('tags', '')}\n\n"
        f"<b>Описание:</b> {sub.get('description', '')}"
    )


def format_update_message(upd: Dict[str, Any]) -> str:
    return (
        "🔄 <b>Заявка на обновление</b>\n\n"
        f"<b>ID:</b> {upd.get('update_id')}\n"
        f"<b>Плагин:</b> {upd.get('plugin_name')}\n"
        f"<b>Автор:</b> @{upd.get('username')} ({upd.get('display_name')})\n\n"
        f"<b>Описание обновления:</b> {upd.get('description', '') or '—'}"
    )

async def notify_admins_about_submission(bot: Bot, submission_data: Dict[str, Any]):
    """Уведомляет админов о новой заявке (отправляет сообщение в нужный топик)."""
    # 1) файл — в тему безопасности (если настроена)
    await send_to_topic(
        bot,
        TOPIC_SECURITY,
        f"🔒 <b>Файл для проверки</b>\n\n{submission_data.get('plugin_name')}",
        file_id=submission_data.get("file_id"),
    )
    # 2) карточка заявки — в тему заявок
    await send_to_topic(
        bot,
        TOPIC_SUBMISSIONS,
        format_submission_message(submission_data),
        reply_markup=create_submission_review_menu(submission_data["submission_id"]),
    )

async def notify_admins_about_update(bot: Bot, update_data: Dict[str, Any]):
    """Уведомляет админов о заявке на обновление."""
    await send_to_topic(
        bot,
        TOPIC_SECURITY,
        f"🔒 <b>Файл обновления для проверки</b>\n\n{update_data.get('plugin_name')}",
        file_id=update_data.get("file_id"),
    )
    await send_to_topic(
        bot,
        TOPIC_SUBMISSIONS,
        format_update_message(update_data),
        reply_markup=create_update_review_menu(update_data["update_id"]),
    )


@router.callback_query(F.data == "admin_submissions")
async def admin_submissions(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    pending = db.get_pending_submissions()
    if not pending:
        await _edit_or_send(callback_query, "✅ Нет заявок на загрузку в ожидании.", reply_markup=create_admin_menu())
        await callback_query.answer()
        return

    text = "📥 <b>Ожидающие заявки</b>\n\n" + "\n".join(
        [f"• <b>{s['submission_id']}</b>: {s['plugin_name']} (@{s['username']})" for s in pending[:20]]
    )
    await _edit_or_send(callback_query, text, reply_markup=create_admin_menu())
    await callback_query.answer()


@router.callback_query(F.data == "admin_updates")
async def admin_updates(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    pending = db.get_pending_updates()
    if not pending:
        await _edit_or_send(callback_query, "✅ Нет заявок на обновление в ожидании.", reply_markup=create_admin_menu())
        await callback_query.answer()
        return

    text = "🔄 <b>Ожидающие обновления</b>\n\n" + "\n".join(
        [f"• <b>{u['update_id']}</b>: {u['plugin_name']} (@{u['username']})" for u in pending[:20]]
    )
    await _edit_or_send(callback_query, text, reply_markup=create_admin_menu())
    await callback_query.answer()


@router.callback_query(F.data.startswith("approve_sub_"))
async def approve_submission(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    submission_id = int(callback_query.data.replace("approve_sub_", ""))
    sub = db.get_submission(submission_id)
    if not sub:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return

    plugin = Plugin(
        plugin_id=0,
        name=sub["plugin_name"],
        description=sub["description"],
        file_id=sub["file_id"],
        file_name=sub["file_name"],
        file_size=sub["file_size"],
        photo_id=sub.get("photo_id"),
        author_id=sub["user_id"],
        category=sub["category"],
        status=sub["status"],
        tags=sub.get("tags", ""),
    )

    plugin_id = db.create_plugin(plugin)
    if not plugin_id:
        await callback_query.answer("Ошибка при публикации", show_alert=True)
        return

    db.update_submission(submission_id, state="approved")

    # уведомление автору
    try:
        await callback_query.bot.send_message(
            sub["user_id"],
            MESSAGES["plugin_approved"].format(name=sub["plugin_name"]),
        )
    except Exception:
        pass

    await callback_query.answer("✅ Одобрено")
    try:
        await callback_query.message.edit_text(
            f"✅ <b>Заявка одобрена</b>\n\nID: {submission_id}\nПлагин: {sub['plugin_name']}\nОпубликовал: @{callback_query.from_user.username}",
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("reject_sub_"))
async def reject_submission(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    submission_id = int(callback_query.data.replace("reject_sub_", ""))
    sub = db.get_submission(submission_id)
    if not sub:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return

    db.update_submission(submission_id, state="rejected")
    try:
        await callback_query.bot.send_message(
            sub["user_id"],
            MESSAGES["plugin_rejected"].format(name=sub["plugin_name"], reason="без указания причины"),
        )
    except Exception:
        pass

    await callback_query.answer("❌ Отклонено")
    try:
        await callback_query.message.edit_text(
            f"❌ <b>Заявка отклонена</b>\n\nID: {submission_id}\nПлагин: {sub['plugin_name']}\nОтклонил: @{callback_query.from_user.username}",
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("edit_sub_"))
async def edit_submission(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    submission_id = int(callback_query.data.replace("edit_sub_", ""))
    sub = db.get_submission(submission_id)
    if not sub:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return

    await state.update_data(submission_id=submission_id)
    await _edit_or_send(callback_query, "✏️ Что изменить?", reply_markup=create_edit_field_menu(submission_id))
    await callback_query.answer()


@router.callback_query(F.data.startswith("edit_field_"))
async def edit_submission_field(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    parts = callback_query.data.split("_")
    # edit_field_{submission_id}_{field}
    submission_id = int(parts[2])
    field = parts[3]
    await state.set_state(EditSubmissionStates.waiting_value)
    await state.update_data(submission_id=submission_id, field=field)
    await _edit_or_send(callback_query, "Отправьте новое значение одним сообщением:")
    await callback_query.answer()



@router.message(EditSubmissionStates.waiting_value)
async def save_edited_field(message: types.Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["access_denied"])
        return
    
    data = await state.get_data()
    submission_id = data["submission_id"]
    field = data["field"]
    
    submission = db.get_submission(submission_id)
    if not submission:
        await message.answer("Заявка не найдена")
        await state.clear()
        return
    
    new_value = (message.text or "").strip()

    # mapping UI-field -> DB field
    field_map = {
        "name": "plugin_name",
        "description": "description",
        "category": "category",
        "status": "status",
        "tags": "tags",
    }
    db_field = field_map.get(field)
    if not db_field:
        await message.answer("Неизвестное поле для редактирования")
        await state.clear()
        return
    
    if field == "name" and (len(new_value) < 2 or len(new_value) > 100):
        await message.answer("Название должно быть от 2 до 100 символов")
        return
    
    if field == "category":
        # принимаем как ключ (tools/fun/...) так и текстовую метку
        if new_value in CATEGORIES:
            pass
        elif new_value in CATEGORIES.values():
            # reverse lookup
            for k, v in CATEGORIES.items():
                if v == new_value:
                    new_value = k
                    break
        else:
            await message.answer("Неверная категория. Введите ключ из списка: " + ", ".join(CATEGORIES.keys()))
            return
    
    if field == "status":
        if new_value in DEV_STATUSES:
            pass
        elif new_value in DEV_STATUSES.values():
            for k, v in DEV_STATUSES.items():
                if v == new_value:
                    new_value = k
                    break
        else:
            await message.answer("Неверный статус. Введите ключ из списка: " + ", ".join(DEV_STATUSES.keys()))
            return
    
    db.update_submission(submission_id, **{db_field: new_value})

    # Уведомляем автора (без inline подтверждения — callback_data имеет жесткий лимит 64 байта)
    try:
        await message.bot.send_message(
            submission["user_id"],
            "⚠️ <b>Ваша заявка была отредактирована модератором</b>\n\n"
            f"<b>Плагин:</b> {submission['plugin_name']}\n"
            f"<b>Изменено:</b> {db_field}\n"
            f"<b>Новое значение:</b> {new_value}\n\n"
            "После проверки заявка будет одобрена или отклонена.",
        )
    except Exception:
        pass

    await message.answer("✅ Значение обновлено. Теперь можно нажать «Одобрить» в карточке заявки.")
    
    await state.clear()

@router.callback_query(F.data == "admin_broadcast")
async def admin_broadcast(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    await state.set_state(BroadcastStates.waiting_message)
    await _edit_or_send(callback_query, 
        "Отправьте сообщение для рассылки всем пользователям:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=buttons.COMMON["cancel"], callback_data="cancel_admin_broadcast")
        ]])
    )
    await callback_query.answer()

@router.message(BroadcastStates.waiting_message)
async def process_broadcast(message: types.Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["access_denied"])
        return
    
    with db._get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM users")
        users = [row[0] for row in cursor.fetchall()]
    
    success_count = 0
    fail_count = 0
    
    for user_id in users:
        try:
            if message.photo:
                await message.bot.send_photo(user_id, message.photo[-1].file_id, caption=message.caption)
            elif message.video:
                await message.bot.send_video(user_id, message.video.file_id, caption=message.caption)
            elif message.document:
                await message.bot.send_document(user_id, message.document.file_id, caption=message.caption)
            else:
                await message.bot.send_message(user_id, message.text)
            success_count += 1
            await asyncio.sleep(0.1)
        except:
            fail_count += 1
    
    await state.clear()
    await message.answer(
        f"✅ Рассылка завершена\n\nУспешно: {success_count}\nНе удалось: {fail_count}",
        reply_markup=create_main_menu()
    )

@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    with db._get_connection() as conn:
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM plugins WHERE is_archived = 0")
        total_plugins = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM plugins WHERE is_archived = 1")
        archived_plugins = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(downloads) FROM plugins")
        total_downloads = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT SUM(views) FROM plugins")
        total_views = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT COUNT(*) FROM submissions WHERE state = 'pending'")
        pending_submissions = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM updates WHERE state = 'pending'")
        pending_updates = cursor.fetchone()[0]
    
    text = f"""📊 <b>Статистика библиотеки</b>

👥 <b>Пользователи:</b> {total_users}
📦 <b>Плагины:</b> {total_plugins} (в архиве: {archived_plugins})
📥 <b>Скачиваний:</b> {total_downloads}
👁 <b>Просмотров:</b> {total_views}

⚠️ <b>На модерации:</b>
└ Заявки на загрузку: {pending_submissions}
└ Заявки на обновление: {pending_updates}"""
    
    await _edit_or_send(callback_query, text)
    await callback_query.answer()

@router.callback_query(F.data.startswith("approve_upd_"))
async def approve_update(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    update_id = int(callback_query.data.replace("approve_upd_", ""))
    update_req = db.get_update_request(update_id)
    if not update_req:
        await callback_query.answer("Обновление не найдено", show_alert=True)
        return
    
    success = db.update_plugin(
        update_req["plugin_id"],
        file_id=update_req["file_id"],
        file_name=update_req["file_name"]
    )
    
    if not success:
        await callback_query.answer("Ошибка при обновлении плагина", show_alert=True)
        return
    
    db.update_update_request(update_id, state="approved")
    
    subscribers = db.get_plugin_subscribers(update_req["plugin_id"])
    plugin = db.get_plugin(update_req["plugin_id"])
    
    for subscriber_id in subscribers:
        try:
            text = f"""🔄 <b>Обновление плагина!</b>

Плагин "<b>{plugin.name}</b>" получил обновление!

<b>Автор:</b> @{update_req['username']}
<b>Описание обновления:</b> {update_req.get('description', 'Без описания')}"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="📥 Перейти к плагину", callback_data=f"plugin_{plugin.plugin_id}")]
            ])
            
            await callback_query.bot.send_message(subscriber_id, text, reply_markup=keyboard)
            await asyncio.sleep(0.1)
        except:
            pass
    
    try:
        await callback_query.bot.send_message(
            update_req["user_id"],
            f"✅ Обновление плагина '{plugin.name}' одобрено и опубликовано!"
        )
    except:
        pass
    
    await callback_query.answer("✅ Обновление одобрено!")
    
    text = f"""✅ <b>Обновление одобрено</b>

<b>ID:</b> {update_id}
<b>Плагин:</b> {plugin.name}
<b>Автор:</b> @{update_req['username']}
<b>Одобрил:</b> @{callback_query.from_user.username}"""
    
    try:
        await callback_query.message.edit_text(text=text)
    except:
        pass

@router.callback_query(F.data.startswith("reject_upd_"))
async def reject_update(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    update_id = int(callback_query.data.replace("reject_upd_", ""))
    update_req = db.get_update_request(update_id)
    if not update_req:
        await callback_query.answer("Обновление не найдено", show_alert=True)
        return
    
    db.update_update_request(update_id, state="rejected")
    
    try:
        await callback_query.bot.send_message(
            update_req["user_id"],
            f"❌ Обновление плагина '{update_req['plugin_name']}' отклонено. Свяжитесь с администратором для уточнения."
        )
    except:
        pass
    
    await callback_query.answer("❌ Обновление отклонено")
    
    text = f"""❌ <b>Обновление отклонено</b>

<b>ID:</b> {update_id}
<b>Плагин:</b> {update_req['plugin_name']}
<b>Автор:</b> @{update_req['username']}
<b>Отклонил:</b> @{callback_query.from_user.username}"""
    
    try:
        await callback_query.message.edit_text(text=text)
    except:
        pass

@router.callback_query(F.data.startswith("confirm_edit_"))
async def confirm_edit(callback_query: types.CallbackQuery):
    parts = callback_query.data.split("_")
    # поддерживаем два формата:
    # 1) confirm_edit_<submission_id>
    # 2) confirm_edit_<submission_id>_<field>_<new_value>
    submission_id = int(parts[2])
    field = parts[3] if len(parts) >= 4 else None
    new_value = "_".join(parts[4:]) if len(parts) >= 5 else None
    
    submission = db.get_submission(submission_id)
    if not submission:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return
    
    if field and new_value is not None:
        field_map = {"name": "plugin_name", "description": "description", "category": "category", "status": "status", "tags": "tags"}
        db_field = field_map.get(field, field)
        db.update_submission(submission_id, **{db_field: new_value})
    db.update_submission(submission_id, state="approved")
    
    plugin = Plugin(
        plugin_id=0,
        name=submission["plugin_name"],
        description=submission.get("description", ""),
        file_id=submission["file_id"],
        file_name=submission["file_name"],
        file_size=submission["file_size"],
        photo_id=submission.get("photo_id"),
        author_id=submission["user_id"],
        category=submission["category"],
        status=submission["status"],
        tags=submission.get("tags", ""),
    )
    
    plugin_id = db.create_plugin(plugin)
    
    if plugin_id:
        await callback_query.answer("✅ Изменения приняты! Плагин опубликован.")
        
        try:
            await callback_query.message.edit_text(
                f"✅ Ваш плагин '{submission['plugin_name']}' одобрен и опубликован!\n\n"
                f"Изменения в {field} были приняты."
            )
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при публикации плагина.", show_alert=True)

@router.callback_query(F.data.startswith("reject_edit_"))
async def reject_edit(callback_query: types.CallbackQuery):
    submission_id = int(callback_query.data.replace("reject_edit_", ""))
    
    db.update_submission(submission_id, state="rejected")
    
    await callback_query.answer("❌ Изменения отклонены.")
    
    try:
        await callback_query.message.edit_text(
            "❌ Изменения были отклонены. Пожалуйста, свяжитесь с поддержкой для уточнения."
        )
    except:
        pass

@router.callback_query(F.data == "cancel_admin_edit")
async def cancel_admin_edit(callback_query: types.CallbackQuery):
    await callback_query.answer("Редактирование отменено")
    await callback_query.message.delete()

@router.callback_query(F.data == "cancel_admin_broadcast")
async def cancel_admin_broadcast(callback_query: types.CallbackQuery):
    await callback_query.answer("Рассылка отменена")
    await callback_query.message.delete()

def create_main_menu() -> ReplyKeyboardMarkup:
    from user_functions import create_main_menu
    return create_main_menu()
