from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database import Database
from states import SearchStates
import keyboards as kb

router = Router()
db = Database()


@router.message(SearchStates.waiting_query)
async def search_receive_query(message: Message, state: FSMContext):
    """Получение поискового запроса"""
    query = message.text.strip()
    
    if len(query) < 2:
        await message.answer("Запрос слишком короткий. Минимум 2 символа.")
        return
    
    # Выполняем поиск
    results = await db.search_plugins(query, limit=10)
    
    if not results:
        await message.answer(
            "🔍 <b>Ничего не найдено.</b>\n\n"
            "Попробуйте другой запрос или проверьте орфографию.",
            reply_markup=kb.get_main_menu()
        )
        await state.clear()
        return
    
    # Сохраняем запрос в состоянии
    await state.update_data(last_query=query)
    
    # Формируем список результатов
    plugin_list = [(p['plugin_id'], p['name']) for p in results]
    keyboard = kb.get_search_results_plugins(plugin_list)
    
    # Формируем текст результатов
    text = f"🔍 <b>Возможно, вы искали:</b>\n\n"
    text += f"Результаты по запросу '<i>{query}</i>':\n\n"
    
    for i, plugin in enumerate(results, 1):
        status_emoji = {"development": "🔧", "updates": "🔄", "completed": "✅"}.get(plugin['status'], "")
        text += f"{i}. <b>{plugin['name']}</b> {status_emoji}\n"
        text += f"   👤 {plugin['display_name']}\n"
        text += f"   ⬇️ {plugin['downloads']} | ⭐ {plugin['rating']:.1f}\n\n"
    
    await message.answer(text, reply_markup=keyboard)
    await state.clear()


@router.callback_query(F.data.startswith("plugin_"))
async def search_show_plugin(callback: CallbackQuery):
    """Показ страницы плагина"""
    plugin_id = int(callback.data.replace("plugin_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("Плагин не найден.", show_alert=True)
        return
    
    # Увеличиваем просмотры
    await db.increment_views(plugin_id)
    
    # Проверяем подписку
    is_subscribed = await db.is_subscribed(user_id, plugin_id=plugin_id)
    is_owner = plugin['user_id'] == user_id
    # TODO: Проверка админа
    is_admin = False
    
    # Формируем текст
    text = f"📦 <b>{plugin['name']}</b>\n\n"
    text += f"{plugin['description']}\n\n"
    
    status_names = {"development": "🔧 В работе", "updates": "🔄 Возможны обновления", 
                   "completed": "✅ Завершено", "archived": "📦 В архиве"}
    text += f"📊 <b>Статус разработки:</b> {status_names.get(plugin['status'], plugin['status'])}\n"
    text += f"👤 <b>Автор:</b> @{plugin.get('username', 'скрыт')} ({plugin['display_name']})\n"
    
    category_names = dict(kb.CATEGORIES)
    text += f"📂 <b>Категория:</b> {category_names.get(plugin['category'], plugin['category'])}\n"
    text += f"🕐 <b>Обновлено:</b> {plugin['updated_at'][:10]}\n\n"
    
    text += f"📈 <b>Статистика:</b>\n"
    text += f"   👁 Просмотров: {plugin['views']}\n"
    text += f"   ⬇️ Скачиваний: {plugin['downloads']}\n"
    text += f"   ⭐ Рейтинг: {plugin['rating']:.1f} ({plugin['rating_count']} оценок)\n"
    
    if plugin.get('tags'):
        text += f"\n🏷 <b>Теги:</b> {plugin['tags']}"
    
    # Клавиатура
    keyboard = kb.get_plugin_page_keyboard(
        plugin_id, user_id, plugin['user_id'],
        is_subscribed, is_owner, is_admin
    )
    
    # Отправляем сообщение с обложкой или без
    if plugin.get('photo_file_id'):
        await callback.message.answer_photo(
            photo=plugin['photo_file_id'],
            caption=text,
            reply_markup=keyboard
        )
    else:
        await callback.message.answer(text, reply_markup=keyboard)
    
    await callback.answer()


@router.callback_query(F.data.startswith("download_"))
async def search_download_plugin(callback: CallbackQuery):
    """Скачивание плагина"""
    plugin_id = int(callback.data.replace("download_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("Плагин не найден.", show_alert=True)
        return
    
    # Увеличиваем счетчик скачиваний
    await db.increment_downloads(plugin_id)
    
    # Отправляем файл
    try:
        await callback.message.answer_document(
            document=plugin['file_id'],
            caption=f"📦 <b>{plugin['name']}</b>\n\n"
                   f"Автор: {plugin['display_name']}\n"
                   f"Версия от: {plugin['updated_at'][:10]}"
        )
        await callback.answer("Плагин отправлен!")
    except Exception as e:
        await callback.answer("Ошибка при отправке файла.", show_alert=True)


@router.callback_query(F.data.startswith("toggle_sub_"))
async def search_toggle_subscription(callback: CallbackQuery):
    """Подписка/отписка на плагин"""
    plugin_id = int(callback.data.replace("toggle_sub_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("Плагин не найден.", show_alert=True)
        return
    
    is_subscribed = await db.is_subscribed(user_id, plugin_id=plugin_id)
    
    if is_subscribed:
        await db.remove_subscription(user_id, plugin_id=plugin_id)
        await callback.answer("Вы отписались от плагина.")
    else:
        await db.add_subscription(user_id, plugin_id=plugin_id)
        await callback.answer("Вы подписались на плагин!")
    
    # Обновляем клавиатуру
    is_owner = plugin['user_id'] == user_id
    is_admin = False  # TODO
    keyboard = kb.get_plugin_page_keyboard(
        plugin_id, user_id, plugin['user_id'],
        not is_subscribed, is_owner, is_admin
    )
    
    await callback.message.edit_reply_markup(reply_markup=keyboard)


@router.callback_query(F.data.startswith("author_"))
async def search_show_author(callback: CallbackQuery):
    """Показ профиля автора"""
    author_user_id = int(callback.data.replace("author_", ""))
    user_id = callback.from_user.id
    
    author = await db.get_user(author_user_id)
    if not author:
        await callback.answer("Пользователь не найден.", show_alert=True)
        return
    
    stats = await db.get_user_stats(author_user_id)
    
    # Проверяем подписку
    is_subscribed = await db.is_subscribed(user_id, target_user_id=author_user_id)
    
    # Формируем текст
    text = f"👤 <b>{author['display_name']}</b>\n\n"
    
    if author.get('username'):
        text += f"🔗 @{author['username']}\n\n"
    
    text += f"📊 <b>Статистика:</b>\n"
    text += f"👥 Подписчиков: {stats['subscriber_count']}\n"
    
    if stats['plugin_count'] > 0:
        text += f"\n📦 <b>Плагины автора:</b>\n"
        text += f"   Всего: {stats['plugin_count']}\n"
        text += f"   ⬇️ Скачиваний: {stats['total_downloads']}\n"
        text += f"   👁 Просмотров: {stats['total_views']}\n"
        text += f"   ⭐ Средний рейтинг: {stats['avg_rating']:.1f}\n"
    
    # Получаем плагины автора
    author_plugins = await db.get_user_plugins(author_user_id, include_archived=False)
    has_plugins = len(author_plugins) > 0
    
    keyboard = kb.get_author_profile_keyboard(author_user_id, is_subscribed, has_plugins)
    
    # TODO: Если есть баннер - отправить с баннером
    await callback.message.answer(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("sub_author_"))
async def search_toggle_author_subscription(callback: CallbackQuery):
    """Подписка/отписка на автора"""
    author_user_id = int(callback.data.replace("sub_author_", ""))
    user_id = callback.from_user.id
    
    if author_user_id == user_id:
        await callback.answer("Нельзя подписаться на себя.", show_alert=True)
        return
    
    author = await db.get_user(author_user_id)
    if not author:
        await callback.answer("Пользователь не найден.", show_alert=True)
        return
    
    is_subscribed = await db.is_subscribed(user_id, target_user_id=author_user_id)
    
    if is_subscribed:
        await db.remove_subscription(user_id, target_user_id=author_user_id)
        await callback.answer("Вы отписались от автора.")
    else:
        await db.add_subscription(user_id, target_user_id=author_user_id)
        await callback.answer("Вы подписались на автора!")
    
    # Обновляем клавиатуру
    author_plugins = await db.get_user_plugins(author_user_id, include_archived=False)
    has_plugins = len(author_plugins) > 0
    keyboard = kb.get_author_profile_keyboard(author_user_id, not is_subscribed, has_plugins)
    
    await callback.message.edit_reply_markup(reply_markup=keyboard)


@router.callback_query(F.data.startswith("author_plugins_"))
async def search_show_author_plugins(callback: CallbackQuery):
    """Показ плагинов автора"""
    author_user_id = int(callback.data.replace("author_plugins_", ""))
    
    plugins = await db.get_user_plugins(author_user_id, include_archived=False)
    if not plugins:
        await callback.answer("У автора нет плагинов.", show_alert=True)
        return
    
    plugin_list = [(p['plugin_id'], p['name']) for p in plugins]
    keyboard = kb.get_search_results_plugins(plugin_list)
    
    await callback.message.answer(
        f"📦 <b>Плагины автора</b>\n\n"
        f"Найдено: {len(plugins)}",
        reply_markup=keyboard
    )
    await callback.answer()


@router.callback_query(F.data.startswith("rate_"))
async def search_rate_plugin(callback: CallbackQuery):
    """Оценка плагина"""
    plugin_id = int(callback.data.replace("rate_", ""))
    
    keyboard = kb.get_rating_keyboard(plugin_id)
    await callback.message.answer(
        "⭐ Оцените плагин:",
        reply_markup=keyboard
    )
    await callback.answer()


@router.callback_query(F.data.startswith("rate_set_"))
async def search_set_rating(callback: CallbackQuery):
    """Установка оценки"""
    parts = callback.data.replace("rate_set_", "").split("_")
    plugin_id = int(parts[0])
    rating = int(parts[1])
    user_id = callback.from_user.id
    
    await db.add_rating(user_id, plugin_id, rating)
    await callback.answer(f"Спасибо за оценку! {'⭐' * rating}")
    
    # Удаляем сообщение с оценкой
    await callback.message.delete()


@router.callback_query(F.data == "back_to_search")
async def search_back(callback: CallbackQuery, state: FSMContext):
    """Возврат к результатам поиска"""
    data = await state.get_data()
    query = data.get('last_query')
    
    if query:
        results = await db.search_plugins(query, limit=10)
        if results:
            plugin_list = [(p['plugin_id'], p['name']) for p in results]
            keyboard = kb.get_search_results_plugins(plugin_list)
            
            text = f"🔍 <b>Результаты по запросу '{query}':</b>\n\n"
            for i, plugin in enumerate(results, 1):
                status_emoji = {"development": "🔧", "updates": "🔄", "completed": "✅"}.get(plugin['status'], "")
                text += f"{i}. <b>{plugin['name']}</b> {status_emoji}\n"
                text += f"   👤 {plugin['display_name']}\n\n"
            
            await callback.message.edit_text(text, reply_markup=keyboard)
        else:
            await callback.message.edit_text("Результатов нет.", reply_markup=kb.BACK_TO_MENU_KB)
    else:
        await callback.message.edit_text("Поиск.", reply_markup=kb.BACK_TO_MENU_KB)
    
    await callback.answer()