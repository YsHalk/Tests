from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
import asyncio

from database import Database
from keyboards import get_main_menu, BACK_TO_MENU_KB
from states import EditProfileStates, PluginUpdateStates

router = Router()
db = Database()


@router.callback_query(F.data == "my_profile")
async def profile_show(callback: CallbackQuery):
    """Показ своего профиля"""
    user_id = callback.from_user.id
    user = await db.get_user(user_id)
    stats = await db.get_user_stats(user_id)
    
    is_author = stats['plugin_count'] > 0
    
    # Формируем текст профиля
    text = f"👤 <b>Ваш профиль:</b>\n\n"
    text += f"📝 <b>Никнейм:</b> {user['display_name']}\n"
    
    if user.get('username'):
        text += f"🔗 <b>Юзернейм:</b> @{user['username']}\n"
    
    text += f"\n📊 <b>Статистика:</b>\n"
    text += f"👥 Подписчиков: {stats['subscriber_count']}\n"
    
    if is_author:
        text += f"\n📦 <b>Ваши плагины:</b>\n"
        text += f"   Всего: {stats['plugin_count']}\n"
        text += f"   ⬇️ Скачиваний: {stats['total_downloads']}\n"
        text += f"   👁 Просмотров: {stats['total_views']}\n"
        text += f"   ⭐ Средний рейтинг: {stats['avg_rating']:.1f}\n"
    
    from keyboards import get_my_profile_keyboard
    keyboard = get_my_profile_keyboard(is_author)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data == "my_plugins")
async def profile_my_plugins(callback: CallbackQuery):
    """Мои плагины"""
    user_id = callback.from_user.id
    
    # Показываем включая архивные
    plugins = await db.get_user_plugins(user_id, include_archived=True)
    
    if not plugins:
        await callback.answer("У вас еще нет плагинов.", show_alert=True)
        return
    
    text = "📦 <b>Ваши плагины:</b>\n\n"
    
    active_plugins = [p for p in plugins if not p['archived']]
    archived_plugins = [p for p in plugins if p['archived']]
    
    if active_plugins:
        text += "📋 <b>Активные:</b>\n"
        for plugin in active_plugins:
            status_emoji = {"development": "🔧", "updates": "🔄", "completed": "✅"}.get(plugin['status'], "")
            approved = "✅" if plugin['approved'] else "⏳"
            text += f"• {approved} <b>{plugin['name']}</b> {status_emoji}\n"
            text += f"  ⬇️ {plugin['downloads']} | 👁 {plugin['views']}\n\n"
    
    if archived_plugins:
        text += "📦 <b>В архиве:</b>\n"
        for plugin in archived_plugins:
            text += f"• <b>{plugin['name']}</b>\n"
            text += f"  ⬇️ {plugin['downloads']} | 👁 {plugin['views']}\n\n"
    
    # Формируем клавиатуру
    from keyboards import InlineKeyboardBuilder
    kb = InlineKeyboardBuilder()
    
    for plugin in plugins:
        status = "📦" if plugin['archived'] else "📋"
        kb.button(text=f"{status} {plugin['name']}", callback_data=f"plugin_{plugin['plugin_id']}")
    
    kb.button(text="⬅️ Назад", callback_data="my_profile")
    kb.adjust(1)
    
    await callback.message.edit_text(text, reply_markup=kb.as_markup())
    await callback.answer()


@router.callback_query(F.data == "my_subscriptions")
async def profile_my_subscriptions(callback: CallbackQuery):
    """Мои подписки"""
    user_id = callback.from_user.id
    
    # Получаем подписки
    author_subs = await db.get_user_subscriptions_on_authors(user_id)
    plugin_subs = await db.get_user_subscriptions_on_plugins(user_id)
    
    if not author_subs and not plugin_subs:
        await callback.answer("У вас нет подписок.", show_alert=True)
        return
    
    text = "⭐ <b>Ваши подписки:</b>\n\n"
    
    if author_subs:
        text += "👤 <b>Авторы:</b>\n"
        for author in author_subs:
            text += f"• {author['display_name']}"
            if author.get('username'):
                text += f" (@{author['username']})"
            text += "\n"
        text += "\n"
    
    if plugin_subs:
        text += "📦 <b>Плагины:</b>\n"
        for plugin in plugin_subs:
            text += f"• {plugin['name']}\n"
    
    # Клавиатура
    from keyboards import get_subscriptions_list
    subscriptions = []
    for author in author_subs:
        subscriptions.append(('author', author['user_id'], author['display_name']))
    for plugin in plugin_subs:
        subscriptions.append(('plugin', plugin['plugin_id'], plugin['name']))
    
    keyboard = get_subscriptions_list(subscriptions)
    
    await callback.message.edit_text(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("manage_"))
async def profile_manage_plugin(callback: CallbackQuery):
    """Управление плагином"""
    plugin_id = int(callback.data.replace("manage_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("Плагин не найден.", show_alert=True)
        return
    
    if plugin['user_id'] != user_id:
        await callback.answer("Вы не можете управлять этим плагином.", show_alert=True)
        return
    
    from keyboards import get_manage_plugin_keyboard
    keyboard = get_manage_plugin_keyboard(plugin_id, plugin['archived'])
    
    text = f"⚙️ <b>Управление плагином:</b>\n\n" f"📦 <b>{plugin['name']}</b>\n\n" f"Выберите действие:"
    
    await callback.message.answer(text, reply_markup=keyboard)
    await callback.answer()


@router.callback_query(F.data.startswith("archive_"))
async def profile_archive_plugin(callback: CallbackQuery):
    """Архивирование плагина"""
    plugin_id = int(callback.data.replace("archive_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin or plugin['user_id'] != user_id:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    await db.update_plugin(plugin_id, archived=True)
    await callback.answer(f"Плагин '{plugin['name']}' отправлен в архив.")
    
    # Обновляем клавиатуру
    from keyboards import get_manage_plugin_keyboard
    keyboard = get_manage_plugin_keyboard(plugin_id, True)
    await callback.message.edit_reply_markup(reply_markup=keyboard)


@router.callback_query(F.data.startswith("unarchive_"))
async def profile_unarchive_plugin(callback: CallbackQuery):
    """Возврат плагина из архива"""
    plugin_id = int(callback.data.replace("unarchive_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin or plugin['user_id'] != user_id:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    await db.update_plugin(plugin_id, archived=False)
    await callback.answer(f"Плагин '{plugin['name']}' возвращен из архива.")
    
    # Обновляем клавиатуру
    from keyboards import get_manage_plugin_keyboard
    keyboard = get_manage_plugin_keyboard(plugin_id, False)
    await callback.message.edit_reply_markup(reply_markup=keyboard)


@router.callback_query(F.data.startswith("delete_"))
async def profile_delete_plugin(callback: CallbackQuery):
    """Удаление плагина"""
    plugin_id = int(callback.data.replace("delete_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin or plugin['user_id'] != user_id:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    # TODO: Реализовать удаление с подтверждением
    await callback.answer("Функция удаления в разработке.", show_alert=True)


@router.callback_query(F.data.startswith("update_"))
async def profile_update_plugin(callback: CallbackQuery, state: FSMContext):
    """Обновление плагина"""
    plugin_id = int(callback.data.replace("update_", ""))
    user_id = callback.from_user.id
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin or plugin['user_id'] != user_id:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    from keyboards import BACK_TO_MENU_KB
    from states import PluginUpdateStates
    
    await state.set_state(PluginUpdateStates.waiting_file)
    await state.update_data(update_plugin_id=plugin_id)
    
    await callback.message.answer(
        f"🔄 <b>Обновление плагина:</b> {plugin['name']}\n\n"
        "Отправьте новый файл плагина:",
        reply_markup=BACK_TO_MENU_KB
    )
    await callback.answer()


@router.message(PluginUpdateStates.waiting_file)
async def profile_update_receive_file(message: Message, state: FSMContext):
    """Получение нового файла плагина"""
    data = await state.get_data()
    plugin_id = data['update_plugin_id']
    
    file_id = message.document.file_id
    file_name = message.document.file_name
    
    await state.update_data(file_id=file_id, file_name=file_name)
    await state.set_state(PluginUpdateStates.waiting_description)
    
    await message.answer(
        "✅ Файл получен!\n\n"
        "Теперь отправьте описание обновления:",
        reply_markup=BACK_TO_MENU_KB
    )


@router.message(PluginUpdateStates.waiting_description)
async def profile_update_receive_description(message: Message, state: FSMContext):
    """Получение описания обновления"""
    data = await state.get_data()
    plugin_id = data['update_plugin_id']
    file_id = data['file_id']
    
    description = message.text.strip()
    
    # Обновляем плагин
    await db.update_plugin(plugin_id, file_id=file_id, updated_at='now')
    
    # Получаем подписчиков и отправляем уведомление
    subscribers = await db.get_subscribers(plugin_id=plugin_id)
    plugin = await db.get_plugin(plugin_id)
    
    # Импортируем бота из main
    from main import bot
    
    for subscriber_id in subscribers:
        try:
            await bot.send_message(
                subscriber_id,
                f"📢 <b>Плагин обновлен!</b>\n\n"
                f"📦 <b>{plugin['name']}</b>\n\n"
                f"📝 <b>Что нового:</b>\n{description}\n\n"
                f"👤 Автор: {plugin['display_name']}",
                reply_markup=kb.BACK_TO_PLUGIN_KB(plugin_id)
            )
        except Exception:
            pass
        await asyncio.sleep(0.1)
    
    await state.clear()
    await message.answer(
        "✅ Плагин обновлен!\n\n"
        f"Уведомления отправлены {len(subscribers)} подписчикам.",
        reply_markup=get_m