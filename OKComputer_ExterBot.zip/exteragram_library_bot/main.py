import asyncio
import logging
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import BOT_TOKEN, ADMIN_GROUP_ID
from database import Database
from states import UploadStates, EditProfileStates, SearchStates, BroadcastStates, PluginUpdateStates
import keyboards as kb

# Импорт хэндлеров
from handlers.user import search, profile, subscriptions
from handlers.admin import moderation

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Инициализация
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()
db = Database()


# ===== ГЛАВНЫЙ ОБРАБОТЧИК /START =====
@dp.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """Старт бота и регистрация пользователя"""
    await state.clear()
    
    # Добавляем пользователя в БД
    user_id = message.from_user.id
    username = message.from_user.username or ""
    display_name = message.from_user.full_name or username or f"User{user_id}"
    
    await db.add_user(user_id, username, display_name)
    
    await message.answer(
        f"👋 Привет, <b>{display_name}</b>!\n\n"
        "Добро пожаловать в библиотеку плагинов Exteragram!\n\n"
        "Здесь ты можешь:\n"
        "• 🔍 Найти нужные плагины\n"
        "• 📤 Загрузить свои плагины\n"
        "• ⭐ Подписаться на авторов\n"
        "• 📂 Исследовать по категориям\n\n"
        "Используй клавиатуру ниже для навигации!",
        reply_markup=kb.get_main_menu()
    )


# ===== ОБРАБОТЧИКИ ГЛАВНОГО МЕНЮ =====

@dp.message(F.text == "🔍 Найти")
async def menu_search(message: Message, state: FSMContext):
    """Начало поиска"""
    await state.set_state(SearchStates.waiting_query)
    await message.answer(
        "🔍 Введите название, автора или просто опишите плагин - я найду самый подходящий!\n\n"
        "Можно искать по тегам, описанию или даже части названия.",
        reply_markup=kb.get_cancel_menu()
    )


@dp.message(F.text == "📤 Загрузить")
async def menu_upload(message: Message, state: FSMContext):
    """Начало загрузки плагина"""
    user = await db.get_user(message.from_user.id)
    if not user or not user.get('display_name'):
        await message.answer(
            "⚠️ Для загрузки плагинов нужно сначала заполнить профиль.\n"
            "Нажмите '👤 Мой профиль' -> '✏️ Изменить профиль'"
        )
        return
    
    await state.set_state(UploadStates.waiting_file)
    await state.update_data(upload_step=1)
    await message.answer(
        "[1/5] 📎 Пожалуйста, загрузите файл плагина.\n\n"
        "Файл будет отправлен на модерацию. Если хотите заменить файл - просто отправьте другой.",
        reply_markup=kb.get_cancel_menu()
    )


@dp.message(F.text == "🔥 Популярное")
async def menu_popular(message: Message):
    """Популярные плагины"""
    plugins = await db.get_popular_plugins(limit=10)
    if not plugins:
        await message.answer("Пока нет популярных плагинов.", reply_markup=kb.get_main_menu())
        return
    
    # Формируем список с кнопками
    plugin_list = [(p['plugin_id'], p['name']) for p in plugins]
    keyboard = kb.get_search_results_plugins(plugin_list)
    
    text = "🔥 <b>Популярные плагины:</b>\n\n"
    for i, plugin in enumerate(plugins, 1):
        status_emoji = {"development": "🔧", "updates": "🔄", "completed": "✅"}.get(plugin['status'], "")
        text += f"{i}. <b>{plugin['name']}</b> {status_emoji}\n"
        text += f"   👤 {plugin['display_name']}\n"
        text += f"   ⬇️ {plugin['downloads']} | ⭐ {plugin['rating']:.1f}\n\n"
    
    await message.answer(text, reply_markup=keyboard)


@dp.message(F.text == "📂 Категории")
async def menu_categories(message: Message):
    """Категории плагинов"""
    await message.answer(
        "📂 <b>Выберите категорию:</b>",
        reply_markup=kb.get_categories_keyboard()
    )


@dp.message(F.text == "⭐ Подписки")
async def menu_subscriptions(message: Message):
    """Мои подписки"""
    user_id = message.from_user.id
    
    # Получаем подписки на авторов
    author_subs = await db.get_user_subscriptions_on_authors(user_id)
    plugin_subs = await db.get_user_subscriptions_on_plugins(user_id)
    
    if not author_subs and not plugin_subs:
        await message.answer(
            "У вас пока нет подписок.\n\n"
            "Подписывайтесь на авторов и плагины, чтобы получать уведомления об обновлениях!",
            reply_markup=kb.get_main_menu()
        )
        return
    
    # Формируем список подписок
    subscriptions = []
    for author in author_subs:
        subscriptions.append(('author', author['user_id'], author['display_name']))
    for plugin in plugin_subs:
        subscriptions.append(('plugin', plugin['plugin_id'], plugin['name']))
    
    keyboard = kb.get_subscriptions_list(subscriptions)
    
    text = "⭐ <b>Ваши подписки:</b>\n\n"
    if author_subs:
        text += "👤 <b>Авторы:</b>\n"
        for author in author_subs:
            text += f"• {author['display_name']}\n"
    if plugin_subs:
        text += "\n📦 <b>Плагины:</b>\n"
        for plugin in plugin_subs:
            text += f"• {plugin['name']}\n"
    
    await message.answer(text, reply_markup=keyboard)


@dp.message(F.text == "👤 Мой профиль")
async def menu_profile(message: Message):
    """Мой профиль"""
    user_id = message.from_user.id
    user = await db.get_user(user_id)
    stats = await db.get_user_stats(user_id)
    
    is_author = stats['plugin_count'] > 0
    
    # Формируем текст профиля
    text = f"👤 <b>Ваш профиль:</b>\n\n"
    text += f"📝 <b>Никнейм:</b> {user['display_name']}\n"
    
    if user.get('username'):
        text += f"🔗 <b>Юзернейм:</b> @{user['username']}\n"
    
    text += f"\n📊 <b>Статистика:</b>\n"
    text += f"👥 Подписчиков: {stats['subscriber_count']}\n"
    
    if is_author:
        text += f"\n📦 <b>Ваши плагины:</b>\n"
        text += f"   Всего: {stats['plugin_count']}\n"
        text += f"   ⬇️ Скачиваний: {stats['total_downloads']}\n"
        text += f"   👁 Просмотров: {stats['total_views']}\n"
        text += f"   ⭐ Средний рейтинг: {stats['avg_rating']:.1f}\n"
    
    keyboard = kb.get_my_profile_keyboard(is_author)
    
    # Если есть баннер - отправляем с баннером
    # banner_file_id = user.get('banner_file_id')
    # if banner_file_id:
    #     await message.answer_photo(banner_file_id, caption=text, reply_markup=keyboard)
    # else:
    await message.answer(text, reply_markup=keyboard)


# ===== ОБРАБОТЧИКИ ОТМЕНЫ =====

@dp.message(F.text == "❌ Отмена")
async def cmd_cancel(message: Message, state: FSMContext):
    """Отмена текущего действия"""
    await state.clear()
    await message.answer("Действие отменено.", reply_markup=kb.get_main_menu())


@dp.message(F.text == "⬅️ Назад")
async def cmd_back(message: Message, state: FSMContext):
    """Назад (зависит от состояния)"""
    current_state = await state.get_state()
    
    if current_state == UploadStates.waiting_file.state:
        await state.clear()
        await message.answer("Отмена загрузки.", reply_markup=kb.get_main_menu())
    elif current_state == UploadStates.waiting_name.state:
        await state.set_state(UploadStates.waiting_file)
        await message.answer("Возврат к загрузке файла.", reply_markup=kb.get_cancel_menu())
    elif current_state == UploadStates.waiting_category.state:
        await state.set_state(UploadStates.waiting_name)
        await message.answer("Возврат к вводу названия.", reply_markup=kb.get_cancel_menu())
    elif current_state == UploadStates.waiting_status.state:
        await state.set_state(UploadStates.waiting_category)
        await message.answer("Возврат к выбору категории.", reply_markup=kb.get_back_menu())
    elif current_state == UploadStates.waiting_tags.state:
        await state.set_state(UploadStates.waiting_status)
        await message.answer("Возврат к выбору статуса.", reply_markup=kb.get_back_menu())
    elif current_state in [EditProfileStates.waiting_nickname.state, 
                          EditProfileStates.waiting_username.state,
                          EditProfileStates.waiting_banner.state]:
        await state.clear()
        await message.answer("Отмена редактирования.", reply_markup=kb.get_main_menu())
    else:
        await state.clear()
        await message.answer("Главное меню.", reply_markup=kb.get_main_menu())


# ===== ОБРАБОТЧИКИ CALLBACK QUERY (основные) =====

@dp.callback_query(F.data == "main_menu")
async def callback_main_menu(callback: CallbackQuery, state: FSMContext):
    """Возврат в главное меню"""
    await state.clear()
    await callback.message.edit_text("Главное меню.", reply_markup=None)
    await callback.answer()


@dp.callback_query(F.data.startswith("category_"))
async def callback_category(callback: CallbackQuery):
    """Выбор категории"""
    category = callback.data.replace("category_", "")
    plugins = await db.get_plugins_by_category(category, limit=20)
    
    if not plugins:
        await callback.answer("В этой категории пока нет плагинов.", show_alert=True)
        return
    
    # Формируем список
    plugin_list = [(p['plugin_id'], p['name']) for p in plugins]
    keyboard = kb.get_search_results_plugins(plugin_list)
    
    category_names = dict(kb.CATEGORIES)
    await callback.message.edit_text(
        f"📂 <b>{category_names.get(category, category)}</b>\n\n"
        f"Найдено плагинов: {len(plugins)}",
        reply_markup=keyboard
    )
    await callback.answer()


# ===== ЗАГРУЗКА ПЛАГИНОВ (основная логика в handlers/user/upload.py) =====

@dp.message(F.document, UploadStates.waiting_file)
async def upload_receive_file(message: Message, state: FSMContext):
    """Получение файла плагина"""
    file_id = message.document.file_id
    file_name = message.document.file_name
    
    await state.update_data(
        file_id=file_id,
        file_name=file_name,
        upload_step=2
    )
    
    await state.set_state(UploadStates.waiting_name)
    await message.answer(
        "[2/5] ✅ Файл получен!\n\n"
        "Теперь отправьте <b>название плагина</b> и, при желании, прикрепите <b>фото для обложки</b>.",
        reply_markup=kb.get_upload_continue_keyboard()
    )


# ===== ПРОФИЛЬ (основная логика в handlers/user/profile.py) =====

@dp.callback_query(F.data == "edit_profile")
async def callback_edit_profile(callback: CallbackQuery):
    """Редактирование профиля"""
    await callback.message.edit_text(
        "Что хотите изменить?",
        reply_markup=kb.get_edit_profile_keyboard()
    )
    await callback.answer()


@dp.callback_query(F.data == "edit_nickname")
async def callback_edit_nickname(callback: CallbackQuery, state: FSMContext):
    """Изменение никнейма"""
    await state.set_state(EditProfileStates.waiting_nickname)
    await callback.message.edit_text(
        "📝 Отправьте новый никнейм:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@dp.message(EditProfileStates.waiting_nickname)
async def profile_receive_nickname(message: Message, state: FSMContext):
    """Получение нового никнейма"""
    nickname = message.text.strip()
    if len(nickname) < 2 or len(nickname) > 50:
        await message.answer("Никнейм должен быть от 2 до 50 символов.", reply_markup=kb.get_cancel_menu())
        return
    
    await db.update_user(message.from_user.id, display_name=nickname)
    await state.clear()
    await message.answer("✅ Никнейм обновлен!", reply_markup=kb.get_main_menu())


@dp.callback_query(F.data == "edit_username")
async def callback_edit_username(callback: CallbackQuery, state: FSMContext):
    """Изменение юзернейма"""
    await state.set_state(EditProfileStates.waiting_username)
    await callback.message.edit_text(
        "🔗 Отправьте новый юзернейм (без @) или отправьте '-' чтобы удалить:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@dp.message(EditProfileStates.waiting_username)
async def profile_receive_username(message: Message, state: FSMContext):
    """Получение нового юзернейма"""
    username = message.text.strip()
    if username == "-":
        username = None
    elif username and (len(username) < 3 or not username.replace('_', '').isalnum()):
        await message.answer("Некорректный юзернейм.", reply_markup=kb.get_cancel_menu())
        return
    
    await db.update_user(message.from_user.id, username=username)
    await state.clear()
    await message.answer("✅ Юзернейм обновлен!", reply_markup=kb.get_main_menu())


# ===== РАССЫЛКА ПОДПИСЧИКАМ =====

@dp.callback_query(F.data == "broadcast_to_subs")
async def callback_broadcast(callback: CallbackQuery, state: FSMContext):
    """Начало рассылки подписчикам"""
    user_id = callback.from_user.id
    stats = await db.get_user_stats(user_id)
    
    if stats['subscriber_count'] == 0:
        await callback.answer("У вас нет подписчиков.", show_alert=True)
        return
    
    await state.set_state(BroadcastStates.waiting_message)
    await callback.message.edit_text(
        f"✉️ У вас {stats['subscriber_count']} подписчиков.\n\n"
        "Отправьте сообщение для рассылки:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@dp.message(BroadcastStates.waiting_message)
async def broadcast_receive_message(message: Message, state: FSMContext):
    """Получение сообщения для рассылки"""
    user_id = message.from_user.id
    subscribers = await db.get_subscribers(target_user_id=user_id)
    
    if not subscribers:
        await message.answer("У вас больше нет подписчиков.", reply_markup=kb.get_main_menu())
        await state.clear()
        return
    
    # Отправляем сообщение подписчикам
    sent = 0
    failed = 0
    for subscriber_id in subscribers:
        try:
            await bot.copy_message(
                chat_id=subscriber_id,
                from_chat_id=message.chat.id,
                message_id=message.message_id,
                caption=f"📢 <b>Новое сообщение от {message.from_user.full_name}</b>"
            )
            sent += 1
        except Exception as e:
            logger.error(f"Failed to send broadcast to {subscriber_id}: {e}")
            failed += 1
        await asyncio.sleep(0.1)  # Задержка чтобы не попасть в лимиты
    
    await state.clear()
    await message.answer(
        f"✅ Рассылка завершена!\n"
        f"Отправлено: {sent}\n"
        f"Не удалось: {failed}",
        reply_markup=kb.get_main_menu()
    )


# ===== ГЛАВНАЯ ФУНКЦИЯ =====

async def main():
    """Запуск бота"""
    # Инициализация БД
    await db.initialize()
    logger.info("Database initialized")
    
    # Регистрация хэндлеров из других модулей
    dp.include_router(search.router)
    dp.include_router(profile.router)
    dp.include_router(subscriptions.router)
    dp.include_router(moderation.router)
    
    logger.info("Starting bot...")
    
    # Запуск polling
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Bot crashed: {e}", exc_info=True)