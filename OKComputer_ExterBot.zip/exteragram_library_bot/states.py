from aiogram.fsm.state import StatesGroup, State


class UploadStates(StatesGroup):
    """Состояния загрузки плагина"""
    waiting_file = State()  # Ожидание файла плагина
    waiting_name = State()  # Ожидание названия и обложки
    waiting_category = State()  # Ожидание выбора категории
    waiting_status = State()  # Ожидание выбора статуса
    waiting_tags = State()  # Ожидание тегов
    confirm_data = State()  # Подтверждение данных


class EditProfileStates(StatesGroup):
    """Состояния редактирования профиля"""
    waiting_nickname = State()  # Ожидание никнейма
    waiting_username = State()  # Ожидание юзернейма
    waiting_banner = State()  # Ожидание баннера


class BroadcastStates(StatesGroup):
    """Состояния рассылки"""
    waiting_message = State()  # Ожидание сообщения для подписчиков


class SearchStates(StatesGroup):
    """Состояния поиска"""
    waiting_query = State()  # Ожидание поискового запроса


class PluginUpdateStates(StatesGroup):
    """Состояния обновления плагина"""
    waiting_file = State()  # Ожидание нового файла
    waiting_description = State()  # Ожидание описания обновления