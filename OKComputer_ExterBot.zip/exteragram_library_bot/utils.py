import re
from typing import List, Tuple
from difflib import SequenceMatcher


def similarity(a: str, b: str) -> float:
    """Вычисляет сходство двух строк (0-1)"""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def extract_tags(text: str) -> List[str]:
    """Извлекает теги из текста"""
    # Убираем лишние пробелы, разделяем по пробелам
    tags = re.split(r'\s+', text.strip())
    # Фильтруем пустые и слишком длинные теги
    return [tag for tag in tags if len(tag) >= 2 and len(tag) <= 30]


def format_file_size(size_bytes: int) -> str:
    """Форматирует размер файла"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"


def escape_markdown(text: str) -> str:
    """Экранирует специальные символы Markdown"""
    chars = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
    for char in chars:
        text = text.replace(char, f'\\{char}')
    return text


def validate_username(username: str) -> bool:
    """Проверяет корректность юзернейма"""
    if not username:
        return False
    if len(username) < 3 or len(username) > 32:
        return False
    return bool(re.match(r'^[a-zA-Z0-9_]+$', username))


def validate_plugin_name(name: str) -> bool:
    """Проверяет корректность названия плагина"""
    if not name:
        return False
    if len(name) < 3 or len(name) > 100:
        return False
    return True


def validate_description(description: str) -> bool:
    """Проверяет корректность описания"""
    if not description:
        return False
    if len(description) < 10 or len(description) > 2000:
        return False
    return True


def generate_search_score(query: str, plugin_name: str, plugin_description: str, 
                          plugin_tags: str, author_name: str, author_username: str) -> float:
    """Генерирует оценку релевантности для поиска"""
    query_lower = query.lower()
    
    score = 0.0
    
    # Совпадение в названии (высший приоритет)
    if query_lower in plugin_name.lower():
        score += 10.0
        if plugin_name.lower().startswith(query_lower):
            score += 5.0
    
    # Совпадение в описании
    if query_lower in plugin_description.lower():
        score += 5.0
    
    # Совпадение в тегах
    if plugin_tags and query_lower in plugin_tags.lower():
        score += 3.0
    
    # Совпадение в имени автора
    if query_lower in author_name.lower():
        score += 2.0
    
    # Совпадение в юзернейме автора
    if author_username and query_lower in author_username.lower():
        score += 2.0
    
    # Косвенное сходство
    name_similarity = similarity(query_lower, plugin_name.lower())
    desc_similarity = similarity(query_lower, plugin_description.lower())
    
    score += name_similarity * 3
    score += desc_similarity * 2
    
    return score


def truncate_text(text: str, max_length: int = 100) -> str:
    """Обрезает текст до указанной длины"""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


def format_rating(rating: float, count: int) -> str:
    """Форматирует рейтинг для отображения"""
    stars = "⭐" * int(round(rating))
    return f"{stars} {rating:.1f} ({count})"


def is_admin(user_id: int, admin_list: List[int]) -> bool:
    """Проверяет, является ли пользователь админом"""
    return user_id in admin_list


def clean_filename(filename: str) -> str:
    """Очищает имя файла от опасных символов"""
    # Заменяем опасные символы
    dangerous_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
    for char in dangerous_chars:
        filename = filename.replace(char, '_')
    return filename


def get_mime_type(filename: str) -> str:
    """Определяет MIME тип по расширению файла"""
    ext = filename.lower().split('.')[-1] if '.' in filename else ''
    
    mime_types = {
        'py': 'text/x-python',
        'js': 'application/javascript',
        'json': 'application/json',
        'txt': 'text/plain',
        'md': 'text/markdown',
        'zip': 'application/zip',
        'rar': 'application/vnd.rar',
        '7z': 'application/x-7z-compressed',
        'tar': 'application/x-tar',
        'gz': 'application/gzip',
    }
    
    return mime_types.get(ext, 'application/octet-stream')


def is_safe_file(filename: str, allowed_extensions: List[str] = None) -> bool:
    """Проверяет, безопасен ли файл для загрузки"""
    if allowed_extensions is None:
        allowed_extensions = ['.py', '.js', '.json', '.txt', '.md', '.zip', '.rar', '.7z']
    
    ext = '.' + filename.lower().split('.')[-1] if '.' in filename else ''
    return ext in allowed_extensions