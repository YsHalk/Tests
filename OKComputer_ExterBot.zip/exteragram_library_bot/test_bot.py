#!/usr/bin/env python3
"""
Тестовый скрипт для проверки бота на ошибки
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Проверка импортов"""
    print("🔍 Проверка импортов...")
    
    try:
        import config
        print("✅ config.py - OK")
    except Exception as e:
        print(f"❌ config.py - Ошибка: {e}")
        return False
    
    try:
        import database
        print("✅ database.py - OK")
    except Exception as e:
        print(f"❌ database.py - Ошибка: {e}")
        return False
    
    try:
        import keyboards
        print("✅ keyboards.py - OK")
    except Exception as e:
        print(f"❌ keyboards.py - Ошибка: {e}")
        return False
    
    try:
        import states
        print("✅ states.py - OK")
    except Exception as e:
        print(f"❌ states.py - Ошибка: {e}")
        return False
    
    try:
        import utils
        print("✅ utils.py - OK")
    except Exception as e:
        print(f"❌ utils.py - Ошибка: {e}")
        return False
    
    return True

def test_database():
    """Проверка базы данных"""
    print("\n🔍 Проверка базы данных...")
    
    try:
        from database import Database
        db = Database()
        print("✅ Database инициализирован - OK")
        
        # Проверяем SQL синтаксис
        import sqlite3
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Проверяем таблицу users
        cursor.execute("""
            CREATE TABLE users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                display_name TEXT NOT NULL,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("✅ SQL таблицы users - OK")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Database - Ошибка: {e}")
        return False
    
    return True

def test_keyboards():
    """Проверка клавиатур"""
    print("\n🔍 Проверка клавиатур...")
    
    try:
        import keyboards as kb
        
        # Проверяем главное меню
        menu = kb.get_main_menu()
        print("✅ Главное меню - OK")
        
        # Проверяем категории
        cat_kb = kb.get_categories_keyboard()
        print("✅ Категории - OK")
        
        # Проверяем статусы
        status_kb = kb.get_statuses_keyboard()
        print("✅ Статусы - OK")
        
    except Exception as e:
        print(f"❌ Keyboards - Ошибка: {e}")
        return False
    
    return True

def test_config():
    """Проверка конфигурации"""
    print("\n🔍 Проверка конфигурации...")
    
    try:
        from config import CATEGORIES, STATUSES, DB_PATH
        
        print(f"✅ Категории: {len(CATEGORIES)} шт")
        print(f"✅ Статусы: {len(STATUSES)} шт")
        print(f"✅ Путь к БД: {DB_PATH}")
        
        # Проверяем что путь существует
        from pathlib import Path
        db_dir = Path(DB_PATH).parent
        print(f"✅ Директория БД: {db_dir}")
        
    except Exception as e:
        print(f"❌ Config - Ошибка: {e}")
        return False
    
    return True

def main():
    """Главная функция тестирования"""
    print("🚀 Запуск тестов бота...\n")
    
    all_passed = True
    
    # Тест импортов
    if not test_imports():
        all_passed = False
    
    # Тест конфигурации
    if not test_config():
        all_passed = False
    
    # Тест базы данных
    if not test_database():
        all_passed = False
    
    # Тест клавиатур
    if not test_keyboards():
        all_passed = False
    
    print("\n" + "="*50)
    
    if all_passed:
        print("✅ Все тесты пройдены!")
        print("\n📋 Что дальше:")
        print("1. Установите зависимости: pip install -r requirements.txt")
        print("2. Создайте файл .env с BOT_TOKEN")
        print("3. Запустите бота: python main.py")
        print("\n⚠️  ВАЖНО:")
        print("- Создайте административную группу в Telegram")
        print("- Добавьте бота в группу как администратора")
        print("- Создайте 3 темы (topics) в группе")
        print("- Укажите ID группы и тем в .env файле")
    else:
        print("❌ Обнаружены ошибки!")
        print("\nИсправьте ошибки выше и запустите тест снова.")
        sys.exit(1)

if __name__ == "__main__":
    main()