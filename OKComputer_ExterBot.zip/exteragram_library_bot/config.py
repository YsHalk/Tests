import os
from pathlib import Path

# Bot configuration
BOT_TOKEN = os.getenv('BOT_TOKEN', 'YOUR_BOT_TOKEN_HERE')
ADMIN_GROUP_ID = int(os.getenv('ADMIN_GROUP_ID', '-1001234567890'))  # Группа администраторов

# Topic IDs in admin group (нужно создать темы и указать их ID)
TOPIC_REQUESTS = int(os.getenv('TOPIC_REQUESTS', '1'))  # Тема для заявок
TOPIC_SECURITY = int(os.getenv('TOPIC_SECURITY', '2'))  # Тема для безопасности
TOPIC_NOTIFICATIONS = int(os.getenv('TOPIC_NOTIFICATIONS', '3'))  # Тема для уведомлений

# Database
DATA_DIR = Path(__file__).parent / 'data'
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = DATA_DIR / 'bot.db'

# File storage
FILES_DIR = DATA_DIR / 'files'
FILES_DIR.mkdir(exist_ok=True)

# Plugin categories
CATEGORIES = [
    ('tools', '🔧 Инструменты'),
    ('fun', '🎉 Веселье'),
    ('bots', '🤖 Боты'),
    ('security', '🔒 Безопасность'),
    ('integrations', '🔗 Интеграции'),
    ('other', '📁 Другое')
]

# Plugin statuses
STATUSES = {
    'development': '🔧 В работе',
    'updates': '🔄 Возможны обновления',
    'completed': '✅ Завершено',
    'archived': '📦 В архиве'
}

# Rating
MIN_RATING = 1
MAX_RATING = 5

# Search settings
MAX_SEARCH_RESULTS = 10
SIMILARITY_THRESHOLD = 0.3