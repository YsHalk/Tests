from typing import List, Dict, Any
from rapidfuzz import fuzz
from database import db
import re


class SearchEngine:
    """Улучшенный поисковый движок"""
    
    @staticmethod
    async def search(query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Улучшенный поиск с ранжированием по релевантности
        
        Ищет по:
        - Названию плагина
        - Описанию
        - Тегам
        - Никнейму автора
        - Юз тегу автора
        """
        # Получаем все плагины из базы
        all_plugins = await db.search_plugins(query)
        
        if not all_plugins:
            return []
        
        # Ранжируем результаты
        scored_plugins = []
        query_lower = query.lower()
        
        for plugin in all_plugins:
            score = await SearchEngine._calculate_score(plugin, query_lower)
            scored_plugins.append((plugin, score))
        
        # Сортируем по релевантности
        scored_plugins.sort(key=lambda x: x[1], reverse=True)
        
        # Возвращаем топ результаты
        return [plugin for plugin, score in scored_plugins[:limit]]
    
    @staticmethod
    async def _calculate_score(plugin: Dict[str, Any], query: str) -> float:
        """Рассчитать релевантность плагина запросу"""
        scores = []
        
        # 1. Точное совпадение в названии (вес 1.0)
        title_score = SearchEngine._exact_match_score(plugin['title'], query)
        scores.append((title_score, 1.0))
        
        # 2. Частичное совпадение в названии (вес 0.8)
        if title_score < 100:
            partial_title = fuzz.partial_ratio(plugin['title'].lower(), query)
            scores.append((partial_title, 0.8))
        
        # 3. Совпадение в описании (вес 0.6)
        desc_score = fuzz.partial_ratio(plugin['description'].lower(), query)
        scores.append((desc_score, 0.6))
        
        # 4. Совпадение в тегах (вес 0.7)
        if plugin['tags']:
            tags_score = fuzz.partial_ratio(plugin['tags'].lower(), query)
            scores.append((tags_score, 0.7))
        
        # 5. Совпадение по автору (вес 0.5)
        author = await db.get_user(plugin['user_id'])
        if author:
            # Никнейм
            nickname_score = fuzz.partial_ratio(author['nickname'].lower(), query)
            scores.append((nickname_score, 0.5))
            
            # Юз тег
            if author['user_tag']:
                usertag_score = fuzz.partial_ratio(author['user_tag'].lower(), query)
                scores.append((usertag_score, 0.5))
        
        # 6. Словарный поиск в описании (вес 0.4)
        words = query.split()
        if len(words) > 1:
            word_match_score = SearchEngine._word_match_score(plugin['description'], words)
            scores.append((word_match_score, 0.4))
        
        # Суммируем взвешенные оценки
        total_score = sum(score * weight for score, weight in scores)
        total_weight = sum(weight for _, weight in scores)
        
        return total_score / total_weight if total_weight > 0 else 0
    
    @staticmethod
    def _exact_match_score(text: str, query: str) -> float:
        """Оценка точного совпадения"""
        text_lower = text.lower()
        
        # Полное совпадение
        if text_lower == query:
            return 100
        
        # Начинается с запроса
        if text_lower.startswith(query):
            return 90
        
        # Содержит запрос как подстроку
        if query in text_lower:
            return 70
        
        return 0
    
    @staticmethod
    def _word_match_score(text: str, words: list) -> float:
        """Оценка совпадения по словам"""
        text_lower = text.lower()
        matched_words = sum(1 for word in words if word in text_lower)
        return (matched_words / len(words)) * 100 if words else 0
    
    @staticmethod
    async def search_by_category(category: str) -> List[Dict[str, Any]]:
        """Поиск по категории"""
        return await db.get_plugins_by_category(category)
    
    @staticmethod
    async def get_popular(limit: int = 10) -> List[Dict[str, Any]]:
        """Получение популярных плагинов"""
        return await db.get_popular_plugins(limit)
    
    @staticmethod
    async def get_recommendations(user_id: int, limit: int = 5) -> List[Dict[str, Any]]:
        """Получить рекомендации на основе подписок пользователя"""
        # Получаем подписки пользователя
        subscriptions = await db.get_user_subscriptions(user_id)
        
        if not subscriptions:
            # Если нет подписок - возвращаем популярные
            return await SearchEngine.get_popular(limit)
        
        # Получаем категории подписок
        categories = {}
        for plugin in subscriptions:
            cat = plugin['category']
            categories[cat] = categories.get(cat, 0) + 1
        
        # Находим наиболее интересные категории
        top_categories = sorted(categories.items(), key=lambda x: x[1], reverse=True)[:3]
        
        # Ищем плагины из этих категорий, на которые пользователь не подписан
        recommendations = []
        for category, _ in top_categories:
            if len(recommendations) >= limit:
                break
            
            category_plugins = await db.get_plugins_by_category(category)
            for plugin in category_plugins:
                if plugin['plugin_id'] not in [p['plugin_id'] for p in subscriptions]:
                    if plugin not in recommendations:
                        recommendations.append(plugin)
                        if len(recommendations) >= limit:
                            break
        
        return recommendations