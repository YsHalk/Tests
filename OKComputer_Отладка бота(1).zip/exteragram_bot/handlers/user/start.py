from aiogram import Router, types, F
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from keyboards.user_kb import UserKeyboards
from database import db
from utils.states import UserStates
import logging

logger = logging.getLogger(__name__)


async def cmd_start(message: types.Message, state: FSMContext):
    """Команда /start - начало работы с ботом"""
    await state.clear()
    
    user_id = message.from_user.id
    user = await db.get_user(user_id)
    
    if not user:
        # Новый пользователь - начинаем регистрацию
        await message.answer(
            "🎉 <b>Добро пожаловать в Exteragram Plugin Library!</b>\n\n"
            "Для работы с ботом нужно пройти небольшую регистрацию.\n\n"
            "📋 <b>Шаг 1/2</b>\n"
            "Придумайте и введите ваш никнейм:",
            parse_mode="HTML"
        )
        await state.set_state(UserStates.waiting_nickname)
    else:
        # Существующий пользователь
        await message.answer(
            f"👋 <b>Привет, {user['nickname']}!</b>\n\n"
            "Выберите действие из меню:",
            parse_mode="HTML",
            reply_markup=UserKeyboards.main_menu()
        )


async def process_nickname(message: types.Message, state: FSMContext):
    """Обработка никнейма при регистрации"""
    nickname = message.text.strip()
    
    if len(nickname) < 2 or len(nickname) > 50:
        await message.answer(
            "❌ Никнейм должен быть от 2 до 50 символов.\n\n"
            "Попробуйте еще раз:"
        )
        return
    
    # Сохраняем никнейм и переходим к следующему шагу
    await state.update_data(nickname=nickname)
    
    await message.answer(
        "📋 <b>Шаг 2/2</b>\n\n"
        "Теперь введите ваш юз тег (без @):\n\n"
        "<i>Например: myusername</i>",
        parse_mode="HTML"
    )
    await state.set_state(UserStates.waiting_usertag)


async def process_usertag(message: types.Message, state: FSMContext):
    """Обработка юз тега при регистрации"""
    usertag = message.text.strip().lstrip('@')
    
    if len(usertag) < 3 or len(usertag) > 32:
        await message.answer(
            "❌ Юз тег должен быть от 3 до 32 символов.\n\n"
            "Попробуйте еще раз:"
        )
        return
    
    # Получаем сохраненные данные
    data = await state.get_data()
    nickname = data['nickname']
    
    # Создаем пользователя
    success = await db.create_user(
        user_id=message.from_user.id,
        username=message.from_user.username,
        nickname=nickname,
        user_tag=usertag
    )
    
    if success:
        await message.answer(
            f"✅ <b>Регистрация завершена!</b>\n\n"
            f"Никнейм: <b>{nickname}</b>\n"
            f"Юз тег: <b>@{usertag}</b>\n\n"
            f"Добро пожаловать в библиотеку плагинов! 🎉",
            parse_mode="HTML",
            reply_markup=UserKeyboards.main_menu()
        )
        await state.clear()
    else:
        await message.answer(
            "❌ Произошла ошибка при регистрации. Попробуйте еще раз /start",
            parse_mode="HTML"
        )


async def cmd_help(message: types.Message):
    """Команда /help - помощь"""
    help_text = (
        "📚 <b>Помощь по боту</b>\n\n"
        "<b>Основные функции:</b>\n"
        "🔍 <b>Найти</b> - поиск плагинов по названию, автору, тегам\n"
        "📤 <b>Загрузить</b> - загрузить свой плагин на модерацию\n"
        "🔥 <b>Популярное</b> - самые популярные плагины\n"
        "📂 <b>Категории</b> - плагины по категориям\n"
        "❤️ <b>Подписки</b> - ваши подписки на плагины\n"
        "👤 <b>Мой профиль</b> - управление профилем и плагинами\n\n"
        "<b>Поддержка:</b> @your_support_username"
    )
    
    await message.answer(help_text, parse_mode="HTML")


async def cmd_menu(message: types.Message, state: FSMContext):
    """Команда для возврата в меню"""
    await state.clear()
    await message.answer(
        "🏠 Главное меню",
        reply_markup=UserKeyboards.main_menu()
    )


def register_start_handlers(router: Router):
    """Регистрация стартовых обработчиков"""
    router.message.register(cmd_start, CommandStart())
    router.message.register(cmd_help, Command("help"))
    router.message.register(cmd_menu, Command("menu"))
    
    # Регистрация
    router.message.register(process_nickname, UserStates.waiting_nickname)
    router.message.register(process_usertag, UserStates.waiting_usertag)