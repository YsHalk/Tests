from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from keyboards.user_kb import UserKeyboards
from utils.states import UserStates
from database import db
import logging

logger = logging.getLogger(__name__)


async def show_profile(message: types.Message):
    """Показать профиль пользователя"""
    user_id = message.from_user.id
    user = await db.get_user(user_id)
    
    if not user:
        await message.answer("❌ Профиль не найден")
        return
    
    # Получаем статистику
    user_plugins = await db.get_plugins_by_user(user_id, include_archived=False)
    subscriptions = await db.get_user_subscriptions(user_id)
    
    profile_text = (
        f"👤 <b>{user['nickname']}</b>\n"
        f"🔗 @{user['user_tag'] or 'не указан'}\n\n"
        f"📊 <b>Статистика:</b>\n"
        f"❤️ Подписчиков: <b>{user['subscribers_count']:,}</b>\n"
        f"📦 Плагинов: <b>{len(user_plugins)}</b>\n"
        f"❤️ Подписок: <b>{len(subscriptions)}</b>\n\n"
        f"📈 <b>Общая статистика плагинов:</b>\n"
        f"⬇️ Скачиваний: <b>{user['total_downloads']:,}</b>\n"
        f"👁 Просмотров: <b>{user['total_views']:,}</b>\n"
        f"⭐ Рейтинг: <b>{user['total_rating']:.1f}</b>"
    )
    
    await message.answer(
        profile_text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.profile_menu()
    )


async def edit_profile(callback: types.CallbackQuery):
    """Редактирование профиля"""
    await callback.message.edit_text(
        "✏️ <b>Что хотите изменить?</b>",
        parse_mode="HTML",
        reply_markup=UserKeyboards.edit_profile()
    )
    await callback.answer()


async def edit_nickname(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование никнейма"""
    user = await db.get_user(callback.from_user.id)
    
    await callback.message.edit_text(
        f"📝 <b>Текущий никнейм:</b> {user['nickname']}\n\n"
        "Введите новый никнейм:",
        parse_mode="HTML"
    )
    await state.set_state(UserStates.editing_nickname)
    await callback.answer()


async def process_new_nickname(message: types.Message, state: FSMContext):
    """Обработка нового никнейма"""
    nickname = message.text.strip()
    
    if len(nickname) < 2 or len(nickname) > 50:
        await message.answer(
            "❌ Никнейм должен быть от 2 до 50 символов.\n\n"
            "Попробуйте еще раз:"
        )
        return
    
    success = await db.update_user(message.from_user.id, nickname=nickname)
    
    if success:
        await message.answer(
            f"✅ Никнейм изменен на <b>{nickname}</b>!",
            parse_mode="HTML",
            reply_markup=UserKeyboards.profile_menu()
        )
        await state.clear()
    else:
        await message.answer("❌ Ошибка при изменении никнейма.")


async def edit_usertag(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование юз тега"""
    user = await db.get_user(callback.from_user.id)
    
    await callback.message.edit_text(
        f"🔗 <b>Текущий юз тег:</b> @{user['user_tag'] or 'не указан'}\n\n"
        "Введите новый юз тег (без @):",
        parse_mode="HTML"
    )
    await state.set_state(UserStates.editing_usertag)
    await callback.answer()


async def process_new_usertag(message: types.Message, state: FSMContext):
    """Обработка нового юз тега"""
    usertag = message.text.strip().lstrip('@')
    
    if len(usertag) < 3 or len(usertag) > 32:
        await message.answer(
            "❌ Юз тег должен быть от 3 до 32 символов.\n\n"
            "Попробуйте еще раз:"
        )
        return
    
    success = await db.update_user(message.from_user.id, user_tag=usertag)
    
    if success:
        await message.answer(
            f"✅ Юз тег изменен на <b>@{usertag}</b>!",
            parse_mode="HTML",
            reply_markup=UserKeyboards.profile_menu()
        )
        await state.clear()
    else:
        await message.answer("❌ Ошибка при изменении юз тега.")


async def edit_banner(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование баннера профиля"""
    await callback.message.edit_text(
        "🖼 <b>Баннер профиля</b>\n\n"
        "Отправьте фото, которое будет отображаться в вашем профиле:",
        parse_mode="HTML"
    )
    await state.set_state(UserStates.editing_banner)
    await callback.answer()


async def process_banner(message: types.Message, state: FSMContext):
    """Обработка баннера"""
    if not message.photo:
        await message.answer(
            "❌ Пожалуйста, отправьте фото."
        )
        return
    
    photo_id = message.photo[-1].file_id
    
    success = await db.update_user(message.from_user.id, banner_photo_id=photo_id)
    
    if success:
        await message.answer(
            "✅ Баннер профиля обновлен!",
            reply_markup=UserKeyboards.profile_menu()
        )
        await state.clear()
    else:
        await message.answer("❌ Ошибка при обновлении баннера.")


async def show_subscriptions(message: types.Message):
    """Показать подписки пользователя"""
    user_id = message.from_user.id
    subscriptions = await db.get_user_subscriptions(user_id)
    
    if not subscriptions:
        await message.answer(
            "❤️ У вас еще нет подписок.\n\n"
            "Найдите интересные плагины и подпишитесь!",
            parse_mode="HTML",
            reply_markup=UserKeyboards.back_to_menu()
        )
        return
    
    text = f"❤️ <b>Ваши подписки</b> ({len(subscriptions)}):\n\n"
    
    for plugin in subscriptions:
        author = await db.get_user(plugin['user_id'])
        text += f"📦 {plugin['title']} от {author['nickname']}\n"
    
    plugin_ids = [p['plugin_id'] for p in subscriptions]
    
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.search_results(plugin_ids)
    )


async def show_my_plugins(callback: types.CallbackQuery):
    """Показать плагины пользователя"""
    user_id = callback.from_user.id
    
    # Получаем все плагины включая архивные
    plugins = await db.get_plugins_by_user(user_id, include_archived=True)
    
    if not plugins:
        await callback.message.edit_text(
            "📦 У вас еще нет плагинов.\n\n"
            "Загрузите свой первый плагин!",
            parse_mode="HTML",
            reply_markup=UserKeyboards.back_to_menu()
        )
        await callback.answer()
        return
    
    # Формируем список
    text = "📋 <b>Ваши плагины</b>\n\n"
    
    active_plugins = [p for p in plugins if not p['is_archived']]
    archived_plugins = [p for p in plugins if p['is_archived']]
    
    if active_plugins:
        text += "📦 <b>Активные:</b>\n"
        for plugin in active_plugins:
            text += f"   • {plugin['title']} (#{plugin['plugin_id']})\n"
        text += "\n"
    
    if archived_plugins:
        text += "📁 <b>В архиве:</b>\n"
        for plugin in archived_plugins:
            text += f"   • {plugin['title']} (#{plugin['plugin_id']})\n"
    
    plugin_ids = [p['plugin_id'] for p in plugins]
    
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.my_plugins(plugin_ids, include_archived=True)
    )
    await callback.answer()


async def back_to_menu(callback: types.CallbackQuery, state: FSMContext):
    """Вернуться в главное меню"""
    await state.clear()
    await callback.message.answer(
        "🏠 Главное меню",
        reply_markup=UserKeyboards.main_menu()
    )
    await callback.answer()


def register_profile_handlers(router: Router):
    """Регистрация обработчиков профиля"""
    # Reply кнопки главного меню
    router.message.register(show_profile, F.text == "👤 Мой профиль")
    router.message.register(show_subscriptions, F.text == "❤️ Подписки")
    
    # Остальные обработчики
    router.callback_query.register(edit_profile, F.data == "edit_profile")
    router.callback_query.register(edit_nickname, F.data == "edit_nickname")
    router.callback_query.register(edit_usertag, F.data == "edit_usertag")
    router.callback_query.register(edit_banner, F.data == "edit_banner")
    router.callback_query.register(show_my_plugins, F.data == "my_plugins")
    
    router.message.register(process_new_nickname, UserStates.editing_nickname, F.text)
    router.message.register(process_new_usertag, UserStates.editing_usertag, F.text)
    router.message.register(process_banner, UserStates.editing_banner, F.photo)
    
    router.callback_query.register(back_to_menu, F.data == "back_main")