from aiogram import Router
from .start import register_start_handlers
from .search import register_search_handlers
from .upload import register_upload_handlers
from .profile import register_profile_handlers
from .plugins import register_plugins_handlers


def register_user_handlers(router: Router):
    """Регистрация всех обработчиков пользователя"""
    register_start_handlers(router)
    register_search_handlers(router)
    register_upload_handlers(router)
    register_profile_handlers(router)
    register_plugins_handlers(router)