from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from keyboards.user_kb import UserKeyboards
from utils.states import UserStates, UploadStates
from utils.notifications import NotificationManager
from database import db
import logging

logger = logging.getLogger(__name__)


async def download_plugin(callback: types.CallbackQuery):
    """Скачивание плагина"""
    plugin_id = int(callback.data.replace('download_', ''))
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("❌ Плагин не найден", show_alert=True)
        return
    
    # Увеличиваем счетчик скачиваний
    await db.increment_plugin_downloads(plugin_id)
    
    # Отправляем файл
    await callback.message.answer_document(
        plugin['file_id'],
        caption=f"📦 <b>{plugin['title']}</b>\n\n"
                f"👤 Автор: {plugin['user_id']}\n"
                f"⬇️ Скачиваний: {plugin['downloads'] + 1}",
        parse_mode="HTML"
    )
    
    await callback.answer()


async def subscribe_plugin(callback: types.CallbackQuery):
    """Подписка на плагин"""
    plugin_id = int(callback.data.replace('sub_', ''))
    user_id = callback.from_user.id
    
    success = await db.subscribe_to_plugin(user_id, plugin_id)
    
    if success:
        await callback.answer("✅ Вы подписались на плагин!")
        
        # Обновляем клавиатуру
        await callback.message.edit_reply_markup(
            reply_markup=UserKeyboards.plugin_actions(plugin_id, is_subscribed=True)
        )
    else:
        await callback.answer("❌ Вы уже подписаны на этот плагин", show_alert=True)


async def unsubscribe_plugin(callback: types.CallbackQuery):
    """Отписка от плагина"""
    plugin_id = int(callback.data.replace('unsub_', ''))
    user_id = callback.from_user.id
    
    success = await db.unsubscribe_from_plugin(user_id, plugin_id)
    
    if success:
        await callback.answer("💔 Вы отписались от плагина")
        
        # Обновляем клавиатуру
        await callback.message.edit_reply_markup(
            reply_markup=UserKeyboards.plugin_actions(plugin_id, is_subscribed=False)
        )
    else:
        await callback.answer("❌ Вы не подписаны на этот плагин", show_alert=True)


async def rate_plugin(callback: types.CallbackQuery):
    """Оценка плагина - показать кнопки оценки"""
    plugin_id = int(callback.data.replace('rate_', ''))
    
    await callback.message.edit_reply_markup(
        reply_markup=UserKeyboards.rate_plugin(plugin_id)
    )
    await callback.answer()


async def set_rating(callback: types.CallbackQuery):
    """Установка оценки"""
    data = callback.data.split('_')
    plugin_id = int(data[2])
    rating = int(data[3])
    user_id = callback.from_user.id
    
    # Проверяем, есть ли уже оценка
    existing_rating = await db.get_user_rating(user_id, plugin_id)
    
    if existing_rating:
        # Обновляем оценку
        success = await db.update_rating(user_id, plugin_id, rating)
        action = "обновлена"
    else:
        # Новая оценка
        success = await db.rate_plugin(user_id, plugin_id, rating)
        action = "поставлена"
    
    if success:
        await callback.answer(f"⭐ Оценка {action}: {rating} звезд!")
        
        # Возвращаем к плагину
        await callback.message.edit_reply_markup(
            reply_markup=UserKeyboards.plugin_actions(plugin_id)
        )
    else:
        await callback.answer("❌ Ошибка при оценке", show_alert=True)


async def show_author(callback: types.CallbackQuery):
    """Показать страницу автора"""
    plugin_id = int(callback.data.replace('author_', ''))
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("❌ Плагин не найден", show_alert=True)
        return
    
    author = await db.get_user(plugin['user_id'])
    
    # Получаем плагины автора
    author_plugins = await db.get_plugins_by_user(author['user_id'], include_archived=False)
    
    # Проверяем подписку на автора (если реализована)
    is_subscribed = False  # TODO: реализовать подписку на автора
    
    author_text = (
        f"👤 <b>{author['nickname']}</b>\n"
        f"🔗 @{author['user_tag'] or 'не указан'}\n\n"
        f"❤️ <b>Подписчики:</b> {author['subscribers_count']:,}\n\n"
        f"📊 <b>Статистика плагинов:</b>\n"
        f"⬇️ Скачиваний: {author['total_downloads']:,}\n"
        f"👁 Просмотров: {author['total_views']:,}\n"
        f"⭐ Рейтинг: {author['total_rating']:.1f}\n\n"
        f"📦 <b>Плагины автора:</b> {len(author_plugins)}"
    )
    
    plugin_ids = [p['plugin_id'] for p in author_plugins]
    
    await callback.message.edit_text(
        author_text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.author_page(
            author['user_id'], plugin_ids, is_subscribed
        )
    )
    await callback.answer()


async def show_reviews(callback: types.CallbackQuery):
    """Показать отзывы о плагине"""
    plugin_id = int(callback.data.replace('reviews_', ''))
    
    reviews = await db.get_plugin_reviews(plugin_id, limit=10)
    plugin = await db.get_plugin(plugin_id)
    
    if not reviews:
        text = (
            f"💬 <b>Отзывы о {plugin['title']}</b>\n\n"
            "Пока нет отзывов. Будьте первым!"
        )
    else:
        text = f"💬 <b>Отзывы о {plugin['title']}</b>\n\n"
        
        for review in reviews:
            text += (
                f"👤 <b>{review['nickname']}</b>\n"
                f"<i>{review['text']}</i>\n\n"
            )
    
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.reviews(plugin_id)
    )
    await callback.answer()


async def add_review(callback: types.CallbackQuery, state: FSMContext):
    """Добавить отзыв"""
    plugin_id = int(callback.data.replace('add_review_', ''))
    
    await callback.message.edit_text(
        "✏️ <b>Напишите отзыв:</b>\n\n"
        "Поделитесь своим мнением о плагине:",
        parse_mode="HTML"
    )
    await state.update_data(review_plugin_id=plugin_id)
    await state.set_state(UserStates.writing_review)
    await callback.answer()


async def process_review(message: types.Message, state: FSMContext):
    """Обработка отзыва"""
    data = await state.get_data()
    plugin_id = data['review_plugin_id']
    
    text = message.text.strip()
    
    if len(text) < 10 or len(text) > 500:
        await message.answer(
            "❌ Отзыв должен быть от 10 до 500 символов.\n\n"
            "Попробуйте еще раз:"
        )
        return
    
    # Сохраняем отзыв
    await db.add_review(plugin_id, message.from_user.id, text)
    
    await message.answer(
        "✅ Отзыв добавлен! Спасибо за ваше мнение.",
        reply_markup=UserKeyboards.back_to_plugin(plugin_id)
    )
    await state.clear()


async def process_update_file(message: types.Message, state: FSMContext):
    """Обработка файла при обновлении плагина"""
    if not message.document:
        await message.answer(
            "❌ Пожалуйста, отправьте файл плагина."
        )
        return
    
    data = await state.get_data()
    plugin_id = data.get('update_plugin_id')
    
    if not plugin_id:
        await message.answer("❌ Ошибка: не найден ID плагина")
        await state.clear()
        return
    
    # Обновляем файл плагина
    success = await db.update_plugin(
        plugin_id,
        file_id=message.document.file_id,
        file_name=message.document.file_name
    )
    
    if success:
        await message.answer(
            "✅ Файл плагина обновлен!",
            reply_markup=UserKeyboards.back_to_plugin(plugin_id)
        )
    else:
        await message.answer("❌ Ошибка при обновлении файла")
    
    await state.clear()


async def manage_plugin(callback: types.CallbackQuery):
    """Управление плагином (для владельца/админа)"""
    plugin_id = int(callback.data.replace('manage_', ''))
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("❌ Плагин не найден", show_alert=True)
        return
    
    await callback.message.edit_reply_markup(
        reply_markup=UserKeyboards.manage_plugin(plugin_id, plugin['is_archived'])
    )
    await callback.answer()


async def archive_plugin(callback: types.CallbackQuery):
    """Архивировать плагин"""
    plugin_id = int(callback.data.replace('archive_', ''))
    
    success = await db.update_plugin(plugin_id, is_archived=1)
    
    if success:
        await callback.answer("📁 Плагин перемещен в архив")
        await callback.message.edit_reply_markup(
            reply_markup=UserKeyboards.manage_plugin(plugin_id, is_archived=True)
        )
    else:
        await callback.answer("❌ Ошибка при архивации", show_alert=True)


async def unarchive_plugin(callback: types.CallbackQuery):
    """Вернуть плагин из архива"""
    plugin_id = int(callback.data.replace('unarchive_', ''))
    
    success = await db.update_plugin(plugin_id, is_archived=0)
    
    if success:
        await callback.answer("📥 Плагин возвращен из архива")
        await callback.message.edit_reply_markup(
            reply_markup=UserKeyboards.manage_plugin(plugin_id, is_archived=False)
        )
    else:
        await callback.answer("❌ Ошибка при восстановлении", show_alert=True)


async def delete_plugin(callback: types.CallbackQuery):
    """Удалить плагин"""
    plugin_id = int(callback.data.replace('delete_', ''))
    
    await callback.message.edit_text(
        "🗑 <b>Удалить плагин?</b>\n\n"
        "Это действие нельзя отменить!",
        parse_mode="HTML",
        reply_markup=UserKeyboards.confirm_action("delete", plugin_id)
    )
    await callback.answer()


async def confirm_delete(callback: types.CallbackQuery, bot):
    """Подтверждение удаления"""
    plugin_id = int(callback.data.split('_')[-1])
    
    plugin = await db.get_plugin(plugin_id)
    if not plugin:
        await callback.answer("❌ Плагин не найден", show_alert=True)
        return
    
    # Удаляем плагин (в реальном приложении - мягкое удаление)
    # await db.delete_plugin(plugin_id)
    
    await callback.message.edit_text(
        "✅ Плагин удален.",
        reply_markup=UserKeyboards.back_to_menu()
    )
    await callback.answer()


async def update_plugin(callback: types.CallbackQuery, state: FSMContext):
    """Обновить плагин"""
    plugin_id = int(callback.data.replace('update_', ''))
    
    await callback.message.edit_text(
        "🔄 <b>Обновление плагина</b>\n\n"
        "Отправьте новый файл плагина:",
        parse_mode="HTML"
    )
    await state.update_data(update_plugin_id=plugin_id)
    await state.set_state(UploadStates.waiting_file)
    await callback.answer()


def register_plugins_handlers(router: Router):
    """Регистрация обработчиков действий с плагинами"""
    router.callback_query.register(download_plugin, F.data.startswith("download_"))
    router.callback_query.register(subscribe_plugin, F.data.startswith("sub_"))
    router.callback_query.register(unsubscribe_plugin, F.data.startswith("unsub_"))
    router.callback_query.register(rate_plugin, F.data.startswith("rate_"))
    router.callback_query.register(set_rating, F.data.startswith("rate_set_"))
    router.callback_query.register(show_author, F.data.startswith("author_"))
    router.callback_query.register(show_reviews, F.data.startswith("reviews_"))
    router.callback_query.register(add_review, F.data.startswith("add_review_"))
    router.callback_query.register(manage_plugin, F.data.startswith("manage_"))
    router.callback_query.register(archive_plugin, F.data.startswith("archive_"))
    router.callback_query.register(unarchive_plugin, F.data.startswith("unarchive_"))
    router.callback_query.register(delete_plugin, F.data.startswith("delete_"))
    router.callback_query.register(confirm_delete, F.data.startswith("confirm_delete_"))
    router.callback_query.register(update_plugin, F.data.startswith("update_"))
    
    # Обработчик для обновления файла плагина
    router.message.register(process_update_file, UploadStates.waiting_file, F.document)
    # Обработчик для отзывов
    router.message.register(process_review, UserStates.writing_review, F.text)