from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from keyboards.user_kb import UserKeyboards
from utils.states import UploadStates
from utils.notifications import NotificationManager
from database import db
from config import Config
import logging

logger = logging.getLogger(__name__)


async def upload_button(message: types.Message, state: FSMContext):
    """Нажатие на кнопку 'Загрузить'"""
    await state.clear()
    await message.answer(
        "📤 <b>Загрузка плагина</b>\n\n"
        "[1/5] Пожалуйста, загрузите файл плагина:\n\n"
        "Файл будет отправлен на модерацию.",
        parse_mode="HTML"
    )
    await state.set_state(UploadStates.waiting_file)


async def process_file(message: types.Message, state: FSMContext):
    """Обработка загруженного файла"""
    if not message.document:
        await message.answer(
            "❌ Пожалуйста, отправьте файл плагина."
        )
        return
    
    file_id = message.document.file_id
    file_name = message.document.file_name
    
    # Сохраняем данные
    await state.update_data(
        file_id=file_id,
        file_name=file_name
    )
    
    await message.answer(
        "✅ Файл получен!\n\n"
        "Отправьте другой файл, если хотите заменить его.",
        reply_markup=UserKeyboards.upload_steps(step=1)
    )


async def continue_upload(callback: types.CallbackQuery, state: FSMContext, bot):
    """Продолжить загрузку после файла"""
    data = await state.get_data()
    file_id = data.get('file_id')
    
    if not file_id:
        await callback.answer("❌ Сначала загрузите файл", show_alert=True)
        return
    
    # Отправляем файл в топик безопасности
    await NotificationManager(bot).notify_security_file(
        file_id, data['file_name'], callback.from_user.id
    )
    
    await callback.message.edit_text(
        "📤 <b>Загрузка плагина</b>\n\n"
        "[2/5] Отлично! Теперь отправьте:\n"
        "- <b>Название плагина</b> (текстом)\n"
        "- <b>Фото для обложки</b> (опционально, приложите к сообщению)\n\n"
        "Пример: <i>Мой супер плагин</i> (с фото или без)",
        parse_mode="HTML"
    )
    await state.set_state(UploadStates.waiting_title)
    await callback.answer()


async def process_title_and_photo(message: types.Message, state: FSMContext):
    """Обработка названия и фото"""
    title = message.text or message.caption
    
    if not title or len(title) < 3 or len(title) > 100:
        await message.answer(
            "❌ Название должно быть от 3 до 100 символов.\n\n"
            "Попробуйте еще раз:"
        )
        return
    
    # Сохраняем данные
    await state.update_data(title=title)
    
    # Проверяем фото
    photo_id = None
    if message.photo:
        photo_id = message.photo[-1].file_id
        await state.update_data(photo_id=photo_id)
    
    await message.answer(
        f"✅ Название: <b>{title}</b>\n"
        f"{'✅ Фото обложки загружено' if photo_id else '📷 Без обложки'}\n\n"
        "[3/5] Выберите категорию:",
        parse_mode="HTML",
        reply_markup=UserKeyboards.select_category()
    )


async def select_category(callback: types.CallbackQuery, state: FSMContext):
    """Выбор категории"""
    category_map = {
        'tools': 'Инструменты',
        'fun': 'Веселье',
        'bots': 'Боты',
        'security': 'Безопасность',
        'integrations': 'Интеграции'
    }
    
    category_key = callback.data.replace('upload_cat_', '')
    category_name = category_map[category_key]
    
    await state.update_data(category=category_name)
    
    await callback.message.edit_text(
        f"✅ Категория: <b>{category_name}</b>\n\n"
        "[4/5] Выберите статус разработки:",
        parse_mode="HTML",
        reply_markup=UserKeyboards.select_status()
    )
    await callback.answer()


async def select_status(callback: types.CallbackQuery, state: FSMContext):
    """Выбор статуса"""
    status_map = {
        'development': 'В работе',
        'updates': 'Возможны обновления',
        'completed': 'Завершено'
    }
    
    status_key = callback.data.replace('upload_status_', '')
    status_name = status_map[status_key]
    
    await state.update_data(status=status_name)
    
    await callback.message.edit_text(
        f"✅ Статус: <b>{status_name}</b>\n\n"
        "[5/5] Почти всё! Введите теги:\n\n"
        "Каждое слово через пробел - отдельный тег.\n"
        "Опишите плагин ключевыми словами.",
        parse_mode="HTML"
    )
    await state.set_state(UploadStates.waiting_tags)
    await callback.answer()


async def process_tags(message: types.Message, state: FSMContext):
    """Обработка тегов"""
    tags = message.text.strip()
    
    if len(tags) < 3 or len(tags) > 200:
        await message.answer(
            "❌ Теги должны быть от 3 до 200 символов.\n\n"
            "Попробуйте еще раз:"
        )
        return
    
    # Сохраняем теги
    await state.update_data(tags=tags)
    
    # Показываем подтверждение
    data = await state.get_data()
    
    confirmation_text = (
        "📋 <b>Проверьте данные:</b>\n\n"
        f"📦 <b>Название:</b> {data['title']}\n"
        f"📂 <b>Категория:</b> {data['category']}\n"
        f"🛠 <b>Статус:</b> {data['status']}\n"
        f"🏷 <b>Теги:</b> {tags}\n"
        f"📷 <b>Обложка:</b> {'Да' if data.get('photo_id') else 'Нет'}\n\n"
        "Всё верно?"
    )
    
    await message.answer(
        confirmation_text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.upload_steps(step=3)
    )


async def submit_plugin(callback: types.CallbackQuery, state: FSMContext, bot):
    """Отправка плагина на модерацию"""
    data = await state.get_data()
    user_id = callback.from_user.id
    
    try:
        # Создаем плагин в базе
        plugin_id = await db.create_plugin(
            user_id=user_id,
            file_id=data['file_id'],
            file_name=data['file_name'],
            title=data['title'],
            description="Ожидает модерации",
            category=data['category'],
            status=data['status'],
            tags=data['tags'],
            photo_id=data.get('photo_id')
        )
        
        # Создаем заявку на загрузку
        request_id = await db.create_upload_request(
            user_id=user_id,
            plugin_id=plugin_id,
            security_file_id=data['file_id']
        )
        
        # Уведомляем админов
        await NotificationManager(bot).notify_new_request(request_id, user_id, data['title'])
        
        await callback.message.edit_text(
            "✅ <b>Отлично!</b>\n\n"
            "Ваш плагин отправлен на модерацию.\n"
            f"Номер заявки: <b>#{request_id}</b>\n\n"
            "Ожидайте уведомления о результатах.",
            parse_mode="HTML",
            reply_markup=UserKeyboards.back_to_menu()
        )
        
        await state.clear()
        
    except Exception as e:
        logger.error(f"Error submitting plugin: {e}")
        await callback.answer("❌ Ошибка при отправке. Попробуйте позже.", show_alert=True)


async def cancel_upload(callback: types.CallbackQuery, state: FSMContext):
    """Отмена загрузки"""
    await state.clear()
    await callback.message.edit_text(
        "❌ Загрузка отменена.",
        reply_markup=UserKeyboards.back_to_menu()
    )
    await callback.answer()


def register_upload_handlers(router: Router):
    """Регистрация обработчиков загрузки"""
    # Reply кнопка
    router.message.register(upload_button, F.text == "📤 Загрузить")
    
    # Остальные обработчики
    router.message.register(process_file, UploadStates.waiting_file, F.document)
    router.callback_query.register(continue_upload, F.data == "upload_step2")
    router.message.register(process_title_and_photo, UploadStates.waiting_title, F.text | F.photo)
    router.callback_query.register(select_category, F.data.startswith("upload_cat_"))
    router.callback_query.register(select_status, F.data.startswith("upload_status_"))
    router.message.register(process_tags, UploadStates.waiting_tags, F.text)
    router.callback_query.register(submit_plugin, F.data == "upload_submit")
    router.callback_query.register(cancel_upload, F.data == "cancel_upload")