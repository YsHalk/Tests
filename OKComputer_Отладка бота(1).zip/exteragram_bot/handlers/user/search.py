from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from keyboards.user_kb import UserKeyboards
from utils.states import UserStates
from utils.search import SearchEngine
from database import db
from models.plugin import Plugin
from config import Config
import logging

logger = logging.getLogger(__name__)


async def search_button(message: types.Message, state: FSMContext):
    """Нажатие на кнопку 'Найти'"""
    await message.answer(
        "🔍 <b>Поиск плагинов</b>\n\n"
        "Введите название, автора или просто опишите плагин - я найду самый подходящий!",
        parse_mode="HTML"
    )
    await state.set_state(UserStates.waiting_search_query)


async def process_search_query(message: types.Message, state: FSMContext):
    """Обработка поискового запроса"""
    query = message.text.strip()
    
    if len(query) < 2:
        await message.answer(
            "❌ Запрос слишком короткий. Попробуйте еще раз:"
        )
        return
    
    # Ищем плагины
    results = await SearchEngine.search(query, limit=10)
    
    if not results:
        await message.answer(
            "😔 К сожалению, по вашему запросу ничего не найдено.\n\n"
            "Попробуйте изменить запрос или воспользуйтесь категориями.",
            reply_markup=UserKeyboards.back_to_menu()
        )
        await state.clear()
        return
    
    # Показываем результаты
    plugin_ids = [p['plugin_id'] for p in results]
    
    await message.answer(
        f"🔍 <b>Возможно, вы искали:</b>\n\n"
        f"Найдено результатов: <b>{len(results)}</b>",
        parse_mode="HTML",
        reply_markup=UserKeyboards.search_results(plugin_ids)
    )
    await state.clear()


async def show_popular(message: types.Message):
    """Показать популярные плагины"""
    plugins = await SearchEngine.get_popular(limit=10)
    
    if not plugins:
        await message.answer(
            "📂 Пока нет популярных плагинов.",
            reply_markup=UserKeyboards.back_to_menu()
        )
        return
    
    # Формируем текст с популярными плагинами
    text = "🔥 <b>Популярные плагины</b>\n\n"
    
    for i, plugin in enumerate(plugins, 1):
        author = await db.get_user(plugin['user_id'])
        rating = plugin['rating_sum'] / plugin['rating_count'] if plugin['rating_count'] > 0 else 0
        
        text += (
            f"{i}. <b>{plugin['title']}</b>\n"
            f"   👤 {author['nickname']}\n"
            f"   ⭐ {rating:.1f} | 📥 {plugin['downloads']}\n\n"
        )
    
    plugin_ids = [p['plugin_id'] for p in plugins]
    
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.search_results(plugin_ids)
    )
    await callback.answer()


async def show_categories(message: types.Message):
    """Показать категории"""
    await message.answer(
        "📂 <b>Категории плагинов</b>\n\n"
        "Выберите категорию:",
        parse_mode="HTML",
        reply_markup=UserKeyboards.categories()
    )


async def show_category_plugins(callback: types.CallbackQuery):
    """Показать плагины категории"""
    category_map = {
        'tools': 'Инструменты',
        'fun': 'Веселье',
        'bots': 'Боты',
        'security': 'Безопасность',
        'integrations': 'Интеграции'
    }
    
    category_key = callback.data.replace('cat_', '')
    category_name = category_map.get(category_key, category_key)
    
    plugins = await SearchEngine.search_by_category(category_name)
    
    if not plugins:
        await callback.message.edit_text(
            f"📂 В категории '<b>{category_name}</b>' пока нет плагинов.",
            parse_mode="HTML",
            reply_markup=UserKeyboards.categories()
        )
        await callback.answer()
        return
    
    text = f"📂 <b>{category_name}</b>\n\n"
    text += f"Найдено плагинов: <b>{len(plugins)}</b>"
    
    plugin_ids = [p['plugin_id'] for p in plugins]
    
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=UserKeyboards.search_results(plugin_ids)
    )
    await callback.answer()


async def show_plugin(callback: types.CallbackQuery):
    """Показать страницу плагина"""
    plugin_id = int(callback.data.replace('plugin_', ''))
    
    # Получаем данные плагина
    plugin_data = await db.get_plugin(plugin_id)
    if not plugin_data:
        await callback.answer("❌ Плагин не найден", show_alert=True)
        return
    
    # Увеличиваем просмотры
    await db.increment_plugin_views(plugin_id)
    
    # Получаем автора
    author = await db.get_user(plugin_data['user_id'])
    
    # Проверяем подписку
    user_id = callback.from_user.id
    is_subscribed = await db.is_subscribed(user_id, plugin_id)
    
    # Проверяем, является ли пользователь владельцем или админом
    is_owner = plugin_data['user_id'] == user_id
    is_admin = user_id == Config.OWNER_ID  # Замените на вашу логику проверки админа
    
    # Формируем сообщение
    plugin = Plugin(**plugin_data)
    
    message_text = (
        f"{plugin.category_emoji} <b>{plugin.title}</b>\n\n"
        f"{plugin.description}\n\n"
        f"🛠 <b>Статус разработки:</b> {plugin.status_emoji} {plugin.status}\n"
        f"👤 <b>Автор:</b> {author['mention']}\n"
        f"📂 <b>Категория:</b> {plugin.category}\n"
        f"📅 <b>Обновлено:</b> {plugin.updated_at.strftime('%d.%m.%Y')}\n\n"
        f"👁 <b>Просмотры:</b> {plugin.views:,}\n"
        f"⬇️ <b>Скачивания:</b> {plugin.downloads:,}\n"
        f"⭐ <b>Рейтинг:</b> {plugin.rating_text}"
    )
    
    # Отправляем фото, если есть
    if plugin.photo_id:
        await callback.message.delete()
        await callback.message.answer_photo(
            plugin.photo_id,
            caption=message_text,
            parse_mode="HTML",
            reply_markup=UserKeyboards.plugin_actions(
                plugin_id, is_subscribed, is_owner, is_admin
            )
        )
    else:
        await callback.message.edit_text(
            message_text,
            parse_mode="HTML",
            reply_markup=UserKeyboards.plugin_actions(
                plugin_id, is_subscribed, is_owner, is_admin
            )
        )
    
    await callback.answer()


def register_search_handlers(router: Router):
    """Регистрация обработчиков поиска"""
    # Reply кнопки главного меню
    router.message.register(search_button, F.text == "🔍 Найти")
    router.message.register(show_popular, F.text == "🔥 Популярное")
    router.message.register(show_categories, F.text == "📂 Категории")
    
    # Остальные обработчики
    router.message.register(process_search_query, UserStates.waiting_search_query)
    router.callback_query.register(show_category_plugins, F.data.startswith("cat_"))
    router.callback_query.register(show_plugin, F.data.startswith("plugin_"))