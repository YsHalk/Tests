from aiogram import Router
from .moderation import register_moderation_handlers
from .broadcast import register_broadcast_handlers


def register_admin_handlers(router: Router):
    """Регистрация всех обработчиков администратора"""
    register_moderation_handlers(router)
    register_broadcast_handlers(router)