from .database import Database

db = Database()