from dataclasses import dataclass


@dataclass
class Config:
    # Bot token
    BOT_TOKEN = "8086980745:AAHy0qUFRU1R9YPVrxjTT2ygO8t0oG_Mz9c"
    
    # Chat IDs
    ADMIN_GROUP_ID = -1003668432996
    OWNER_ID = 7188906494
    
    # Forum topic IDs
    REQUESTS_TOPIC_ID = 2  # Заявки
    SECURITY_TOPIC_ID = 3  # Безопасность
    STORAGE_TOPIC_ID = 5   # Хранилище
    
    # Database
    DATABASE_PATH = "data/bot.db"
    
    # Search settings
    MAX_SEARCH_RESULTS = 10
    
    # Rating settings
    MIN_RATING = 1
    MAX_RATING = 5