import asyncio
import logging
import sys
import os
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram import Router
from config import Config
from database import db
from handlers.user import register_user_handlers
from handlers.admin import register_admin_handlers

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def main() -> None:
    """Главная функция запуска бота"""
    
    # Создание папки данных
    os.makedirs("data", exist_ok=True)
    logger.info("Папка данных создана")
    
    # Инициализация базы данных
    logger.info("Инициализация базы данных...")
    await db.initialize()
    logger.info("База данных инициализирована")
    
    # Создание бота
    bot = Bot(
        token=Config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    
    # Создание диспетчера
    dp = Dispatcher()
    
    # Создание роутеров
    user_router = Router()
    admin_router = Router()
    
    # Регистрация обработчиков
    logger.info("Регистрация обработчиков...")
    register_user_handlers(user_router)
    register_admin_handlers(admin_router)
    
    # Подключение роутеров к диспетчеру
    dp.include_router(user_router)
    dp.include_router(admin_router)
    logger.info("Обработчики зарегистрированы")
    
    # Запуск бота
    logger.info("Запуск бота...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Бот остановлен")
        sys.exit(0)