from dataclasses import dataclass
from typing import Optional, List
from datetime import datetime


@dataclass
class Plugin:
    plugin_id: int
    user_id: int
    file_id: str
    file_name: str
    title: str
    description: str
    photo_id: Optional[str]
    category: str
    status: str
    tags: str
    views: int
    downloads: int
    rating_sum: float
    rating_count: int
    is_archived: bool
    created_at: datetime
    updated_at: datetime
    
    @property
    def rating(self) -> float:
        """Средний рейтинг"""
        if self.rating_count == 0:
            return 0.0
        return self.rating_sum / self.rating_count
    
    @property
    def rating_text(self) -> str:
        """Текстовое представление рейтинга"""
        rating = self.rating
        if rating == 0:
            return "Нет оценок"
        return f"{rating:.1f} ⭐ ({self.rating_count})"
    
    @property
    def status_emoji(self) -> str:
        """Эмодзи для статуса"""
        status_emojis = {
            'В работе': '🛠',
            'Возможны обновления': '🔄',
            'Завершено': '✅'
        }
        return status_emojis.get(self.status, '')
    
    @property
    def category_emoji(self) -> str:
        """Эмодзи для категории"""
        category_emojis = {
            'Инструменты': '🔧',
            'Веселье': '🎉',
            'Боты': '🤖',
            'Безопасность': '🛡',
            'Интеграции': '🔗'
        }
        return category_emojis.get(self.category, '📦')