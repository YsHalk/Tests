from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder


class UserKeyboards:
    """Клавиатуры для пользователей - ЛЕГКО РЕДАКТИРОВАТЬ!"""
    
    # === ГЛАВНОЕ МЕНЮ ===
    @staticmethod
    def main_menu() -> ReplyKeyboardMarkup:
        """Главное меню действий"""
        kb = ReplyKeyboardBuilder()
        
        # Первая строка
        kb.button(text="🔍 Найти")
        kb.button(text="📤 Загрузить")
        
        # Вторая строка
        kb.button(text="🔥 Популярное")
        kb.button(text="📂 Категории")
        
        # Третья строка
        kb.button(text="❤️ Подписки")
        kb.button(text="👤 Мой профиль")
        
        kb.adjust(2, 2, 2)  # По 2 кнопки в строку
        return kb.as_markup(resize_keyboard=True)
    
    # === ИНЛАЙН КНОПКИ ПЛАГИНА ===
    @staticmethod
    def plugin_actions(plugin_id: int, is_subscribed: bool = False, 
                      is_owner: bool = False, is_admin: bool = False) -> InlineKeyboardMarkup:
        """Кнопки действий на странице плагина"""
        kb = InlineKeyboardBuilder()
        
        # Первая строка - Скачать и Подписаться/Отписаться
        kb.button(text="⬇️ Скачать", callback_data=f"download_{plugin_id}")
        
        if is_subscribed:
            kb.button(text="💔 Отписаться", callback_data=f"unsub_{plugin_id}")
        else:
            kb.button(text="❤️ Подписаться", callback_data=f"sub_{plugin_id}")
        
        # Вторая строка - Автор и отзывы
        kb.button(text="👤 Автор", callback_data=f"author_{plugin_id}")
        kb.button(text="💬 Отзывы", callback_data=f"reviews_{plugin_id}")
        
        # Третья строка - Оценить
        kb.button(text="⭐ Оценить", callback_data=f"rate_{plugin_id}")
        
        # Четвертая строка - Управление (только для владельца и админов)
        if is_owner or is_admin:
            kb.button(text="⚙️ Управление", callback_data=f"manage_{plugin_id}")
        
        kb.adjust(2, 2, 1, 1)
        return kb.as_markup()
    
    # === ОЦЕНКА ===
    @staticmethod
    def rate_plugin(plugin_id: int) -> InlineKeyboardMarkup:
        """Кнопки оценки плагина"""
        kb = InlineKeyboardBuilder()
        
        # Звезды от 1 до 5
        for rating in range(1, 6):
            kb.button(text=f"{'⭐' * rating}", callback_data=f"rate_set_{plugin_id}_{rating}")
        
        # Назад
        kb.button(text="⬅️ Назад", callback_data=f"plugin_{plugin_id}")
        
        kb.adjust(5, 1)
        return kb.as_markup()
    
    # === КАТЕГОРИИ ===
    @staticmethod
    def categories() -> InlineKeyboardMarkup:
        """Категории плагинов"""
        kb = InlineKeyboardBuilder()
        
        categories = [
            ("🔧 Инструменты", "tools"),
            ("🎉 Веселье", "fun"),
            ("🤖 Боты", "bots"),
            ("🛡 Безопасность", "security"),
            ("🔗 Интеграции", "integrations")
        ]
        
        for text, callback in categories:
            kb.button(text=text, callback_data=f"cat_{callback}")
        
        kb.button(text="⬅️ Назад", callback_data="back_main")
        kb.adjust(1)
        return kb.as_markup()
    
    # === ПОИСКОВЫЕ РЕЗУЛЬТАТЫ ===
    @staticmethod
    def search_results(plugin_ids: list, page: int = 0) -> InlineKeyboardMarkup:
        """Результаты поиска"""
        kb = InlineKeyboardBuilder()
        
        # Плагины (максимум 10)
        for i, plugin_id in enumerate(plugin_ids[:10]):
            kb.button(text=f"📦 #{i+1}", callback_data=f"plugin_{plugin_id}")
        
        # Навигация (если нужно)
        buttons_in_row = 5
        if len(plugin_ids) > buttons_in_row:
            nav_buttons = []
            if page > 0:
                nav_buttons.append(InlineKeyboardButton(text="⬅️", callback_data=f"search_page_{page-1}"))
            if len(plugin_ids) > (page + 1) * buttons_in_row:
                nav_buttons.append(InlineKeyboardButton(text="➡️", callback_data=f"search_page_{page+1}"))
            
            if nav_buttons:
                kb.row(*nav_buttons)
        
        # Назад
        kb.button(text="⬅️ В меню", callback_data="back_main")
        kb.adjust(5, 5, 2)
        return kb.as_markup()
    
    # === ПРОФИЛЬ ===
    @staticmethod
    def profile_menu() -> InlineKeyboardMarkup:
        """Меню профиля"""
        kb = InlineKeyboardBuilder()
        
        kb.button(text="✉️ Отправить подписчикам", callback_data="broadcast")
        kb.button(text="✏️ Изменить", callback_data="edit_profile")
        kb.button(text="🖼 Баннер", callback_data="edit_banner")
        kb.button(text="📋 Мои плагины", callback_data="my_plugins")
        kb.button(text="🏠 Меню", callback_data="back_main")
        
        kb.adjust(1, 2, 2)
        return kb.as_markup()
    
    # === РЕДАКТИРОВАНИЕ ПРОФИЛЯ ===
    @staticmethod
    def edit_profile() -> InlineKeyboardMarkup:
        """Редактирование профиля"""
        kb = InlineKeyboardBuilder()
        
        kb.button(text="📝 Никнейм", callback_data="edit_nickname")
        kb.button(text="🔗 Юз", callback_data="edit_usertag")
        kb.button(text="⬅️ Назад", callback_data="profile")
        
        kb.adjust(2, 1)
        return kb.as_markup()
    
    # === МОИ ПЛАГИНЫ ===
    @staticmethod
    def my_plugins(plugin_ids: list, include_archived: bool = False) -> InlineKeyboardMarkup:
        """Список плагинов пользователя"""
        kb = InlineKeyboardBuilder()
        
        for plugin_id in plugin_ids:
            status = "📦"
            if include_archived:
                status = "📁"  # Архивный
            kb.button(text=f"{status} #{plugin_id}", callback_data=f"plugin_{plugin_id}")
        
        kb.button(text="⬅️ Назад", callback_data="profile")
        kb.adjust(2)
        return kb.as_markup()
    
    # === УПРАВЛЕНИЕ ПЛАГИНОМ (владелец/админ) ===
    @staticmethod
    def manage_plugin(plugin_id: int, is_archived: bool = False) -> InlineKeyboardMarkup:
        """Управление плагином"""
        kb = InlineKeyboardBuilder()
        
        if is_archived:
            kb.button(text="📥 Вернуть из архива", callback_data=f"unarchive_{plugin_id}")
        else:
            kb.button(text="📁 В архив", callback_data=f"archive_{plugin_id}")
        
        kb.button(text="🗑 Удалить", callback_data=f"delete_{plugin_id}")
        kb.button(text="🔄 Обновить", callback_data=f"update_{plugin_id}")
        kb.button(text="⬅️ Назад", callback_data=f"plugin_{plugin_id}")
        
        kb.adjust(2, 2, 1)
        return kb.as_markup()
    
    # === СТРАНИЦА АВТОРА ===
    @staticmethod
    def author_page(author_id: int, plugin_ids: list, is_subscribed: bool = False) -> InlineKeyboardMarkup:
        """Страница автора"""
        kb = InlineKeyboardBuilder()
        
        # Подписаться/Отписаться
        if is_subscribed:
            kb.button(text="💔 Отписаться от автора", callback_data=f"unsub_author_{author_id}")
        else:
            kb.button(text="❤️ Подписаться на автора", callback_data=f"sub_author_{author_id}")
        
        # Плагины автора (до 5)
        for plugin_id in plugin_ids[:5]:
            kb.button(text=f"📦 Плагин #{plugin_id}", callback_data=f"plugin_{plugin_id}")
        
        kb.button(text="🏠 Меню", callback_data="back_main")
        
        # Форматируем клавиатуру
        kb.adjust(1, 1)  # Подписка и плагины
        if len(plugin_ids) > 0:
            kb.adjust(1, min(len(plugin_ids), 5), 1)
        return kb.as_markup()
    
    # === ОТЗЫВЫ ===
    @staticmethod
    def reviews(plugin_id: int, can_add: bool = True) -> InlineKeyboardMarkup:
        """Отзывы плагина"""
        kb = InlineKeyboardBuilder()
        
        if can_add:
            kb.button(text="✏️ Написать отзыв", callback_data=f"add_review_{plugin_id}")
        
        kb.button(text="⬅️ Назад", callback_data=f"plugin_{plugin_id}")
        kb.adjust(1)
        return kb.as_markup()
    
    # === ЗАГРУЗКА ПЛАГИНА ===
    @staticmethod
    def upload_steps(step: int = 1) -> InlineKeyboardMarkup:
        """Кнопки при загрузке плагина"""
        kb = InlineKeyboardBuilder()
        
        if step == 1:  # Загрузка файла
            kb.button(text="➡️ Продолжить", callback_data="upload_step2")
        elif step == 2:  # Подтверждение файла
            kb.button(text="✅ Да", callback_data="upload_step3")
            kb.button(text="🔄 Заменить файл", callback_data="upload_replace_file")
        elif step == 3:  # Подтверждение данных
            kb.button(text="✅ Всё верно", callback_data="upload_submit")
            kb.button(text="✏️ Изменить", callback_data="upload_edit")
        
        kb.button(text="❌ Отмена", callback_data="cancel_upload")
        kb.adjust(2, 1)
        return kb.as_markup()
    
    # === ВЫБОР КАТЕГОРИИ ПРИ ЗАГРУЗКЕ ===
    @staticmethod
    def select_category() -> InlineKeyboardMarkup:
        """Выбор категории при загрузке"""
        kb = InlineKeyboardBuilder()
        
        categories = [
            ("🔧 Инструменты", "tools"),
            ("🎉 Веселье", "fun"),
            ("🤖 Боты", "bots"),
            ("🛡 Безопасность", "security"),
            ("🔗 Интеграции", "integrations")
        ]
        
        for text, callback in categories:
            kb.button(text=text, callback_data=f"upload_cat_{callback}")
        
        kb.button(text="❌ Отмена", callback_data="cancel_upload")
        kb.adjust(1)
        return kb.as_markup()
    
    # === ВЫБОР СТАТУСА ПРИ ЗАГРУЗКЕ ===
    @staticmethod
    def select_status() -> InlineKeyboardMarkup:
        """Выбор статуса при загрузке"""
        kb = InlineKeyboardBuilder()
        
        statuses = [
            ("🛠 В работе", "development"),
            ("🔄 Возможны обновления", "updates"),
            ("✅ Завершено", "completed")
        ]
        
        for text, callback in statuses:
            kb.button(text=text, callback_data=f"upload_status_{callback}")
        
        kb.button(text="❌ Отмена", callback_data="cancel_upload")
        kb.adjust(1)
        return kb.as_markup()
    
    # === УНИВЕРСАЛЬНЫЕ КНОПКИ ===
    @staticmethod
    def back_to_plugin(plugin_id: int) -> InlineKeyboardMarkup:
        """Вернуться к плагину"""
        kb = InlineKeyboardBuilder()
        kb.button(text="⬅️ Назад к плагину", callback_data=f"plugin_{plugin_id}")
        return kb.as_markup()
    
    @staticmethod
    def back_to_menu() -> InlineKeyboardMarkup:
        """Вернуться в меню"""
        kb = InlineKeyboardBuilder()
        kb.button(text="🏠 В меню", callback_data="back_main")
        return kb.as_markup()
    
    @staticmethod
    def confirm_action(action: str, plugin_id: int) -> InlineKeyboardMarkup:
        """Подтверждение действия"""
        kb = InlineKeyboardBuilder()
        kb.button(text="✅ Подтвердить", callback_data=f"confirm_{action}_{plugin_id}")
        kb.button(text="❌ Отмена", callback_data=f"plugin_{plugin_id}")
        kb.adjust(2)
        return kb.as_markup()