#!/bin/bash

echo "🚀 Установка Exteragram Plugin Library Bot"
echo "=========================================="

# Проверка Python
echo "📍 Проверка Python..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 не найден. Пожалуйста, установите Python 3.8 или выше"
    exit 1
fi

echo "✅ Python найден: $(python3 --version)"

# Создание виртуального окружения
echo "📍 Создание виртуального окружения..."
python3 -m venv venv

# Активация виртуального окружения
echo "📍 Активация виртуального окружения..."
source venv/bin/activate

# Установка зависимостей
echo "📍 Установка зависимостей..."
pip install --upgrade pip
pip install -r requirements.txt

# Создание папки для данных
echo "📍 Создание структуры данных..."
mkdir -p data

echo ""
echo "✅ Установка завершена!"
echo ""
echo "📋 Дальнейшие шаги:"
echo "1. Отредактируйте config.py и укажите ваши данные"
echo "2. Активируйте виртуальное окружение: source venv/bin/activate"
echo "3. Запустите бота: python bot.py"
echo ""