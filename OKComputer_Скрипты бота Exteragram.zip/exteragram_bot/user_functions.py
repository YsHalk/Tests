import os
import asyncio
from typing import Dict, List, Optional, Any
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from datetime import datetime

import buttons
from database import Database, Plugin, User
from config import DATABASE_PATH, PLUGIN_STORAGE_PATH, PHOTO_STORAGE_PATH, MESSAGES

# Создаем директории для хранения
os.makedirs(PLUGIN_STORAGE_PATH, exist_ok=True)
os.makedirs(PHOTO_STORAGE_PATH, exist_ok=True)

# Инициализируем базу данных
db = Database(DATABASE_PATH)


# ========== СОСТОЯНИЯ ==========
class RegistrationStates(StatesGroup):
    waiting_username = State()
    waiting_display_name = State()


class UploadStates(StatesGroup):
    waiting_file = State()
    waiting_name_and_photo = State()
    waiting_category = State()
    waiting_status = State()
    waiting_tags = State()


class SearchStates(StatesGroup):
    waiting_query = State()


class ProfileEditStates(StatesGroup):
    waiting_display_name = State()
    waiting_username = State()
    waiting_banner = State()


class RatingStates(StatesGroup):
    waiting_rating = State()


class BroadcastStates(StatesGroup):
    waiting_message = State()


# ========== ХЕЛПЕРЫ ==========
def create_main_menu() -> ReplyKeyboardMarkup:
    """Создание главного меню"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=3)
    keyboard.add(
        KeyboardButton(buttons.MAIN_MENU["search"]),
        KeyboardButton(buttons.MAIN_MENU["upload"]),
        KeyboardButton(buttons.MAIN_MENU["popular"])
    )
    keyboard.add(
        KeyboardButton(buttons.MAIN_MENU["categories"]),
        KeyboardButton(buttons.MAIN_MENU["subscriptions"]),
        KeyboardButton(buttons.MAIN_MENU["profile"])
    )
    return keyboard


def create_cancel_menu() -> ReplyKeyboardMarkup:
    """Создание меню с кнопкой отмены"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton(buttons.COMMON["cancel"]))
    return keyboard


def create_categories_menu() -> InlineKeyboardMarkup:
    """Создание меню категорий"""
    keyboard = InlineKeyboardMarkup(row_width=1)
    for key, value in buttons.CATEGORIES.items():
        keyboard.add(InlineKeyboardButton(value, callback_data=f"category_{key}"))
    keyboard.add(InlineKeyboardButton(buttons.COMMON["cancel"], callback_data="cancel"))
    return keyboard


def create_statuses_menu() -> InlineKeyboardMarkup:
    """Создание меню статусов"""
    keyboard = InlineKeyboardMarkup(row_width=1)
    for key, value in buttons.DEV_STATUSES.items():
        keyboard.add(InlineKeyboardButton(value, callback_data=f"status_{key}"))
    keyboard.add(InlineKeyboardButton(buttons.COMMON["cancel"], callback_data="cancel"))
    return keyboard


def create_plugin_menu(plugin_id: int, user_id: int, is_author: bool = False, is_subscribed: bool = False) -> InlineKeyboardMarkup:
    """Создание меню для страницы плагина"""
    keyboard = InlineKeyboardMarkup(row_width=2)
    
    # Первая строка: Скачать и Подписаться/Отписаться
    keyboard.add(
        InlineKeyboardButton(buttons.PLUGIN_PAGE["download"], callback_data=f"download_{plugin_id}"),
        InlineKeyboardButton(
            buttons.PLUGIN_PAGE["unsubscribe"] if is_subscribed else buttons.PLUGIN_PAGE["subscribe"],
            callback_data=f"{'unsubscribe' if is_subscribed else 'subscribe'}_{plugin_id}"
        )
    )
    
    # Вторая строка: Автор, Отзывы, Оценить
    keyboard.add(
        InlineKeyboardButton(buttons.PLUGIN_PAGE["author"], callback_data=f"author_{plugin_id}"),
        InlineKeyboardButton(buttons.PLUGIN_PAGE["reviews"], callback_data=f"reviews_{plugin_id}"),
        InlineKeyboardButton(buttons.PLUGIN_PAGE["rate"], callback_data=f"rate_{plugin_id}")
    )
    
    # Третья строка: Управление (только для автора и админов)
    if is_author:
        keyboard.add(
            InlineKeyboardButton(buttons.PLUGIN_PAGE["manage"], callback_data=f"manage_{plugin_id}")
        )
    
    return keyboard


def create_manage_menu(plugin_id: int, is_archived: bool = False) -> InlineKeyboardMarkup:
    """Создание меню управления плагином"""
    keyboard = InlineKeyboardMarkup(row_width=2)
    
    # Первая строка: Архив/Вернуть и Удалить
    keyboard.add(
        InlineKeyboardButton(
            buttons.PLUGIN_PAGE["restore"] if is_archived else buttons.PLUGIN_PAGE["archive"],
            callback_data=f"{'restore' if is_archived else 'archive'}_{plugin_id}"
        ),
        InlineKeyboardButton(buttons.PLUGIN_PAGE["delete"], callback_data=f"delete_{plugin_id}")
    )
    
    # Вторая строка: Обновить и Назад
    keyboard.add(
        InlineKeyboardButton(buttons.PLUGIN_PAGE["update"], callback_data=f"update_{plugin_id}"),
        InlineKeyboardButton(buttons.COMMON["back"], callback_data=f"back_to_plugin_{plugin_id}")
    )
    
    return keyboard


def create_rating_menu(plugin_id: int) -> InlineKeyboardMarkup:
    """Создание меню оценки"""
    keyboard = InlineKeyboardMarkup(row_width=5)
    
    rating_buttons = []
    for i in range(1, 6):
        rating_buttons.append(InlineKeyboardButton(
            buttons.RATING[f"rate_{i}"], 
            callback_data=f"set_rating_{plugin_id}_{i}"
        ))
    
    keyboard.add(*rating_buttons)
    keyboard.add(InlineKeyboardButton(buttons.COMMON["cancel"], callback_data="cancel"))
    
    return keyboard


def create_pagination_menu(current_page: int, total_pages: int, base_callback: str) -> InlineKeyboardMarkup:
    """Создание меню пагинации"""
    keyboard = InlineKeyboardMarkup(row_width=3)
    
    buttons_row = []
    
    # Кнопка назад
    if current_page > 1:
        buttons_row.append(InlineKeyboardButton(
            buttons.PAGINATION["prev"], 
            callback_data=f"{base_callback}_page_{current_page - 1}"
        ))
    
    # Информация о странице
    buttons_row.append(InlineKeyboardButton(
        buttons.PAGINATION["page_info"].format(current=current_page, total=total_pages),
        callback_data="noop"
    ))
    
    # Кнопка вперед
    if current_page < total_pages:
        buttons_row.append(InlineKeyboardButton(
            buttons.PAGINATION["next"], 
            callback_data=f"{base_callback}_page_{current_page + 1}"
        ))
    
    keyboard.add(*buttons_row)
    keyboard.add(InlineKeyboardButton(buttons.COMMON["menu"], callback_data="menu"))
    
    return keyboard


# ========== ОСНОВНЫЕ ФУНКЦИИ ==========

async def cmd_start(message: types.Message, state: FSMContext):
    """Команда /start"""
    await state.finish()
    
    user = db.get_user(message.from_user.id)
    if not user:
        await RegistrationStates.waiting_display_name.set()
        await message.answer(MESSAGES["registration_required"], reply_markup=create_cancel_menu())
    else:
        await message.answer(MESSAGES["start"], reply_markup=create_main_menu())


async def cmd_report(message: types.Message):
    """Команда /report для отправки отчетов об ошибках"""
    text = message.get_args()
    if text:
        # Здесь можно добавить логирование или отправку админам
        await message.answer("✅ Ваш отчет об ошибке отправлен разработчикам. Спасибо!")
    else:
        await message.answer("⚠️ Используйте: /report <текст ошибки>")


# ========== РЕГИСТРАЦИЯ ==========

async def process_registration_display_name(message: types.Message, state: FSMContext):
    """Обработка ввода никнейма при регистрации"""
    display_name = message.text.strip()
    if len(display_name) < 2 or len(display_name) > 50:
        await message.answer("⚠️ Никнейм должен быть от 2 до 50 символов. Попробуйте еще раз:")
        return
    
    await state.update_data(display_name=display_name)
    await RegistrationStates.next()
    await message.answer(MESSAGES["registration_username"])


async def process_registration_username(message: types.Message, state: FSMContext):
    """Обработка ввода username при регистрации"""
    username = message.text.strip().replace("@", "")
    if len(username) < 3 or len(username) > 32:
        await message.answer("⚠️ Username должен быть от 3 до 32 символов. Попробуйте еще раз:")
        return
    
    user_data = await state.get_data()
    display_name = user_data["display_name"]
    
    success = db.create_user(message.from_user.id, username, display_name)
    if success:
        await state.finish()
        await message.answer(MESSAGES["registration_complete"], reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка при регистрации. Попробуйте еще раз.")


# ========== ПОИСК ==========

async def menu_search(message: types.Message, state: FSMContext):
    """Обработка нажатия кнопки 'Найти'"""
    await SearchStates.waiting_query.set()
    await message.answer(MESSAGES["search_prompt"], reply_markup=create_cancel_menu())


async def process_search_query(message: types.Message, state: FSMContext):
    """Обработка поискового запроса"""
    query = message.text.strip()
    if len(query) < 2:
        await message.answer("⚠️ Запрос слишком короткий. Попробуйте еще раз:")
        return
    
    results = db.search_plugins(query, 10)
    await state.finish()
    
    if not results:
        await message.answer(MESSAGES["search_no_results"], reply_markup=create_main_menu())
        return
    
    # Показываем результаты
    await message.answer(f"🔍 Возможно, вы искали.. (найдено {len(results)})")
    
    for plugin in results:
        text = format_plugin_preview(plugin)
        photo_id = plugin.get("photo_id")
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            f"📥 {plugin['name']}", 
            callback_data=f"plugin_{plugin['plugin_id']}"
        ))
        
        if photo_id:
            await message.answer_photo(photo_id, caption=text, reply_markup=keyboard)
        else:
            await message.answer(text, reply_markup=keyboard)


def format_plugin_preview(plugin: Dict[str, Any]) -> str:
    """Форматирование превью плагина"""
    return f"""<b>{plugin['name']}</b>

<blockquote>{plugin['description'][:100]}...</blockquote>

👤 Автор: @{plugin['author_username']}
📂 Категория: {buttons.CATEGORIES.get(plugin['category'], plugin['category'])}
👁 Просмотров: {plugin['views']}
📥 Скачиваний: {plugin['downloads']}
⭐ Рейтинг: {plugin['rating']:.1f} ({plugin['rating_count']} оценок)"""


# ========== ПОПУЛЯРНОЕ ==========

async def menu_popular(message: types.Message):
    """Обработка нажатия кнопки 'Популярное'"""
    plugins = db.get_popular_plugins(10)
    
    if not plugins:
        await message.answer("😔 Плагинов пока нет. Будьте первым!")
        return
    
    await message.answer("⭐ Популярные плагины:", reply_markup=create_main_menu())
    
    for plugin in plugins:
        text = format_plugin_preview(plugin)
        photo_id = plugin.get("photo_id")
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            f"📥 {plugin['name']}", 
            callback_data=f"plugin_{plugin['plugin_id']}"
        ))
        
        if photo_id:
            await message.answer_photo(photo_id, caption=text, reply_markup=keyboard)
        else:
            await message.answer(text, reply_markup=keyboard)


# ========== КАТЕГОРИИ ==========

async def menu_categories(message: types.Message):
    """Обработка нажатия кнопки 'Категории'"""
    await message.answer("📂 Выберите категорию:", reply_markup=create_categories_menu())


async def process_category_selection(callback_query: types.CallbackQuery):
    """Обработка выбора категории"""
    category = callback_query.data.replace("category_", "")
    plugins = db.get_plugins_by_category(category)
    
    await callback_query.answer()
    
    if not plugins:
        await callback_query.message.answer(
            f"😔 В категории '{buttons.CATEGORIES.get(category, category)}' пока нет плагинов."
        )
        return
    
    await callback_query.message.answer(
        f"📂 Плагины в категории '{buttons.CATEGORIES.get(category, category)}':"
    )
    
    for plugin in plugins[:5]:  # Показываем первые 5
        text = format_plugin_preview(plugin)
        photo_id = plugin.get("photo_id")
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            f"📥 {plugin['name']}", 
            callback_data=f"plugin_{plugin['plugin_id']}"
        ))
        
        if photo_id:
            await callback_query.message.answer_photo(photo_id, caption=text, reply_markup=keyboard)
        else:
            await callback_query.message.answer(text, reply_markup=keyboard)


# ========== ПОДПИСКИ ==========

async def menu_subscriptions(message: types.Message):
    """Обработка нажатия кнопки 'Подписки'"""
    subscriptions = db.get_user_subscriptions(message.from_user.id)
    
    if not subscriptions:
        await message.answer("🔕 У вас пока нет подписок. Подпишитесь на интересные плагины!")
        return
    
    await message.answer(f"🔔 Ваши подписки ({len(subscriptions)}):", reply_markup=create_main_menu())
    
    for plugin in subscriptions:
        text = format_plugin_preview(plugin)
        photo_id = plugin.get("photo_id")
        
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton(
            f"📥 {plugin['name']}", 
            callback_data=f"plugin_{plugin['plugin_id']}"
        ))
        
        if photo_id:
            await message.answer_photo(photo_id, caption=text, reply_markup=keyboard)
        else:
            await message.answer(text, reply_markup=keyboard)


# ========== ПРОФИЛЬ ==========

async def menu_profile(message: types.Message):
    """Обработка нажатия кнопки 'Мой профиль'"""
    user = db.get_user(message.from_user.id)
    if not user:
        await message.answer("⚠️ Профиль не найден. Пройдите регистрацию заново.")
        return
    
    stats = db.get_user_stats(message.from_user.id)
    
    text = f"""👤 <b>Ваш профиль</b>

<b>Никнейм:</b> {user.display_name}
<b>Username:</b> @{user.username}

📊 <b>Статистика:</b>
└ Плагинов: {stats.get('plugin_count', 0)}
└ Подписчиков: {stats.get('subscribers', 0)}
└ Скачиваний: {stats.get('total_downloads', 0)}
└ Просмотров: {stats.get('total_views', 0)}
└ Средний рейтинг: {stats.get('avg_rating', 0.0)}/5.0"""
    
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        InlineKeyboardButton(buttons.PROFILE["my_plugins"], callback_data="my_plugins"),
        InlineKeyboardButton(buttons.PROFILE["edit_profile"], callback_data="edit_profile"),
        InlineKeyboardButton(buttons.PROFILE["send_to_subscribers"], callback_data="broadcast_to_subscribers")
    )
    
    if user.banner_url:
        await message.answer_photo(user.banner_url, caption=text, reply_markup=keyboard)
    else:
        await message.answer(text, reply_markup=keyboard)


async def show_my_plugins(callback_query: types.CallbackQuery):
    """Показать плагины пользователя"""
    user_id = callback_query.from_user.id
    plugins = db.get_user_plugins(user_id, include_archived=True)
    
    await callback_query.answer()
    
    if not plugins:
        await callback_query.message.answer("📦 У вас пока нет плагинов.")
        return
    
    active_plugins = [p for p in plugins if not p["is_archived"]]
    archived_plugins = [p for p in plugins if p["is_archived"]]
    
    text = f"📦 <b>Ваши плагины</b>\n\n"
    text += f"<b>Активные:</b> {len(active_plugins)}\n"
    text += f"<b>В архиве:</b> {len(archived_plugins)}"
    
    keyboard = InlineKeyboardMarkup(row_width=1)
    
    for plugin in plugins:
        status_icon = "📦" if plugin["is_archived"] else "📥"
        keyboard.add(InlineKeyboardButton(
            f"{status_icon} {plugin['name']}",
            callback_data=f"plugin_{plugin['plugin_id']}"
        ))
    
    keyboard.add(InlineKeyboardButton(buttons.COMMON["back"], callback_data="back_to_profile"))
    
    await callback_query.message.answer(text, reply_markup=keyboard)


async def edit_profile_menu(callback_query: types.CallbackQuery):
    """Меню редактирования профиля"""
    await callback_query.answer()
    
    keyboard = InlineKeyboardMarkup(row_width=1)
    keyboard.add(
        InlineKeyboardButton(buttons.PROFILE["edit_username"], callback_data="edit_username"),
        InlineKeyboardButton(buttons.PROFILE["edit_display_name"], callback_data="edit_display_name"),
        InlineKeyboardButton(buttons.PROFILE["change_banner"], callback_data="edit_banner"),
        InlineKeyboardButton(buttons.COMMON["back"], callback_data="back_to_profile")
    )
    
    await callback_query.message.answer("✏️ Что вы хотите изменить?", reply_markup=keyboard)


async def start_edit_username(callback_query: types.CallbackQuery):
    """Начать изменение username"""
    await callback_query.answer()
    await ProfileEditStates.waiting_username.set()
    await callback_query.message.answer(
        "📝 Введите новый username (без @):",
        reply_markup=create_cancel_menu()
    )


async def process_edit_username(message: types.Message, state: FSMContext):
    """Обработка нового username"""
    username = message.text.strip().replace("@", "")
    if len(username) < 3 or len(username) > 32:
        await message.answer("⚠️ Username должен быть от 3 до 32 символов. Попробуйте еще раз:")
        return
    
    success = db.update_user(message.from_user.id, username=username)
    await state.finish()
    
    if success:
        await message.answer("✅ Username обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка. Попробуйте позже.", reply_markup=create_main_menu())


async def start_edit_display_name(callback_query: types.CallbackQuery):
    """Начать изменение отображаемого имени"""
    await callback_query.answer()
    await ProfileEditStates.waiting_display_name.set()
    await callback_query.message.answer(
        "📛 Введите новый никнейм:",
        reply_markup=create_cancel_menu()
    )


async def process_edit_display_name(message: types.Message, state: FSMContext):
    """Обработка нового отображаемого имени"""
    display_name = message.text.strip()
    if len(display_name) < 2 or len(display_name) > 50:
        await message.answer("⚠️ Никнейм должен быть от 2 до 50 символов. Попробуйте еще раз:")
        return
    
    success = db.update_user(message.from_user.id, display_name=display_name)
    await state.finish()
    
    if success:
        await message.answer("✅ Никнейм обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка. Попробуйте позже.", reply_markup=create_main_menu())


async def start_edit_banner(callback_query: types.CallbackQuery):
    """Начать изменение баннера"""
    await callback_query.answer()
    await ProfileEditStates.waiting_banner.set()
    await callback_query.message.answer(
        "🖼 Отправьте изображение для баннера профиля или нажмите 'Пропустить':",
        reply_markup=create_cancel_menu()
    )


async def process_edit_banner(message: types.Message, state: FSMContext):
    """Обработка нового баннера"""
    if message.text and message.text.lower() == buttons.COMMON["skip"].lower():
        await state.finish()
        await message.answer("✅ Действие отменено.", reply_markup=create_main_menu())
        return
    
    if not message.photo:
        await message.answer("⚠️ Пожалуйста, отправьте изображение или нажмите 'Пропустить':")
        return
    
    # Получаем фото с наилучшим качеством
    photo = message.photo[-1]
    photo_id = photo.file_id
    
    success = db.update_user(message.from_user.id, banner_url=photo_id)
    await state.finish()
    
    if success:
        await message.answer("✅ Баннер профиля обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка. Попробуйте позже.", reply_markup=create_main_menu())


# ========== ОТОБРАЖЕНИЕ ПЛАГИНА ==========

async def show_plugin_page(callback_query: types.CallbackQuery, plugin_id: int):
    """Показать страницу плагина"""
    plugin = db.get_plugin_with_author(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    # Увеличиваем счетчик просмотров
    db.increment_views(plugin_id)
    
    user_id = callback_query.from_user.id
    is_author = plugin["author_id"] == user_id
    is_subscribed = db.is_subscribed(user_id, plugin_id)
    
    text = format_plugin_full(plugin)
    photo_id = plugin.get("photo_id")
    
    keyboard = create_plugin_menu(plugin_id, user_id, is_author, is_subscribed)
    
    if photo_id:
        await callback_query.message.answer_photo(
            photo_id, 
            caption=text, 
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    else:
        await callback_query.message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    
    await callback_query.answer()


def format_plugin_full(plugin: Dict[str, Any]) -> str:
    """Форматирование полной информации о плагине"""
    return f"""<b>{plugin['name']}</b>

{plugin['description']}

⚙️ <b>Статус разработки:</b> {buttons.DEV_STATUSES.get(plugin['status'], plugin['status'])}
👤 <b>Автор:</b> @{plugin['author_username']}
📂 <b>Категория:</b> {buttons.CATEGORIES.get(plugin['category'], plugin['category'])}
📅 <b>Последнее обновление:</b> {plugin['updated_at']}

📊 <b>Статистика:</b>
└ 👁 Просмотров: {plugin['views']}
└ 📥 Скачиваний: {plugin['downloads']}
└ ⭐ Рейтинг: {plugin['rating']:.1f}/5.0 ({plugin['rating_count']} оценок)

🏷 <b>Теги:</b> {plugin['tags'] if plugin['tags'] else 'Нет тегов'}"""


# ========== ПОДПИСКА/ОТПИСКА ==========

async def toggle_subscription(callback_query: types.CallbackQuery, plugin_id: int):
    """Подписаться/Отписаться от плагина"""
    user_id = callback_query.from_user.id
    is_subscribed = db.is_subscribed(user_id, plugin_id)
    
    if is_subscribed:
        success = db.unsubscribe(user_id, plugin_id)
        text = "🔕 Вы отписались от обновлений."
    else:
        success = db.subscribe(user_id, plugin_id)
        text = "🔔 Вы подписались на обновления!"
    
    if success:
        await callback_query.answer(text)
        
        # Обновляем клавиатуру
        plugin = db.get_plugin_with_author(plugin_id)
        if plugin:
            is_author = plugin["author_id"] == user_id
            keyboard = create_plugin_menu(plugin_id, user_id, is_author, not is_subscribed)
            
            try:
                await callback_query.message.edit_reply_markup(reply_markup=keyboard)
            except:
                pass  # Игнорируем ошибку, если сообщение не изменилось
    else:
        await callback_query.answer("⚠️ Произошла ошибка.", show_alert=True)


# ========== ОЦЕНКА ==========

async def rate_plugin(callback_query: types.CallbackQuery, plugin_id: int):
    """Показать меню оценки"""
    keyboard = create_rating_menu(plugin_id)
    await callback_query.message.answer("⭐ Оцените плагин:", reply_markup=keyboard)
    await callback_query.answer()


async def set_rating(callback_query: types.CallbackQuery, plugin_id: int, rating: int):
    """Установить оценку"""
    user_id = callback_query.from_user.id
    success = db.add_rating(plugin_id, user_id, rating)
    
    if success:
        await callback_query.answer(f"⭐ Спасибо за оценку: {rating}/5!")
        
        # Удаляем клавиатуру оценки
        try:
            await callback_query.message.delete()
        except:
            pass
    else:
        await callback_query.answer("⚠️ Произошла ошибка.", show_alert=True)


# ========== АВТОР ==========

async def show_author_info(callback_query: types.CallbackQuery, plugin_id: int):
    """Показать информацию об авторе"""
    plugin = db.get_plugin_with_author(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    author_id = plugin["author_id"]
    author_plugins = db.get_user_plugins(author_id)
    author_stats = db.get_user_stats(author_id)
    
    # Получаем автора из БД для баннера
    author = db.get_user(author_id)
    
    text = f"""<b>{plugin['author_display_name']}</b>

👤 <b>Username:</b> @{plugin['author_username']}
👥 <b>Подписчиков:</b> {author_stats.get('subscribers', 0)}

📊 <b>Статистика плагинов:</b>
└ 📥 Всего скачиваний: {author_stats.get('total_downloads', 0)}
└ 👁 Всего просмотров: {author_stats.get('total_views', 0)}
└ ⭐ Средний рейтинг: {author_stats.get('avg_rating', 0.0)}/5.0

📦 <b>Плагины автора:</b>"""
    
    keyboard = InlineKeyboardMarkup(row_width=1)
    
    # Добавляем кнопку подписаться/отписаться на автора
    # (Здесь можно добавить подписку на автора, если реализована)
    
    # Добавляем плагины автора
    for author_plugin in author_plugins[:5]:
        keyboard.add(InlineKeyboardButton(
            f"📥 {author_plugin['name']}",
            callback_data=f"plugin_{author_plugin['plugin_id']}"
        ))
    
    keyboard.add(InlineKeyboardButton(buttons.COMMON["back"], callback_data=f"back_to_plugin_{plugin_id}"))
    
    if author and author.banner_url:
        await callback_query.message.answer_photo(
            author.banner_url, 
            caption=text, 
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    else:
        await callback_query.message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    
    await callback_query.answer()


# ========== ОТЗЫВЫ ==========

async def show_reviews(callback_query: types.CallbackQuery, plugin_id: int):
    """Показать отзывы о плагине"""
    plugin = db.get_plugin_with_author(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    text = f"""💬 <b>Отзывы о плагине "{plugin['name']}"</b>

⭐ <b>Рейтинг:</b> {plugin['rating']:.1f}/5.0
📊 <b>Оценок:</b> {plugin['rating_count']}

"""
    
    if plugin["rating_count"] == 0:
        text += "😔 Пока нет оценок. Будьте первым!"
    else:
        # Получаем распределение оценок
        with db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT rating, COUNT(*) as count 
                FROM ratings 
                WHERE plugin_id = ? 
                GROUP BY rating 
                ORDER BY rating DESC
            """, (plugin_id,))
            
            ratings = cursor.fetchall()
            for rating, count in ratings:
                bar = "█" * count + "░" * (10 - min(count, 10))
                text += f"{rating}⭐ {bar} {count}\n"
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton(buttons.COMMON["back"], callback_data=f"back_to_plugin_{plugin_id}"))
    
    await callback_query.message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    await callback_query.answer()


# ========== ОТМЕНА ==========

async def cancel_action(message: types.Message, state: FSMContext):
    """Отмена текущего действия"""
    await state.finish()
    await message.answer(MESSAGES["cancelled"], reply_markup=create_main_menu())