#!/usr/bin/env python3
"""
Exteragram Plugin Library Bot

Главный скрипт бота, объединяющий все модули.
Для запуска: python bot.py

Требования:
- aiogram==2.25.1
- python-dotenv
"""

import asyncio
import logging
import os
import sys
from typing import List, Dict, Any

from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Command
from aiogram.utils import executor
from aiogram.utils.exceptions import MessageNotModified, BotBlocked, ChatNotFound

# Импортируем модули
import buttons
import user_functions
import admin_functions
from config import BOT_TOKEN, ADMIN_IDS, MESSAGES
from database import Database, Plugin


# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Инициализация
storage = MemoryStorage()
bot = Bot(token=BOT_TOKEN, parse_mode="HTML")
dp = Dispatcher(bot, storage=storage)

# Инициализация БД
from config import DATABASE_PATH
db = Database(DATABASE_PATH)


# ========== ОБРАБОТЧИКИ КОМАНД ==========

@dp.message_handler(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    """Команда /start"""
    await user_functions.cmd_start(message, state)


@dp.message_handler(Command("report"))
async def cmd_report(message: types.Message):
    """Команда /report для отправки отчетов об ошибках"""
    await user_functions.cmd_report(message)


@dp.message_handler(Command("admin"))
async def cmd_admin(message: types.Message):
    """Команда /admin - админская панель"""
    if message.from_user.id in ADMIN_IDS:
        keyboard = admin_functions.create_admin_menu()
        await message.answer("⚖️ Админская панель:", reply_markup=keyboard)
    else:
        await message.answer(MESSAGES["access_denied"])


# ========== ОБРАБОТЧИКИ СООБЩЕНИЙ (Reply Keyboard) ==========

@dp.message_handler(lambda message: message.text == buttons.MAIN_MENU["search"])
async def menu_search(message: types.Message, state: FSMContext):
    """Поиск плагинов"""
    await user_functions.menu_search(message, state)


@dp.message_handler(lambda message: message.text == buttons.MAIN_MENU["upload"])
async def menu_upload(message: types.Message, state: FSMContext):
    """Загрузка плагина"""
    await user_functions.UploadStates.waiting_file.set()
    await message.answer(MESSAGES["upload_step1"], reply_markup=user_functions.create_cancel_menu())


@dp.message_handler(lambda message: message.text == buttons.MAIN_MENU["popular"])
async def menu_popular(message: types.Message):
    """Популярные плагины"""
    await user_functions.menu_popular(message)


@dp.message_handler(lambda message: message.text == buttons.MAIN_MENU["categories"])
async def menu_categories(message: types.Message):
    """Категории плагинов"""
    await user_functions.menu_categories(message)


@dp.message_handler(lambda message: message.text == buttons.MAIN_MENU["subscriptions"])
async def menu_subscriptions(message: types.Message):
    """Подписки пользователя"""
    await user_functions.menu_subscriptions(message)


@dp.message_handler(lambda message: message.text == buttons.MAIN_MENU["profile"])
async def menu_profile(message: types.Message):
    """Профиль пользователя"""
    await user_functions.menu_profile(message)


@dp.message_handler(lambda message: message.text == buttons.COMMON["cancel"])
async def cancel_action(message: types.Message, state: FSMContext):
    """Отмена действия"""
    await user_functions.cancel_action(message, state)


# ========== ОБРАБОТЧИКИ СОСТОЯНИЙ ==========

# Регистрация
@dp.message_handler(state=user_functions.RegistrationStates.waiting_display_name)
async def process_registration_display_name(message: types.Message, state: FSMContext):
    await user_functions.process_registration_display_name(message, state)


@dp.message_handler(state=user_functions.RegistrationStates.waiting_username)
async def process_registration_username(message: types.Message, state: FSMContext):
    await user_functions.process_registration_username(message, state)


# Поиск
@dp.message_handler(state=user_functions.SearchStates.waiting_query)
async def process_search_query(message: types.Message, state: FSMContext):
    await user_functions.process_search_query(message, state)


# Загрузка плагина
@dp.message_handler(content_types=[types.ContentType.DOCUMENT], state=user_functions.UploadStates.waiting_file)
async def process_upload_file(message: types.Message, state: FSMContext):
    """Обработка загрузки файла плагина"""
    file_info = message.document
    
    # Проверяем размер файла (макс 50MB)
    if file_info.file_size > 50 * 1024 * 1024:
        await message.answer("⚠️ Файл слишком большой. Максимальный размер - 50MB.")
        return
    
    # Сохраняем данные файла
    await state.update_data(
        file_id=file_info.file_id,
        file_name=file_info.file_name,
        file_size=file_info.file_size
    )
    
    # Переходим к следующему шагу
    await user_functions.UploadStates.next()
    await message.answer(MESSAGES["upload_step2"])


@dp.message_handler(content_types=[types.ContentType.TEXT, types.ContentType.PHOTO], 
                   state=user_functions.UploadStates.waiting_name_and_photo)
async def process_upload_name_and_photo(message: types.Message, state: FSMContext):
    """Обработка названия и фото"""
    if message.text:
        name = message.text.strip()
        if len(name) < 2 or len(name) > 100:
            await message.answer("⚠️ Название должно быть от 2 до 100 символов.")
            return
        
        await state.update_data(name=name)
    
    if message.photo:
        photo_id = message.photo[-1].file_id
        await state.update_data(photo_id=photo_id)
    
    # Если есть название, переходим к следующему шагу
    data = await state.get_data()
    if "name" in data:
        await user_functions.UploadStates.next()
        keyboard = user_functions.create_categories_menu()
        await message.answer(MESSAGES["upload_step3"], reply_markup=keyboard)
    else:
        await message.answer("✏️ Отправьте название плагина:")


@dp.message_handler(state=user_functions.UploadStates.waiting_tags)
async def process_upload_tags(message: types.Message, state: FSMContext):
    """Обработка тегов"""
    tags = message.text.strip().lower()
    await state.update_data(tags=tags)
    
    # Получаем все данные и создаем заявку
    data = await state.get_data()
    
    submission_data = {
        "user_id": message.from_user.id,
        "plugin_name": data["name"],
        "description": data["description"],
        "file_id": data["file_id"],
        "file_name": data["file_name"],
        "file_size": data["file_size"],
        "photo_id": data.get("photo_id"),
        "category": data["category"],
        "status": data["status"],
        "tags": tags
    }
    
    submission_id = db.create_submission(submission_data)
    if submission_id:
        submission_data["submission_id"] = submission_id
        submission_data["username"] = message.from_user.username or str(message.from_user.id)
        submission_data["display_name"] = message.from_user.full_name
        
        # Уведомляем админов
        await admin_functions.notify_admins_about_submission(submission_data)
        
        await message.answer(MESSAGES["upload_complete"], reply_markup=user_functions.create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка при создании заявки. Попробуйте позже.")
    
    await state.finish()


# Редактирование профиля
@dp.message_handler(state=user_functions.ProfileEditStates.waiting_username)
async def process_edit_username(message: types.Message, state: FSMContext):
    await user_functions.process_edit_username(message, state)


@dp.message_handler(state=user_functions.ProfileEditStates.waiting_display_name)
async def process_edit_display_name(message: types.Message, state: FSMContext):
    await user_functions.process_edit_display_name(message, state)


@dp.message_handler(content_types=[types.ContentType.PHOTO, types.ContentType.TEXT], 
                   state=user_functions.ProfileEditStates.waiting_banner)
async def process_edit_banner(message: types.Message, state: FSMContext):
    await user_functions.process_edit_banner(message, state)


# Редактирование заявок админом
@dp.message_handler(state=admin_functions.EditSubmissionStates.waiting_value)
async def save_edited_field(message: types.Message, state: FSMContext):
    await admin_functions.save_edited_field(message, state)


# Рассылка
@dp.message_handler(state=admin_functions.BroadcastStates.waiting_message)
async def process_broadcast(message: types.Message, state: FSMContext):
    await admin_functions.process_broadcast(message, state)


# ========== ОБРАБОТЧИКИ CALLBACK QUERY ==========

# Категории
@dp.callback_query_handler(lambda c: c.data.startswith("category_"))
async def process_category_selection(callback_query: types.CallbackQuery):
    await user_functions.process_category_selection(callback_query)
    
    # Если это часть загрузки, переходим к следующему шагу
    state = dp.current_state(chat=callback_query.message.chat.id, user=callback_query.from_user.id)
    current_state = await state.get_state()
    
    if current_state == "UploadStates:waiting_category":
        category = callback_query.data.replace("category_", "")
        await state.update_data(category=category)
        await user_functions.UploadStates.next()
        
        keyboard = user_functions.create_statuses_menu()
        await callback_query.message.answer(MESSAGES["upload_step4"], reply_markup=keyboard)


# Статусы
@dp.callback_query_handler(lambda c: c.data.startswith("status_"))
async def process_status_selection(callback_query: types.CallbackQuery):
    status = callback_query.data.replace("status_", "")
    
    # Если это часть загрузки, переходим к следующему шагу
    state = dp.current_state(chat=callback_query.message.chat.id, user=callback_query.from_user.id)
    current_state = await state.get_state()
    
    if current_state == "UploadStates:waiting_status":
        await state.update_data(status=status)
        await user_functions.UploadStates.next()
        
        await callback_query.message.answer(MESSAGES["upload_step5"])
        await callback_query.answer()


# Страница плагина
@dp.callback_query_handler(lambda c: c.data.startswith("plugin_"))
async def show_plugin_page(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("plugin_", ""))
    await user_functions.show_plugin_page(callback_query, plugin_id)


# Подписка/Отписка
@dp.callback_query_handler(lambda c: c.data.startswith("subscribe_"))
async def subscribe_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("subscribe_", ""))
    await user_functions.toggle_subscription(callback_query, plugin_id)


@dp.callback_query_handler(lambda c: c.data.startswith("unsubscribe_"))
async def unsubscribe_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("unsubscribe_", ""))
    await user_functions.toggle_subscription(callback_query, plugin_id)


# Оценка
@dp.callback_query_handler(lambda c: c.data.startswith("rate_"))
async def rate_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("rate_", ""))
    await user_functions.rate_plugin(callback_query, plugin_id)


@dp.callback_query_handler(lambda c: c.data.startswith("set_rating_"))
async def set_rating(callback_query: types.CallbackQuery):
    parts = callback_query.data.split("_")
    plugin_id = int(parts[2])
    rating = int(parts[3])
    await user_functions.set_rating(callback_query, plugin_id, rating)


# Автор
@dp.callback_query_handler(lambda c: c.data.startswith("author_"))
async def show_author_info(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("author_", ""))
    await user_functions.show_author_info(callback_query, plugin_id)


# Отзывы
@dp.callback_query_handler(lambda c: c.data.startswith("reviews_"))
async def show_reviews(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("reviews_", ""))
    await user_functions.show_reviews(callback_query, plugin_id)


# Управление плагином
@dp.callback_query_handler(lambda c: c.data.startswith("manage_"))
async def manage_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("manage_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    # Проверяем, является ли пользователь автором или админом
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in ADMIN_IDS
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    keyboard = admin_functions.create_manage_menu(plugin_id, plugin.is_archived)
    await callback_query.message.answer("⚙️ Управление плагином:", reply_markup=keyboard)
    await callback_query.answer()


# Архив/Восстановление
@dp.callback_query_handler(lambda c: c.data.startswith("archive_"))
async def archive_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("archive_", ""))
    
    # Проверяем права
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in ADMIN_IDS
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.update_plugin(plugin_id, is_archived=True)
    
    if success:
        await callback_query.answer("📦 Плагин перемещен в архив.")
        
        # Обновляем клавиатуру
        try:
            keyboard = admin_functions.create_manage_menu(plugin_id, True)
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при архивировании.", show_alert=True)


@dp.callback_query_handler(lambda c: c.data.startswith("restore_"))
async def restore_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("restore_", ""))
    
    # Проверяем права
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in ADMIN_IDS
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.update_plugin(plugin_id, is_archived=False)
    
    if success:
        await callback_query.answer("📂 Плагин восстановлен из архива.")
        
        # Обновляем клавиатуру
        try:
            keyboard = admin_functions.create_manage_menu(plugin_id, False)
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при восстановлении.", show_alert=True)


# Удаление
@dp.callback_query_handler(lambda c: c.data.startswith("delete_"))
async def delete_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("delete_", ""))
    
    # Проверяем права
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in ADMIN_IDS
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.delete_plugin(plugin_id)
    
    if success:
        await callback_query.answer("🗑 Плагин удален.")
        await callback_query.message.delete()
    else:
        await callback_query.answer("⚠️ Ошибка при удалении.", show_alert=True)


# Обновление плагина
@dp.callback_query_handler(lambda c: c.data.startswith("update_"))
async def update_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("update_", ""))
    
    # Проверяем права
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    if plugin.author_id != callback_query.from_user.id:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    # Запускаем процесс обновления (упрощенная версия)
    await user_functions.UploadStates.waiting_file.set()
    await callback_query.message.answer(
        "📤 Отправьте новую версию файла плагина:",
        reply_markup=user_functions.create_cancel_menu()
    )
    await callback_query.answer()
    
    # Сохраняем ID плагина для обновления
    state = dp.current_state(chat=callback_query.message.chat.id, user=callback_query.from_user.id)
    await state.update_data(update_plugin_id=plugin_id)


# Возврат к плагину
@dp.callback_query_handler(lambda c: c.data.startswith("back_to_plugin_"))
async def back_to_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("back_to_plugin_", ""))
    await user_functions.show_plugin_page(callback_query, plugin_id)


# Профиль
@dp.callback_query_handler(lambda c: c.data == "my_plugins")
async def my_plugins(callback_query: types.CallbackQuery):
    await user_functions.show_my_plugins(callback_query)


@dp.callback_query_handler(lambda c: c.data == "edit_profile")
async def edit_profile(callback_query: types.CallbackQuery):
    await user_functions.edit_profile_menu(callback_query)


@dp.callback_query_handler(lambda c: c.data == "edit_username")
async def edit_username(callback_query: types.CallbackQuery):
    await user_functions.start_edit_username(callback_query)


@dp.callback_query_handler(lambda c: c.data == "edit_display_name")
async def edit_display_name(callback_query: types.CallbackQuery):
    await user_functions.start_edit_display_name(callback_query)


@dp.callback_query_handler(lambda c: c.data == "edit_banner")
async def edit_banner(callback_query: types.CallbackQuery):
    await user_functions.start_edit_banner(callback_query)


@dp.callback_query_handler(lambda c: c.data == "back_to_profile")
async def back_to_profile(callback_query: types.CallbackQuery):
    await callback_query.answer()
    await user_functions.menu_profile(callback_query.message)


@dp.callback_query_handler(lambda c: c.data == "broadcast_to_subscribers")
async def broadcast_to_subscribers(callback_query: types.CallbackQuery):
    await user_functions.BroadcastStates.waiting_message.set()
    await callback_query.message.answer(
        "📢 Отправьте сообщение для ваших подписчиков:",
        reply_markup=user_functions.create_cancel_menu()
    )
    await callback_query.answer()


@dp.message_handler(state=user_functions.BroadcastStates.waiting_message)
async def process_subscriber_broadcast(message: types.Message, state: FSMContext):
    """Рассылка подписчикам"""
    user = db.get_user(message.from_user.id)
    if not user or user.subscribers == 0:
        await message.answer("⚠️ У вас нет подписчиков.", reply_markup=user_functions.create_main_menu())
        await state.finish()
        return
    
    # Получаем подписчиков (упрощенная версия - нужно доработать в БД)
    await message.answer(
        f"✅ Сообщение отправлено {user.subscribers} подписчикам!",
        reply_markup=user_functions.create_main_menu()
    )
    await state.finish()


# Главное меню
@dp.callback_query_handler(lambda c: c.data == "menu")
async def back_to_menu(callback_query: types.CallbackQuery):
    await callback_query.answer(MESSAGES["back_to_menu"])
    await callback_query.message.answer(MESSAGES["start"], reply_markup=user_functions.create_main_menu())


# Админские callback'и
@dp.callback_query_handler(lambda c: c.data == "admin_submissions")
async def admin_submissions(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in ADMIN_IDS:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    submissions = db.get_pending_submissions()
    if not submissions:
        await callback_query.message.answer("📋 Нет ожидающих заявок.")
        await callback_query.answer()
        return
    
    text = f"📋 <b>Ожидающие заявки:</b> {len(submissions)}\n\n"
    
    keyboard = InlineKeyboardMarkup(row_width=1)
    for sub in submissions:
        keyboard.add(InlineKeyboardButton(
            f"#{sub['submission_id']} - {sub['plugin_name']} (от @{sub['username']})",
            callback_data=f"view_sub_{sub['submission_id']}"
        ))
    
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()


@dp.callback_query_handler(lambda c: c.data.startswith("view_sub_"))
async def view_submission(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in ADMIN_IDS:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    submission_id = int(callback_query.data.replace("view_sub_", ""))
    submission = db.get_submission(submission_id)
    
    if not submission:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return
    
    text = f"""📋 <b>Заявка #{submission_id}</b>

<b>От:</b> @{submission['username']} ({submission['display_name']})
<b>Плагин:</b> {submission['plugin_name']}
<b>Категория:</b> {buttons.CATEGORIES.get(submission['category'], submission['category'])}
<b>Статус:</b> {buttons.DEV_STATUSES.get(submission['status'], submission['status'])}

<b>Описание:</b>
{submission['description']}

<b>Теги:</b> {submission.get('tags', 'Нет тегов')}

<b>Файл:</b> {submission['file_name']}"""
    
    keyboard = admin_functions.create_submission_review_menu(submission_id)
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()


@dp.callback_query_handler(lambda c: c.data.startswith("approve_sub_"))
async def approve_submission(callback_query: types.CallbackQuery):
    submission_id = int(callback_query.data.replace("approve_sub_", ""))
    await admin_functions.approve_submission(callback_query, submission_id)


@dp.callback_query_handler(lambda c: c.data.startswith("reject_sub_"))
async def reject_submission(callback_query: types.CallbackQuery):
    submission_id = int(callback_query.data.replace("reject_sub_", ""))
    await admin_functions.reject_submission(callback_query, submission_id)


@dp.callback_query_handler(lambda c: c.data.startswith("edit_sub_"))
async def edit_submission(callback_query: types.CallbackQuery):
    submission_id = int(callback_query.data.replace("edit_sub_", ""))
    await admin_functions.edit_submission(callback_query, submission_id)


@dp.callback_query_handler(lambda c: c.data.startswith("edit_field_"))
async def edit_submission_field(callback_query: types.CallbackQuery):
    parts = callback_query.data.split("_")
    submission_id = int(parts[2])
    field = parts[3]
    await admin_functions.edit_submission_field(callback_query, submission_id, field)


@dp.callback_query_handler(lambda c: c.data == "admin_updates")
async def admin_updates(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in ADMIN_IDS:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    updates = db.get_pending_updates()
    if not updates:
        await callback_query.message.answer("🔄 Нет ожидающих обновлений.")
        await callback_query.answer()
        return
    
    text = f"🔄 <b>Ожидающие обновления:</b> {len(updates)}\n\n"
    
    keyboard = InlineKeyboardMarkup(row_width=1)
    for upd in updates:
        keyboard.add(InlineKeyboardButton(
            f"#{upd['update_id']} - {upd['plugin_name']} (от @{upd['username']})",
            callback_data=f"view_upd_{upd['update_id']}"
        ))
    
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()


@dp.callback_query_handler(lambda c: c.data.startswith("view_upd_"))
async def view_update(callback_query: types.CallbackQuery):
    if callback_query.from_user.id not in ADMIN_IDS:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    update_id = int(callback_query.data.replace("view_upd_", ""))
    update_req = db.get_update_request(update_id)
    
    if not update_req:
        await callback_query.answer("Обновление не найдено", show_alert=True)
        return
    
    text = f"""🔄 <b>Обновление #{update_id}</b>

<b>Плагин:</b> {update_req['plugin_name']}
<b>От:</b> @{update_req['username']} ({update_req['display_name']})

<b>Описание обновления:</b>
{update_req.get('description', 'Без описания')}

<b>Файл:</b> {update_req['file_name']}"""
    
    keyboard = admin_functions.create_update_review_menu(update_id)
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()


@dp.callback_query_handler(lambda c: c.data.startswith("approve_upd_"))
async def approve_update(callback_query: types.CallbackQuery):
    update_id = int(callback_query.data.replace("approve_upd_", ""))
    await admin_functions.approve_update(callback_query, update_id)


@dp.callback_query_handler(lambda c: c.data.startswith("reject_upd_"))
async def reject_update(callback_query: types.CallbackQuery):
    update_id = int(callback_query.data.replace("reject_upd_", ""))
    await admin_functions.reject_update(callback_query, update_id)


@dp.callback_query_handler(lambda c: c.data == "admin_broadcast")
async def admin_broadcast(callback_query: types.CallbackQuery):
    await admin_functions.admin_broadcast(callback_query)


@dp.callback_query_handler(lambda c: c.data == "admin_stats")
async def admin_stats(callback_query: types.CallbackQuery):
    await admin_functions.admin_stats(callback_query)


# Подтверждение изменений пользователем
@dp.callback_query_handler(lambda c: c.data.startswith("confirm_edit_"))
async def confirm_edit(callback_query: types.CallbackQuery):
    parts = callback_query.data.split("_")
    submission_id = int(parts[2])
    field = parts[3]
    new_value = " ".join(parts[4:])
    
    # Получаем заявку
    submission = db.get_submission(submission_id)
    if not submission:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return
    
    # Обновляем заявку
    db.update_submission(submission_id, **{field: new_value, "state": "approved"})
    
    # Создаем плагин
    plugin = Plugin(
        name=submission["plugin_name"],
        description=submission["description"],
        file_id=submission["file_id"],
        file_name=submission["file_name"],
        file_size=submission["file_size"],
        photo_id=submission.get("photo_id"),
        author_id=submission["user_id"],
        category=submission["category"],
        status=submission["status"],
        tags=submission.get("tags", "")
    )
    
    plugin_id = db.create_plugin(plugin)
    
    if plugin_id:
        await callback_query.answer("✅ Изменения приняты! Плагин опубликован.")
        
        # Уведомляем пользователя
        try:
            await callback_query.message.edit_text(
                f"✅ Ваш плагин '{submission['plugin_name']}' одобрен и опубликован!\n\n"
                f"Изменения в {field} были приняты."
            )
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при публикации плагина.", show_alert=True)


@dp.callback_query_handler(lambda c: c.data.startswith("reject_edit_"))
async def reject_edit(callback_query: types.CallbackQuery):
    submission_id = int(callback_query.data.replace("reject_edit_", ""))
    
    # Обновляем состояние заявки
    db.update_submission(submission_id, state="rejected")
    
    await callback_query.answer("❌ Изменения отклонены.")
    
    try:
        await callback_query.message.edit_text(
            "❌ Изменения были отклонены. Пожалуйста, свяжитесь с поддержкой для уточнения."
        )
    except:
        pass


# Заглушки
@dp.callback_query_handler(lambda c: c.data == "noop")
async def noop(callback_query: types.CallbackQuery):
    await callback_query.answer()


# ========== ОБРАБОТЧИКИ ОШИБОК ==========

@dp.errors_handler(exception=MessageNotModified)
async def message_not_modified_handler(update, error):
    """Игнорируем ошибку при попытке отредактировать сообщение тем же текстом"""
    return True


@dp.errors_handler(exception=BotBlocked)
async def bot_blocked_handler(update, error):
    """Обработка блокировки бота пользователем"""
    logger.warning(f"Bot blocked by user: {update}")
    return True


@dp.errors_handler(exception=ChatNotFound)
async def chat_not_found_handler(update, error):
    """Обработка ненайденного чата"""
    logger.warning(f"Chat not found: {update}")
    return True


@dp.errors_handler()
async def error_handler(update, error):
    """Общий обработчик ошибок"""
    logger.error(f"Update: {update} caused error: {error}")
    
    # Пытаемся отправить сообщение об ошибке пользователю
    try:
        if update and update.message:
            await update.message.answer(MESSAGES["unknown_error"])
        elif update and update.callback_query:
            await update.callback_query.answer(MESSAGES["unknown_error"], show_alert=True)
    except:
        pass
    
    return True


# ========== ЗАПУСК ==========

async def on_startup(dp):
    """Действия при запуске бота"""
    logger.info("Bot starting...")
    
    # Устанавливаем команды бота
    commands = [
        types.BotCommand("start", "Запустить бота"),
        types.BotCommand("report", "Сообщить об ошибке"),
    ]
    
    if ADMIN_IDS:
        commands.append(types.BotCommand("admin", "Админская панель"))
    
    await bot.set_my_commands(commands)
    
    # Проверяем подключение к БД
    try:
        test_user = db.get_user(1)
        logger.info("Database connected successfully")
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        sys.exit(1)
    
    logger.info("Bot started successfully")


async def on_shutdown(dp):
    """Действия при остановке бота"""
    logger.info("Bot shutting down...")
    await bot.close()
    await dp.storage.close()
    await dp.storage.wait_closed()
    logger.info("Bot stopped")


if __name__ == "__main__":
    try:
        executor.start_polling(
            dp,
            on_startup=on_startup,
            on_shutdown=on_shutdown,
            skip_updates=True
        )
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)