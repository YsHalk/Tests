"""
Exteragram Plugin Library Bot

Telegram-бот для библиотеки плагинов Exteragram.

Модули:
- bot.py: Главный скрипт бота
- config.py: Конфигурация
- buttons.py: Кнопки интерфейса
- database.py: Работа с БД
- user_functions.py: Функции для пользователей
- admin_functions.py: Функции для админов

Автор: Exteragram Team
Версия: 2.1
"""

__version__ = "2.1"
__author__ = "Exteragram Team"
__description__ = "Telegram-бот для библиотеки плагинов Exteragram"
