#!/usr/bin/env python3
"""
Валидация кода без импорта модулей
Проверяет синтаксис и структуру проекта
"""

import ast
import os
import re

def check_syntax(filename):
    """Проверяет синтаксис Python файла"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        ast.parse(content)
        return True, "OK"
    except SyntaxError as e:
        return False, f"Синтаксическая ошибка: {e}"
    except Exception as e:
        return False, f"Ошибка чтения: {e}"

def check_duplicate_handlers(filename):
    """Проверяет наличие дублирующихся обработчиков"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Ищем декораторы callback_query handlers
        patterns = [
            r'@router\.callback_query\(F\.data\.startswith\("([^"]+)"\)',
            r'@router\.message\(ReviewStates\.waiting_text\)',
        ]
        
        handlers = {}
        for pattern in patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                if isinstance(match, tuple):
                    match = match[0]
                if match in handlers:
                    handlers[match] += 1
                else:
                    handlers[match] = 1
        
        duplicates = {k: v for k, v in handlers.items() if v > 1}
        return duplicates
    except Exception as e:
        return {}

def check_functions(filename):
    """Проверяет наличие дублирующихся функций"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Ищем определения функций
        func_pattern = r'^async def\s+(\w+)\s*\('
        functions = re.findall(func_pattern, content, re.MULTILINE)
        
        func_count = {}
        for func in functions:
            if func in func_count:
                func_count[func] += 1
            else:
                func_count[func] = 1
        
        duplicates = {k: v for k, v in func_count.items() if v > 1}
        return duplicates
    except Exception as e:
        return {}

def main():
    print("🔍 Валидация кода Exteragram Plugin Library Bot")
    print("=" * 60)
    
    files_to_check = [
        'bot.py',
        'user_functions.py', 
        'admin_functions.py',
        'database.py',
        'config.py',
        'buttons.py'
    ]
    
    all_good = True
    
    for filename in files_to_check:
        if not os.path.exists(filename):
            print(f"❌ {filename}: файл не найден")
            all_good = False
            continue
            
        print(f"\n📄 Проверка {filename}:")
        
        # Проверка синтаксиса
        syntax_ok, syntax_msg = check_syntax(filename)
        if syntax_ok:
            print(f"  ✅ Синтаксис: OK")
        else:
            print(f"  ❌ Синтаксис: {syntax_msg}")
            all_good = False
            continue
        
        # Проверка дублирующихся обработчиков
        dup_handlers = check_duplicate_handlers(filename)
        if dup_handlers:
            print(f"  ⚠️  Дублирующиеся обработчики:")
            for handler, count in dup_handlers.items():
                print(f"     - {handler}: {count} раз(а)")
            all_good = False
        else:
            print(f"  ✅ Обработчики: OK")
        
        # Проверка дублирующихся функций
        dup_funcs = check_functions(filename)
        if dup_funcs:
            print(f"  ⚠️  Дублирующиеся функции:")
            for func, count in dup_funcs.items():
                print(f"     - {func}: {count} раз(а)")
            all_good = False
        else:
            print(f"  ✅ Функции: OK")
    
    print("\n" + "=" * 60)
    if all_good:
        print("🎉 Все проверки пройдены успешно!")
        print("✅ Код готов к запуску")
    else:
        print("⚠️  Найдены проблемы. Исправьте их перед запуском.")
    
    return all_good

if __name__ == "__main__":
    main()
