#!/usr/bin/env python3
"""
Финальное тестирование Exteragram Plugin Library Bot

Проверяет все новые функции и улучшения:
1. Улучшенную систему изменения заявок
2. Систему отзывов
3. Подписку на авторов
4. Уведомления
5. Баннеры
6. Результаты поиска
"""

import os
import sys
import traceback
from pathlib import Path

def print_header(title):
    print(f"\n{'='*70}")
    print(f" {title}")
    print(f"{'='*70}")

def print_result(success, message):
    status = "✅ УСПЕШНО" if success else "❌ ОШИБКА"
    print(f"{status}: {message}")
    return success

def test_database_new_functions():
    """Проверка новых функций базы данных"""
    print_header("Проверка новых функций базы данных")
    
    try:
        import database
        
        # Создание экземпляра БД
        db = database.Database("data/test_final.db")
        
        methods_to_check = [
            'add_review',
            'get_plugin_reviews',
            'subscribe_to_author',
            'unsubscribe_from_author',
            'is_subscribed_to_author',
            'get_author_subscribers',
            'get_user_author_subscriptions'
        ]
        
        all_methods_exist = True
        for method in methods_to_check:
            exists = hasattr(db, method)
            all_methods_exist = all_methods_exist and exists
            if not exists:
                print_result(False, f"Метод {method} не найден")
        
        if all_methods_exist:
            print_result(True, f"Все {len(methods_to_check)} новых методов БД существуют")
        
        # Проверка таблиц
        with db._get_connection() as conn:
            cursor = conn.cursor()
            
            # Проверка таблицы reviews
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='reviews'")
            reviews_table = cursor.fetchone() is not None
            print_result(reviews_table, "Таблица reviews существует")
            
            # Проверка таблицы author_subscriptions
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='author_subscriptions'")
            author_subs_table = cursor.fetchone() is not None
            print_result(author_subs_table, "Таблица author_subscriptions существует")
        
        # Удаление тестовой БД
        try:
            os.remove("data/test_final.db")
        except:
            pass
        
        return all_methods_exist and reviews_table and author_subs_table
        
    except Exception as e:
        print_result(False, f"Ошибка проверки новых функций БД: {e}")
        traceback.print_exc()
        return False

def test_admin_functions_improvements():
    """Проверка улучшений в admin_functions"""
    print_header("Проверка улучшений в admin_functions")
    
    try:
        import admin_functions
        
        # Проверка новых функций
        new_functions = [
            'create_category_selection_menu',
            'create_status_selection_menu',
            'save_changes'
        ]
        
        all_functions_exist = True
        for func in new_functions:
            exists = hasattr(admin_functions, func)
            all_functions_exist = all_functions_exist and exists
            if not exists:
                print_result(False, f"Функция {func} не найдена")
        
        if all_functions_exist:
            print_result(True, f"Все {len(new_functions)} новых функций админа существуют")
        
        # Проверка notify_author_subscribers_about_new_plugin
        if hasattr(admin_functions, 'notify_author_subscribers_about_new_plugin'):
            print_result(True, "Функция notify_author_subscribers_about_new_plugin существует")
        else:
            print_result(False, "Функция notify_author_subscribers_about_new_plugin не найдена")
            all_functions_exist = False
        
        return all_functions_exist
        
    except Exception as e:
        print_result(False, f"Ошибка проверки admin_functions: {e}")
        traceback.print_exc()
        return False

def test_user_functions_improvements():
    """Проверка улучшений в user_functions"""
    print_header("Проверка улучшений в user_functions")
    
    try:
        import user_functions
        
        # Проверка новых состояний
        if hasattr(user_functions, 'ReviewStates'):
            print_result(True, "Состояние ReviewStates существует")
        else:
            print_result(False, "Состояние ReviewStates не найдено")
            return False
        
        # Проверка новых обработчиков
        handlers_to_check = [
            'subscribe_to_author',
            'unsubscribe_from_author',
            'show_author_profile',
            'process_review_text'
        ]
        
        all_handlers_exist = True
        for handler in handlers_to_check:
            exists = hasattr(user_functions, handler)
            all_handlers_exist = all_handlers_exist and exists
            if not exists:
                print_result(False, f"Обработчик {handler} не найден")
        
        if all_handlers_exist:
            print_result(True, f"Все {len(handlers_to_check)} новых обработчиков существуют")
        
        return all_handlers_exist
        
    except Exception as e:
        print_result(False, f"Ошибка проверки user_functions: {e}")
        traceback.print_exc()
        return False

def test_buttons_improvements():
    """Проверка улучшений в buttons"""
    print_header("Проверка улучшений в buttons")
    
    try:
        import buttons
        
        # Проверка новых кнопок
        if hasattr(buttons, 'AUTHOR'):
            print_result(True, "Категория AUTHOR существует")
            print(f"   Кнопки AUTHOR: {len(buttons.AUTHOR)}")
        else:
            print_result(False, "Категория AUTHOR не найдена")
            return False
        
        # Проверка общего количества кнопок
        total_buttons = len(buttons.ALL_BUTTONS)
        print_result(True, f"Всего кнопок: {total_buttons}")
        
        # Проверка дубликатов
        values = list(buttons.ALL_BUTTONS.values())
        duplicates = len(values) != len(set(values))
        if not duplicates:
            print_result(True, "Дубликатов кнопок нет")
        else:
            print_result(False, "Есть дубликаты кнопок")
            return False
        
        return True
        
    except Exception as e:
        print_result(False, f"Ошибка проверки buttons: {e}")
        traceback.print_exc()
        return False

def test_config_improvements():
    """Проверка улучшений в config"""
    print_header("Проверка улучшений в config")
    
    try:
        import config
        
        # Проверка существования всех необходимых переменных
        required_vars = [
            'BOT_TOKEN',
            'ADMIN_IDS',
            'ADMIN_GROUP_ID',
            'TOPIC_SUBMISSIONS',
            'TOPIC_STORAGE',
            'TOPIC_SECURITY',
            'MESSAGES',
            'CATEGORIES',
            'DEV_STATUSES'
        ]
        
        all_vars_exist = True
        for var in required_vars:
            exists = hasattr(config, var)
            all_vars_exist = all_vars_exist and exists
            if not exists:
                print_result(False, f"Переменная {var} не найдена")
        
        if all_vars_exist:
            print_result(True, f"Все {len(required_vars)} необходимых переменных существуют")
        
        # Проверка MESSAGES
        if hasattr(config, 'MESSAGES'):
            messages_count = len(config.MESSAGES)
            print_result(True, f"MESSAGES: {messages_count} сообщений")
        
        return all_vars_exist
        
    except Exception as e:
        print_result(False, f"Ошибка проверки config: {e}")
        traceback.print_exc()
        return False

def test_bot_structure():
    """Проверка структуры бота"""
    print_header("Проверка структуры бота")
    
    required_files = [
        "bot.py",
        "config.py", 
        "buttons.py",
        "database.py",
        "user_functions.py",
        "admin_functions.py",
        "requirements.txt",
        "README.md",
        ".env.example",
        "__init__.py",
        "run.sh",
        "test_bot.py",
        "test_final.py"
    ]
    
    all_files_exist = True
    for file in required_files:
        exists = os.path.exists(file)
        all_files_exist = all_files_exist and exists
        print_result(exists, f"Файл {file} существует")
    
    return all_files_exist

def main():
    """Главная функция финального тестирования"""
    print("🚀 Финальное тестирование Exteragram Plugin Library Bot")
    print("Все улучшения и новые функции")
    print("="*70)
    
    tests = [
        ("Структура проекта", test_bot_structure),
        ("Новые функции БД", test_database_new_functions),
        ("Улучшения admin_functions", test_admin_functions_improvements),
        ("Улучшения user_functions", test_user_functions_improvements),
        ("Улучшения buttons", test_buttons_improvements),
        ("Улучшения config", test_config_improvements),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print_result(False, f"Критическая ошибка в {name}: {e}")
            results.append((name, False))
    
    # Итоговая статистика
    print_header("ИТОГИ ФИНАЛЬНОГО ТЕСТИРОВАНИЯ")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "✅ ПРОЙДЕН" if result else "❌ НЕ ПРОЙДЕН"
        print(f"{status}: {name}")
    
    print(f"\n📊 Всего тестов: {total}")
    print(f"✅ Пройдено: {passed}")
    print(f"❌ Не пройдено: {total - passed}")
    
    if passed == total:
        print("\n🎉 Все тесты пройдены! Бот полностью готов к работе с новыми функциями!")
        print("\n📋 Что было улучшено:")
        print("   ✅ Система изменения заявок (инлайн-кнопки)")
        print("   ✅ Система отзывов с текстом")
        print("   ✅ Подписка на авторов")
        print("   ✅ Уведомления о новых плагинах")
        print("   ✅ Баннеры в профилях авторов")
        print("   ✅ Улучшенные результаты поиска")
        print("   ✅ Одно сообщение в подписках и популярном")
        return 0
    else:
        print(f"\n⚠️  Найдено {total - passed} проблем. Исправьте их перед запуском.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
