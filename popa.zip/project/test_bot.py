#!/usr/bin/env python3
"""
Тестовый скрипт для проверки функциональности Exteragram Plugin Library Bot

Проверяет:
1. Структуру проекта
2. Импорты модулей
3. Базу данных
4. Конфигурацию
5. Кнопки
"""

import os
import sys
import traceback
from pathlib import Path

def print_header(title):
    print(f"\n{'='*60}")
    print(f" {title}")
    print(f"{'='*60}")

def print_result(success, message):
    status = "✅ УСПЕШНО" if success else "❌ ОШИБКА"
    print(f"{status}: {message}")
    return success

def test_project_structure():
    """Проверка структуры проекта"""
    print_header("Проверка структуры проекта")
    
    required_files = [
        "bot.py",
        "config.py",
        "buttons.py",
        "database.py",
        "user_functions.py",
        "admin_functions.py",
        "requirements.txt",
        "README.md",
        ".env.example",
        "__init__.py"
    ]
    
    all_exist = True
    for file in required_files:
        exists = os.path.exists(file)
        all_exist = all_exist and exists
        print_result(exists, f"Файл {file} существует")
    
    # Проверка директории data
    data_dir = Path("data")
    data_exists = data_dir.exists() or not data_dir.exists()
    if not data_dir.exists():
        try:
            data_dir.mkdir(exist_ok=True)
            print_result(True, "Создана директория data/")
        except:
            print_result(False, "Не удалось создать директорию data/")
            all_exist = False
    
    return all_exist

def test_imports():
    """Проверка импортов модулей"""
    print_header("Проверка импортов модулей")
    
    modules = [
        ("aiogram", "aiogram"),
        ("python-dotenv", "dotenv"),
        ("aiofiles", "aiofiles"),
    ]
    
    all_imports_ok = True
    
    for name, module in modules:
        try:
            __import__(module)
            print_result(True, f"Модуль {name} импортируется")
        except ImportError as e:
            print_result(False, f"Модуль {name} не найден: {e}")
            all_imports_ok = False
    
    # Проверка наших модулей
    our_modules = [
        "config",
        "buttons",
        "database",
        "user_functions",
        "admin_functions"
    ]
    
    for module in our_modules:
        try:
            __import__(module)
            print_result(True, f"Модуль {module}.py импортируется")
        except Exception as e:
            print_result(False, f"Ошибка импорта {module}.py: {e}")
            all_imports_ok = False
    
    return all_imports_ok

def test_config():
    """Проверка конфигурации"""
    print_header("Проверка конфигурации")
    
    try:
        import config
        
        # Проверка токена
        token_ok = config.BOT_TOKEN and config.BOT_TOKEN != "YOUR_BOT_TOKEN_HERE"
        print_result(token_ok, f"BOT_TOKEN установлен: {'***' if token_ok else 'не установлен'}")
        
        # Проверка админов
        admin_ok = isinstance(config.ADMIN_IDS, list)
        print_result(admin_ok, f"ADMIN_IDS: {len(config.ADMIN_IDS)} администраторов")
        
        # Проверка сообщений
        messages_ok = isinstance(config.MESSAGES, dict) and len(config.MESSAGES) > 0
        print_result(messages_ok, f"MESSAGES: {len(config.MESSAGES)} сообщений")
        
        # Проверка категорий
        categories_ok = isinstance(config.CATEGORIES, dict) and len(config.CATEGORIES) == 5
        print_result(categories_ok, f"CATEGORIES: {len(config.CATEGORIES)} категорий")
        
        return token_ok and admin_ok and messages_ok and categories_ok
        
    except Exception as e:
        print_result(False, f"Ошибка проверки config.py: {e}")
        return False

def test_buttons():
    """Проверка кнопок"""
    print_header("Проверка кнопок")
    
    try:
        import buttons
        
        # Проверка основных кнопок
        main_menu_ok = hasattr(buttons, 'MAIN_MENU') and len(buttons.MAIN_MENU) == 6
        print_result(main_menu_ok, f"MAIN_MENU: {len(buttons.MAIN_MENU)} кнопок")
        
        # Проверка общих кнопок
        common_ok = hasattr(buttons, 'COMMON') and len(buttons.COMMON) > 5
        print_result(common_ok, f"COMMON: {len(buttons.COMMON)} кнопок")
        
        # Проверка функций
        get_text_ok = hasattr(buttons, 'get_button_text')
        print_result(get_text_ok, "Функция get_button_text существует")
        
        get_code_ok = hasattr(buttons, 'get_button_code')
        print_result(get_code_ok, "Функция get_button_code существует")
        
        # Проверка дубликатов
        all_buttons = buttons.ALL_BUTTONS
        values = list(all_buttons.values())
        duplicates = len(values) != len(set(values))
        print_result(not duplicates, f"Нет дубликатов в кнопках: {len(all_buttons)} уникальных")
        
        return main_menu_ok and common_ok and get_text_ok and get_code_ok and not duplicates
        
    except Exception as e:
        print_result(False, f"Ошибка проверки buttons.py: {e}")
        return False

def test_database():
    """Проверка базы данных"""
    print_header("Проверка базы данных")
    
    try:
        import database
        
        # Создание экземпляра БД
        db = database.Database("data/test.db")
        print_result(True, "База данных инициализирована")
        
        # Проверка методов
        methods_to_check = [
            'create_user',
            'get_user',
            'update_user',
            'get_user_stats',
            'create_plugin',
            'get_plugin',
            'get_plugin_with_author',
            'update_plugin',
            'delete_plugin',
            'increment_views',
            'increment_downloads',
            'get_user_plugins',
            'get_popular_plugins',
            'get_plugins_by_category',
            'search_plugins',
            'add_rating',
            'get_user_rating',
            'subscribe',
            'unsubscribe',
            'is_subscribed',
            'get_user_subscriptions',
            'get_plugin_subscribers',
            'create_submission',
            'get_submission',
            'update_submission',
            'get_pending_submissions',
            'create_update_request',
            'get_update_request',
            'get_pending_updates',
            'update_update_request'
        ]
        
        all_methods_exist = True
        for method in methods_to_check:
            exists = hasattr(db, method)
            all_methods_exist = all_methods_exist and exists
            if not exists:
                print_result(False, f"Метод {method} не найден")
        
        if all_methods_exist:
            print_result(True, f"Все {len(methods_to_check)} методов БД существуют")
        
        # Удаление тестовой БД
        try:
            os.remove("data/test.db")
        except:
            pass
        
        return all_methods_exist
        
    except Exception as e:
        print_result(False, f"Ошибка проверки database.py: {e}")
        traceback.print_exc()
        return False

def test_user_functions():
    """Проверка функций пользователя"""
    print_header("Проверка функций пользователя")
    
    try:
        import user_functions
        
        # Проверка состояний
        states_to_check = [
            'RegistrationStates',
            'UploadStates',
            'SearchStates',
            'ProfileEditStates',
            'BroadcastStates'
        ]
        
        all_states_exist = True
        for state in states_to_check:
            exists = hasattr(user_functions, state)
            all_states_exist = all_states_exist and exists
            if not exists:
                print_result(False, f"Состояние {state} не найдено")
        
        if all_states_exist:
            print_result(True, f"Все {len(states_to_check)} состояний существуют")
        
        # Проверка функций создания меню
        menu_funcs = ['create_main_menu', 'create_cancel_menu', 'create_categories_menu', 
                     'create_statuses_menu', 'create_plugin_menu', 'create_manage_menu',
                     'create_rating_menu', 'create_file_replace_menu']
        
        all_funcs_exist = True
        for func in menu_funcs:
            exists = hasattr(user_functions, func)
            all_funcs_exist = all_funcs_exist and exists
            if not exists:
                print_result(False, f"Функция {func} не найдена")
        
        if all_funcs_exist:
            print_result(True, f"Все {len(menu_funcs)} функций меню существуют")
        
        # Проверка роутера
        router_ok = hasattr(user_functions, 'router')
        print_result(router_ok, "Роутер user_functions существует")
        
        return all_states_exist and all_funcs_exist and router_ok
        
    except Exception as e:
        print_result(False, f"Ошибка проверки user_functions.py: {e}")
        traceback.print_exc()
        return False

def test_admin_functions():
    """Проверка функций администратора"""
    print_header("Проверка функций администратора")
    
    try:
        import admin_functions
        
        # Проверка состояний
        states_to_check = ['EditSubmissionStates', 'BroadcastStates']
        
        all_states_exist = True
        for state in states_to_check:
            exists = hasattr(admin_functions, state)
            all_states_exist = all_states_exist and exists
            if not exists:
                print_result(False, f"Состояние {state} не найдено")
        
        if all_states_exist:
            print_result(True, f"Все {len(states_to_check)} состояний админа существуют")
        
        # Проверка функций
        funcs_to_check = [
            'is_admin',
            'create_admin_menu',
            'create_submission_review_menu',
            'create_update_review_menu',
            'create_edit_field_menu',
            'send_to_topic',
            'format_submission_message',
            'format_update_message',
            'notify_admins_about_submission',
            'notify_admins_about_update'
        ]
        
        all_funcs_exist = True
        for func in funcs_to_check:
            exists = hasattr(admin_functions, func)
            all_funcs_exist = all_funcs_exist and exists
            if not exists:
                print_result(False, f"Функция {func} не найдена")
        
        if all_funcs_exist:
            print_result(True, f"Все {len(funcs_to_check)} функций админа существуют")
        
        # Проверка роутера
        router_ok = hasattr(admin_functions, 'router')
        print_result(router_ok, "Роутер admin_functions существует")
        
        return all_states_exist and all_funcs_exist and router_ok
        
    except Exception as e:
        print_result(False, f"Ошибка проверки admin_functions.py: {e}")
        traceback.print_exc()
        return False

def test_bot_script():
    """Проверка главного скрипта"""
    print_header("Проверка главного скрипта bot.py")
    
    try:
        # Проверка синтаксиса
        import py_compile
        py_compile.compile('bot.py', doraise=True)
        print_result(True, "Синтаксис bot.py корректен")
        
        # Проверка импортов
        import bot
        print_result(True, "bot.py импортируется без ошибок")
        
        return True
        
    except py_compile.PyCompileError as e:
        print_result(False, f"Синтаксическая ошибка в bot.py: {e}")
        return False
    except Exception as e:
        print_result(False, f"Ошибка проверки bot.py: {e}")
        return False

def main():
    """Главная функция тестирования"""
    print("🚀 Запуск тестирования Exteragram Plugin Library Bot")
    print("="*60)
    
    tests = [
        ("Структура проекта", test_project_structure),
        ("Импорты модулей", test_imports),
        ("Конфигурация", test_config),
        ("Кнопки", test_buttons),
        ("База данных", test_database),
        ("Функции пользователя", test_user_functions),
        ("Функции администратора", test_admin_functions),
        ("Главный скрипт", test_bot_script),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print_result(False, f"Критическая ошибка в {name}: {e}")
            results.append((name, False))
    
    # Итоговая статистика
    print_header("ИТОГИ ТЕСТИРОВАНИЯ")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "✅ ПРОЙДЕН" if result else "❌ НЕ ПРОЙДЕН"
        print(f"{status}: {name}")
    
    print(f"\n📊 Всего тестов: {total}")
    print(f"✅ Пройдено: {passed}")
    print(f"❌ Не пройдено: {total - passed}")
    
    if passed == total:
        print("\n🎉 Все тесты пройдены! Бот готов к запуску.")
        return 0
    else:
        print(f"\n⚠️  Найдено {total - passed} проблем. Исправьте их перед запуском.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
