#!/usr/bin/env python3
"""
User functions for Exteragram Plugin Library Bot
Основные функции для пользователей
"""

import os
from typing import Dict, List, Optional, Any
from aiogram import types, F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from datetime import datetime
import asyncio

from buttons import (
    MAIN_MENU, COMMON, PLUGIN_PAGE, RATING, CATEGORIES, 
    DEV_STATUSES, UPLOAD, PROFILE, ADMIN, PAGINATION, AUTHOR,
    get_button_text, get_button_code
)
from database import Database, Plugin
from config import (
    DATABASE_PATH,
    PLUGIN_STORAGE_PATH,
    PHOTO_STORAGE_PATH,
    MESSAGES,
    CATEGORIES as CATEGORIES_CONFIG,
    DEV_STATUSES as DEV_STATUSES_CONFIG,
    ADMIN_IDS,
)

os.makedirs(PLUGIN_STORAGE_PATH, exist_ok=True)
os.makedirs(PHOTO_STORAGE_PATH, exist_ok=True)

db = Database(DATABASE_PATH)
router = Router()

async def _edit_or_send(callback_query: types.CallbackQuery, text: str, reply_markup=None):
    """Для inline-кнопок: пытаемся отредактировать текущее сообщение, иначе шлём новое."""
    msg = callback_query.message
    try:
        is_media = any(getattr(msg, attr, None) for attr in ("photo", "document", "video", "animation", "audio", "voice"))
        if is_media:
            await msg.edit_caption(caption=text, reply_markup=reply_markup)
        else:
            await msg.edit_text(text, reply_markup=reply_markup)
    except Exception:
        await msg.answer(text, reply_markup=reply_markup)


class RegistrationStates(StatesGroup):
    waiting_display_name = State()
    waiting_username = State()

class UploadStates(StatesGroup):
    waiting_file = State()
    waiting_name_and_photo = State()
    waiting_category = State()
    waiting_status = State()
    waiting_tags = State()

class SearchStates(StatesGroup):
    waiting_query = State()

class ProfileEditStates(StatesGroup):
    waiting_display_name = State()
    waiting_username = State()
    waiting_banner = State()

class BroadcastStates(StatesGroup):
    waiting_message = State()

class ReviewStates(StatesGroup):
    waiting_rating = State()
    waiting_text = State()


def create_main_menu() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text=MAIN_MENU["search"])
    builder.button(text=MAIN_MENU["upload"])
    builder.button(text=MAIN_MENU["popular"])
    builder.button(text=MAIN_MENU["categories"])
    builder.button(text=MAIN_MENU["subscriptions"])
    builder.button(text=MAIN_MENU["profile"])
    builder.adjust(3, 3)
    return builder.as_markup(resize_keyboard=True)


def create_cancel_menu() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text=COMMON["cancel"])
    return builder.as_markup(resize_keyboard=True)


def create_categories_menu(is_for_upload: bool = True) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    prefix = "upload_category_" if is_for_upload else "category_"
    for key, value in CATEGORIES_CONFIG.items():
        builder.button(text=value, callback_data=f"{prefix}{key}")
    if not is_for_upload:
        builder.button(text=COMMON["back"], callback_data="menu")
    builder.adjust(2)
    return builder.as_markup()


def create_statuses_menu() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, value in DEV_STATUSES_CONFIG.items():
        builder.button(text=value, callback_data=f"status_{key}")
    builder.adjust(2)
    return builder.as_markup()


def create_file_replace_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=UPLOAD["continue"], callback_data="continue_upload")],
        [InlineKeyboardButton(text=UPLOAD["replace_file"], callback_data="replace_file")]
    ])


def create_rating_menu(plugin_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for i in range(1, 6):
        builder.button(text="⭐" * i, callback_data=f"set_rating_{plugin_id}_{i}")
    builder.adjust(5)
    return builder.as_markup()


def create_plugin_page_menu(plugin_id: int, is_subscribed: bool = False, 
                           is_subscribed_to_author: bool = False, author_id: int = 0) -> InlineKeyboardMarkup:
    keyboard = []
    
    # Подписка на плагин
    sub_text = PLUGIN_PAGE["unsubscribe"] if is_subscribed else PLUGIN_PAGE["subscribe"]
    keyboard.append([InlineKeyboardButton(text=sub_text, callback_data=f"{'unsub' if is_subscribed else 'sub'}_{plugin_id}")])
    
    # Подписка на автора
    if author_id > 0:
        author_sub_text = AUTHOR["unsubscribe"] if is_subscribed_to_author else AUTHOR["subscribe"]
        keyboard.append([InlineKeyboardButton(text=author_sub_text, 
            callback_data=f"{'unsubscribe_author' if is_subscribed_to_author else 'subscribe_author'}_{author_id}")])
    
    keyboard.extend([
        [InlineKeyboardButton(text=PLUGIN_PAGE["download"], callback_data=f"download_{plugin_id}")],
        [InlineKeyboardButton(text=PLUGIN_PAGE["reviews"], callback_data=f"reviews_{plugin_id}_1")],
        [InlineKeyboardButton(text=PLUGIN_PAGE["rate"], callback_data=f"rate_{plugin_id}")],
        [InlineKeyboardButton(text=PLUGIN_PAGE["author"], callback_data=f"author_{plugin_id}")],
        [InlineKeyboardButton(text=COMMON["back"], callback_data="menu")]
    ])
    
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def create_profile_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=PROFILE["edit_profile"], callback_data="edit_profile")],
        [InlineKeyboardButton(text=PROFILE["my_plugins"], callback_data="my_plugins")],
        [InlineKeyboardButton(text=COMMON["back"], callback_data="menu")]
    ])


def create_edit_profile_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Изменить никнейм", callback_data="edit_display_name")],
        [InlineKeyboardButton(text="Изменить username", callback_data="edit_username")],
        [InlineKeyboardButton(text="Изменить баннер", callback_data="edit_banner")],
        [InlineKeyboardButton(text=COMMON["back"], callback_data="back_to_profile")]
    ])


def create_manage_menu(plugin_id: int, is_archived: bool) -> InlineKeyboardMarkup:
    keyboard = []
    if not is_archived:
        keyboard.append([InlineKeyboardButton(text=PLUGIN_PAGE["update"], callback_data=f"update_{plugin_id}")])
        keyboard.append([InlineKeyboardButton(text=PLUGIN_PAGE["archive"], callback_data=f"archive_{plugin_id}")])
    else:
        keyboard.append([InlineKeyboardButton(text=PLUGIN_PAGE["unarchive"], callback_data=f"unarchive_{plugin_id}")])
    keyboard.append([InlineKeyboardButton(text=COMMON["back"], callback_data="my_plugins")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def create_plugin_menu(plugin_id: int) -> InlineKeyboardMarkup:
    """Создание меню для плагина (для обратной совместимости)"""
    return create_manage_menu(plugin_id, False)


def create_pagination_menu(current_page: int, total_pages: int, base_callback: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if current_page > 1:
        builder.button(text=PAGINATION["prev"], callback_data=f"{base_callback}_{current_page - 1}")
    builder.button(text=f"{current_page}/{total_pages}", callback_data="noop")
    if current_page < total_pages:
        builder.button(text=PAGINATION["next"], callback_data=f"{base_callback}_{current_page + 1}")
    return builder.as_markup()


@router.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    await state.clear()
    
    user = db.get_user(message.from_user.id)
    if not user:
        await state.set_state(RegistrationStates.waiting_display_name)
        await message.answer(MESSAGES["registration_required"], reply_markup=create_cancel_menu())
    else:
        await message.answer(MESSAGES["start"], reply_markup=create_main_menu())


@router.message(RegistrationStates.waiting_display_name)
async def process_registration_display_name(message: types.Message, state: FSMContext):
    """Обработка ввода никнейма при регистрации"""
    if message.text == COMMON["cancel"]:
        await state.clear()
        await message.answer(MESSAGES["cancelled"], reply_markup=create_main_menu())
        return

    display_name = message.text.strip()
    if len(display_name) < 2 or len(display_name) > 50:
        await message.answer("⚠️ Никнейм должен быть от 2 до 50 символов.", reply_markup=create_cancel_menu())
        return

    await state.update_data(display_name=display_name)
    await state.set_state(RegistrationStates.waiting_username)
    await message.answer(MESSAGES["registration_username"], reply_markup=create_cancel_menu())


@router.message(RegistrationStates.waiting_username)
async def process_registration_username(message: types.Message, state: FSMContext):
    """Обработка ввода username при регистрации"""
    if message.text == COMMON["cancel"]:
        await state.clear()
        await message.answer(MESSAGES["cancelled"], reply_markup=create_main_menu())
        return

    username = message.text.strip().replace("@", "")
    if len(username) < 3 or len(username) > 32:
        await message.answer("⚠️ Username должен быть от 3 до 32 символов.", reply_markup=create_cancel_menu())
        return

    data = await state.get_data()
    display_name = data.get("display_name", "")

    # Создаем пользователя
    success = db.create_user(message.from_user.id, username, display_name)

    if success:
        await message.answer(MESSAGES["registration_complete"], reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Ошибка при регистрации. Попробуйте еще раз.", reply_markup=create_main_menu())

    await state.clear()
@router.message(lambda message: message.text == MAIN_MENU["search"])
async def menu_search(message: types.Message, state: FSMContext):
    await state.set_state(SearchStates.waiting_query)
    await message.answer(MESSAGES["search_prompt"], reply_markup=create_cancel_menu())


@router.message(SearchStates.waiting_query)
async def process_search(message: types.Message, state: FSMContext):
    if message.text == COMMON["cancel"]:
        await state.clear()
        await message.answer(MESSAGES["start"], reply_markup=create_main_menu())
        return
    
    query = message.text.strip()
    if len(query) < 2:
        await message.answer("⚠️ Запрос должен быть не менее 2 символов.")
        return
    
    results = db.search_plugins(query)
    await state.clear()
    
    if not results:
        await message.answer("😕 Ничего не найдено.", reply_markup=create_main_menu())
        return
    
    text = f"🔍 <b>Результаты поиска</b> по запросу: <i>{query}</i>\n\n"
    keyboard_buttons = []
    
    for plugin in results[:10]:
        author = db.get_user(plugin['author_id'])
        author_username = author.username if author else "unknown"
        stats = db.get_plugin_stats(plugin['plugin_id'])
        text += f"• <b>{plugin['name']}</b> (@{author_username})\n"
        text += f"  ⭐ {stats['rating']:.1f} | 📥 {stats['downloads']} | 👥 {stats['subscribers']}\n\n"
        
        keyboard_buttons.append([InlineKeyboardButton(
            text=f"{plugin['name']} (@{author_username})",
            callback_data=f"plugin_{plugin['plugin_id']}"
        )])
    
    keyboard_buttons.append([InlineKeyboardButton(text=COMMON["back"], callback_data="menu")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    await message.answer(text, reply_markup=keyboard)


@router.message(lambda message: message.text == MAIN_MENU["popular"])
async def menu_popular(message: types.Message):
    plugins = db.get_popular_plugins(limit=20)
    
    if not plugins:
        await message.answer("😕 Пока нет популярных плагинов.", reply_markup=create_main_menu())
        return
    
    text = f"🔥 <b>Популярные плагины</b> ({len(plugins)})\n\n"
    keyboard_buttons = []
    
    for plugin in plugins:
        author = db.get_user(plugin['author_id'])
        author_username = author.username if author else "unknown"
        stats = db.get_plugin_stats(plugin['plugin_id'])
        text += f"• <b>{plugin['name']}</b> by @{author_username}\n"
        text += f"  ⭐ {stats['rating']:.1f} | 📥 {stats['downloads']} | 👥 {stats['subscribers']}\n\n"
        
        keyboard_buttons.append([InlineKeyboardButton(
            text=plugin['name'],
            callback_data=f"plugin_{plugin['plugin_id']}"
        )])
    
    keyboard_buttons.append([InlineKeyboardButton(text=COMMON["back"], callback_data="menu")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    await message.answer(text, reply_markup=keyboard)


@router.message(lambda message: message.text == MAIN_MENU["categories"])
async def menu_categories(message: types.Message):
    keyboard = create_categories_menu(is_for_upload=False)
    await message.answer("📂 Выберите категорию:", reply_markup=keyboard)


@router.callback_query(F.data.startswith("category_"))
async def browse_category(callback_query: types.CallbackQuery):
    category = callback_query.data.replace("category_", "")
    category_name = CATEGORIES_CONFIG.get(category, category)
    
    plugins = db.get_plugins_by_category(category)
    if not plugins:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=COMMON["back"], callback_data="browse_categories")]
        ])
        await _edit_or_send(callback_query, f"📂 В категории '{category_name}' пока нет плагинов.", reply_markup=keyboard)
        await callback_query.answer()
        return
    
    text = f"📂 <b>{category_name}</b>\n\n"
    keyboard_buttons = []
    
    for plugin in plugins:
        author = db.get_user(plugin['author_id'])
        author_username = author.username if author else "unknown"
        stats = db.get_plugin_stats(plugin['plugin_id'])
        text += f"• <b>{plugin['name']}</b> by @{author_username}\n"
        text += f"  ⭐ {stats['rating']:.1f} | 📥 {stats['downloads']} | 👥 {stats['subscribers']}\n\n"
        
        keyboard_buttons.append([InlineKeyboardButton(
            text=plugin['name'],
            callback_data=f"plugin_{plugin['plugin_id']}"
        )])
    
    keyboard_buttons.append([InlineKeyboardButton(text=COMMON["back"], callback_data="browse_categories")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    await _edit_or_send(callback_query, text, reply_markup=keyboard)
    await callback_query.answer()


@router.message(lambda message: message.text == MAIN_MENU["subscriptions"])
async def menu_subscriptions(message: types.Message):
    user_id = message.from_user.id
    subscriptions = db.get_user_subscriptions(user_id)
    author_subscriptions = db.get_user_author_subscriptions(user_id)
    
    if not subscriptions and not author_subscriptions:
        await message.answer("📭 У вас пока нет подписок.", reply_markup=create_main_menu())
        return
    
    text = f"📫 <b>Ваши подписки</b>\n\n"
    keyboard_buttons = []
    
    if subscriptions:
        text += f"📦 Плагины: {len(subscriptions)}\n"
        for sub in subscriptions[:10]:
            plugin = db.get_plugin(sub["plugin_id"])
            if plugin:
                author = db.get_user(plugin['author_id'])
                author_username = author.username if author else "unknown"
                stats = db.get_plugin_stats(plugin['plugin_id'])
                text += f"• <b>{plugin['name']}</b> by @{author_username}\n"
                text += f"  ⭐ {stats['rating']:.1f} | 📥 {stats['downloads']}\n\n"
                
                keyboard_buttons.append([InlineKeyboardButton(
                    text=plugin['name'],
                    callback_data=f"plugin_{plugin['plugin_id']}"
                )])
    
    if author_subscriptions:
        text += f"\n👤 Авторы: {len(author_subscriptions)}\n"
        for sub in author_subscriptions[:5]:
            author = db.get_user(sub["author_id"])
            if author:
                text += f"• @{author.username or author.display_name}\n"
                
                keyboard_buttons.append([InlineKeyboardButton(
                    text=f"Автор: @{author.username or author.display_name}",
                    callback_data=f"author_profile_{author.user_id}"
                )])
    
    keyboard_buttons.append([InlineKeyboardButton(text=COMMON["back"], callback_data="menu")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    await message.answer(text, reply_markup=keyboard)


@router.message(lambda message: message.text == MAIN_MENU["upload"])
async def menu_upload(message: types.Message, state: FSMContext):
    await state.set_state(UploadStates.waiting_file)
    await message.answer(MESSAGES["upload_step1"], reply_markup=create_cancel_menu())


@router.message(lambda message: message.text == MAIN_MENU["profile"])
async def menu_profile(message: types.Message):
    user = db.get_user(message.from_user.id)
    if not user:
        await message.answer("❌ Профиль не найден.", reply_markup=create_main_menu())
        return
    
    stats = db.get_user_stats(message.from_user.id)
    plugins_count = stats.get("plugins_count", 0)
    downloads_count = stats.get("total_downloads", 0)
    subscribers_count = stats.get("subscribers_count", 0)
    
    text = (
        f"👤 <b>Ваш профиль</b>\n\n"
        f"<b>Никнейм:</b> {user.display_name}\n"
        f"<b>Username:</b> @{user.username or 'не установлен'}\n"
        f"<b>Плагинов:</b> {plugins_count}\n"
        f"<b>Загрузок:</b> {downloads_count}\n"
        f"<b>Подписчиков:</b> {subscribers_count}\n"
    )
    
    keyboard = create_profile_menu()
    
    if user.banner_photo_id:
        await message.answer_photo(
            photo=user.banner_photo_id,
            caption=text,
            reply_markup=keyboard
        )
    else:
        await message.answer(text, reply_markup=keyboard)


@router.callback_query(F.data == "back_to_profile")
async def back_to_profile(callback_query: types.CallbackQuery):
    await callback_query.answer()
    user = db.get_user(callback_query.from_user.id)
    if not user:
        await _edit_or_send(callback_query, "❌ Профиль не найден.")
        return
    
    stats = db.get_user_stats(callback_query.from_user.id)
    plugins_count = stats.get("plugins_count", 0)
    downloads_count = stats.get("total_downloads", 0)
    subscribers_count = stats.get("subscribers_count", 0)
    
    text = (
        f"👤 <b>Ваш профиль</b>\n\n"
        f"<b>Никнейм:</b> {user.display_name}\n"
        f"<b>Username:</b> @{user.username or 'не установлен'}\n"
        f"<b>Плагинов:</b> {plugins_count}\n"
        f"<b>Загрузок:</b> {downloads_count}\n"
        f"<b>Подписчиков:</b> {subscribers_count}\n"
    )
    
    keyboard = create_profile_menu()
    
    if user.banner_photo_id:
        try:
            await callback_query.message.delete()
            await callback_query.bot.send_photo(
                chat_id=callback_query.from_user.id,
                photo=user.banner_photo_id,
                caption=text,
                reply_markup=keyboard
            )
        except:
            await _edit_or_send(callback_query, text, reply_markup=keyboard)
    else:
        await _edit_or_send(callback_query, text, reply_markup=keyboard)


@router.callback_query(F.data == "edit_profile")
async def edit_profile_menu(callback_query: types.CallbackQuery):
    await callback_query.answer()
    keyboard = create_edit_profile_menu()
    await _edit_or_send(callback_query, "✏️ Что вы хотите изменить?", reply_markup=keyboard)


@router.callback_query(F.data == "edit_username")
async def start_edit_username(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer()
    await state.set_state(ProfileEditStates.waiting_display_name)
    await _edit_or_send(callback_query, 
        "📝 Введите новый username (без @):",
        reply_markup=create_cancel_menu()
    )


@router.callback_query(F.data == "edit_display_name")
async def start_edit_display_name(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer()
    await state.set_state(ProfileEditStates.waiting_display_name)
    await _edit_or_send(callback_query, 
        "📛 Введите новый никнейм:",
        reply_markup=create_cancel_menu()
    )


@router.callback_query(F.data == "edit_banner")
async def start_edit_banner(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer()
    await state.set_state(ProfileEditStates.waiting_banner)
    await _edit_or_send(callback_query, 
        "🖼 Отправьте изображение для баннера профиля:",
        reply_markup=create_cancel_menu()
    )


@router.message(ProfileEditStates.waiting_display_name)
async def process_edit_username(message: types.Message, state: FSMContext):
    if message.text == COMMON["cancel"]:
        await state.clear()
        await message.answer("❌ Отменено.", reply_markup=create_main_menu())
        return
    
    username = message.text.strip().replace("@", "")
    if len(username) < 3 or len(username) > 32:
        await message.answer("⚠️ Username должен быть от 3 до 32 символов.")
        return
    
    success = db.update_user(message.from_user.id, username=username)
    if success:
        await message.answer("✅ Username обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Ошибка при обновлении.")
    
    await state.clear()



@router.message(ProfileEditStates.waiting_banner)
async def process_edit_banner(message: types.Message, state: FSMContext):
    if message.text == COMMON["cancel"]:
        await state.clear()
        await message.answer("❌ Отменено.", reply_markup=create_main_menu())
        return
    
    if not message.photo:
        await message.answer("⚠️ Пожалуйста, отправьте изображение.")
        return
    
    photo_id = message.photo[-1].file_id
    success = db.update_user(message.from_user.id, banner_photo_id=photo_id)
    
    if success:
        await message.answer("✅ Баннер обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Ошибка при обновлении.")
    
    await state.clear()


@router.callback_query(F.data == "my_plugins")
async def my_plugins(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    plugins = db.get_user_plugins(user_id)
    
    if not plugins:
        await _edit_or_send(callback_query, "📦 У вас пока нет плагинов.")
        return
    
    active_plugins = [p for p in plugins if not p["is_archived"]]
    archived_plugins = [p for p in plugins if p["is_archived"]]
    
    text = f"📦 <b>Ваши плагины</b>\n\n"
    if active_plugins:
        text += f"✅ Активные: {len(active_plugins)}\n"
    if archived_plugins:
        text += f"📁 Архив: {len(archived_plugins)}\n"
    
    keyboard_buttons = []
    for plugin in active_plugins:
        keyboard_buttons.append([InlineKeyboardButton(
            text=f"✅ {plugin['name']}",
            callback_data=f"manage_{plugin['plugin_id']}"
        )])
    
    for plugin in archived_plugins:
        keyboard_buttons.append([InlineKeyboardButton(
            text=f"📁 {plugin['name']}",
            callback_data=f"manage_{plugin['plugin_id']}"
        )])
    
    keyboard_buttons.append([InlineKeyboardButton(text=COMMON["back"], callback_data="back_to_profile")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    await _edit_or_send(callback_query, text, reply_markup=keyboard)


@router.callback_query(F.data.startswith("plugin_"))
async def show_plugin_page(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("plugin_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin or plugin['is_archived']:
        await callback_query.answer("❌ Плагин не найден.", show_alert=True)
        return
    
    user_id = callback_query.from_user.id
    is_subscribed = db.is_subscribed(user_id, plugin_id)
    is_subscribed_to_author = db.is_subscribed_to_author(user_id, plugin['author_id'])
    
    author = db.get_user(plugin['author_id'])
    author_username = author.username if author else "unknown"
    
    stats = db.get_plugin_stats(plugin_id)
    rating = stats.get("rating", 0)
    downloads = stats.get("downloads", 0)
    subscribers = stats.get("subscribers", 0)
    reviews_count = stats.get("reviews_count", 0)
    
    text = (
        f"📦 <b>{plugin['name']}</b>\n\n"
        f"<b>Автор:</b> @{author_username}\n"
        f"<b>Категория:</b> {CATEGORIES_CONFIG.get(plugin['category'], plugin['category'])}\n"
        f"<b>Статус:</b> {DEV_STATUSES_CONFIG.get(plugin['status'], plugin['status'])}\n"
        f"<b>Описание:</b> {plugin['description']}\n\n"
        f"⭐ {rating:.1f} | 📥 {downloads} | 👥 {subscribers} | 💬 {reviews_count}"
    )
    
    keyboard = create_plugin_page_menu(
        plugin_id, 
        is_subscribed, 
        is_subscribed_to_author, 
        plugin['author_id']
    )
    
    if plugin['photo_id']:
        try:
            await callback_query.message.delete()
            await callback_query.bot.send_photo(
                chat_id=callback_query.from_user.id,
                photo=plugin['photo_id'],
                caption=text,
                reply_markup=keyboard
            )
        except:
            await _edit_or_send(callback_query, text, reply_markup=keyboard)
    else:
        await _edit_or_send(callback_query, text, reply_markup=keyboard)
    
    await callback_query.answer()


@router.callback_query(F.data.startswith("sub_"))
async def subscribe_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("sub_", ""))
    user_id = callback_query.from_user.id
    
    success = db.subscribe_to_plugin(user_id, plugin_id)
    if success:
        await callback_query.answer("✅ Подписка оформлена!")
        
        # Обновляем клавиатуру
        plugin = db.get_plugin(plugin_id)
        if plugin:
            is_subscribed_to_author = db.is_subscribed_to_author(user_id, plugin['author_id'])
            keyboard = create_plugin_page_menu(
                plugin_id, 
                True, 
                is_subscribed_to_author, 
                plugin['author_id']
            )
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
    else:
        await callback_query.answer("⚠️ Ошибка при подписке.", show_alert=True)


@router.callback_query(F.data.startswith("unsub_"))
async def unsubscribe_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("unsub_", ""))
    user_id = callback_query.from_user.id
    
    success = db.unsubscribe_from_plugin(user_id, plugin_id)
    if success:
        await callback_query.answer("❌ Подписка отменена.")
        
        # Обновляем клавиатуру
        plugin = db.get_plugin(plugin_id)
        if plugin:
            is_subscribed_to_author = db.is_subscribed_to_author(user_id, plugin['author_id'])
            keyboard = create_plugin_page_menu(
                plugin_id, 
                False, 
                is_subscribed_to_author, 
                plugin['author_id']
            )
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
    else:
        await callback_query.answer("⚠️ Ошибка при отписке.", show_alert=True)


@router.callback_query(F.data.startswith("subscribe_author_"))
async def subscribe_to_author(callback_query: types.CallbackQuery):
    author_id = int(callback_query.data.replace("subscribe_author_", ""))
    user_id = callback_query.from_user.id
    
    if author_id == user_id:
        await callback_query.answer("⚠️ Нельзя подписаться на себя!", show_alert=True)
        return
    
    success = db.subscribe_to_author(user_id, author_id)
    if success:
        await callback_query.answer("✅ Подписка на автора оформлена!")
        
        # Обновляем клавиатуру
        try:
            await callback_query.message.edit_reply_markup(
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text=AUTHOR["unsubscribe"], callback_data=f"unsubscribe_author_{author_id}")],
                    [InlineKeyboardButton(text=COMMON["back"], callback_data=f"back_to_plugin_0")]
                ])
            )
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при подписке.", show_alert=True)


@router.callback_query(F.data.startswith("unsubscribe_author_"))
async def unsubscribe_from_author(callback_query: types.CallbackQuery):
    author_id = int(callback_query.data.replace("unsubscribe_author_", ""))
    user_id = callback_query.from_user.id
    
    success = db.unsubscribe_from_author(user_id, author_id)
    if success:
        await callback_query.answer("❌ Подписка на автора отменена.")
        
        # Обновляем клавиатуру
        try:
            await callback_query.message.edit_reply_markup(
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text=AUTHOR["subscribe"], callback_data=f"subscribe_author_{author_id}")],
                    [InlineKeyboardButton(text=COMMON["back"], callback_data=f"back_to_plugin_0")]
                ])
            )
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при отписке.", show_alert=True)


@router.callback_query(F.data.startswith("author_"))
async def show_author_profile(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("author_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin:
        await callback_query.answer("❌ Плагин не найден.", show_alert=True)
        return
    
    author = db.get_user(plugin['author_id'])
    if not author:
        await callback_query.answer("❌ Автор не найден.", show_alert=True)
        return
    
    stats = db.get_user_stats(author.user_id)
    plugins_count = stats.get("plugins_count", 0)
    downloads_count = stats.get("total_downloads", 0)
    subscribers_count = stats.get("subscribers_count", 0)
    
    is_subscribed_to_author = db.is_subscribed_to_author(callback_query.from_user.id, author.user_id)
    
    text = (
        f"👤 <b>Профиль автора</b>\n\n"
        f"<b>Никнейм:</b> {author.display_name}\n"
        f"<b>Username:</b> @{author.username or 'не установлен'}\n"
        f"<b>Плагинов:</b> {plugins_count}\n"
        f"<b>Загрузок:</b> {downloads_count}\n"
        f"<b>Подписчиков:</b> {subscribers_count}\n"
    )
    
    keyboard_buttons = [
        [InlineKeyboardButton(
            text=AUTHOR["unsubscribe"] if is_subscribed_to_author else AUTHOR["subscribe"],
            callback_data=f"{'unsubscribe_author' if is_subscribed_to_author else 'subscribe_author'}_{author.user_id}"
        )],
        [InlineKeyboardButton(text=PLUGIN_PAGE["back_to_plugin"], callback_data=f"plugin_{plugin_id}")],
        [InlineKeyboardButton(text=COMMON["back"], callback_data="menu")]
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    if author.banner_photo_id:
        try:
            await callback_query.message.delete()
            await callback_query.bot.send_photo(
                chat_id=callback_query.from_user.id,
                photo=author.banner_photo_id,
                caption=text,
                reply_markup=keyboard
            )
        except:
            await _edit_or_send(callback_query, text, reply_markup=keyboard)
    else:
        await _edit_or_send(callback_query, text, reply_markup=keyboard)
    
    await callback_query.answer()


@router.callback_query(F.data.startswith("author_profile_"))
async def show_author_profile_direct(callback_query: types.CallbackQuery):
    author_id = int(callback_query.data.replace("author_profile_", ""))
    author = db.get_user(author_id)
    
    if not author:
        await callback_query.answer("❌ Автор не найден.", show_alert=True)
        return
    
    stats = db.get_user_stats(author.user_id)
    plugins_count = stats.get("plugins_count", 0)
    downloads_count = stats.get("total_downloads", 0)
    subscribers_count = stats.get("subscribers_count", 0)
    
    is_subscribed_to_author = db.is_subscribed_to_author(callback_query.from_user.id, author.user_id)
    
    text = (
        f"👤 <b>Профиль автора</b>\n\n"
        f"<b>Никнейм:</b> {author.display_name}\n"
        f"<b>Username:</b> @{author.username or 'не установлен'}\n"
        f"<b>Плагинов:</b> {plugins_count}\n"
        f"<b>Загрузок:</b> {downloads_count}\n"
        f"<b>Подписчиков:</b> {subscribers_count}\n"
    )
    
    keyboard_buttons = [
        [InlineKeyboardButton(
            text=AUTHOR["unsubscribe"] if is_subscribed_to_author else AUTHOR["subscribe"],
            callback_data=f"{'unsubscribe_author' if is_subscribed_to_author else 'subscribe_author'}_{author.user_id}"
        )],
        [InlineKeyboardButton(text=COMMON["back"], callback_data="menu")]
    ]
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    if author.banner_photo_id:
        try:
            await callback_query.message.delete()
            await callback_query.bot.send_photo(
                chat_id=callback_query.from_user.id,
                photo=author.banner_photo_id,
                caption=text,
                reply_markup=keyboard
            )
        except:
            await _edit_or_send(callback_query, text, reply_markup=keyboard)
    else:
        await _edit_or_send(callback_query, text, reply_markup=keyboard)
    
    await callback_query.answer()


@router.callback_query(F.data.startswith("rate_"))
async def start_review(callback_query: types.CallbackQuery, state: FSMContext):
    plugin_id = int(callback_query.data.replace("rate_", ""))
    
    existing_review = db.get_user_review(plugin_id, callback_query.from_user.id)
    if existing_review:
        await callback_query.answer("⚠️ Вы уже оставляли отзыв на этот плагин.", show_alert=True)
        return
    
    await state.update_data(plugin_id=plugin_id)
    await state.set_state(ReviewStates.waiting_rating)
    keyboard = create_rating_menu(plugin_id)
    await _edit_or_send(callback_query, "⭐ Оцените плагин:", reply_markup=keyboard)
    await callback_query.answer()


@router.callback_query(F.data.startswith("set_rating_"))
async def set_rating(callback_query: types.CallbackQuery, state: FSMContext):
    parts = callback_query.data.split("_")
    plugin_id = int(parts[2])
    rating = int(parts[3])
    
    await state.update_data(plugin_id=plugin_id, rating=rating)
    await state.set_state(ReviewStates.waiting_text)
    await _edit_or_send(callback_query, "💬 Напишите текст отзыва (или отправьте /skip чтобы пропустить):")
    await callback_query.answer()


@router.message(ReviewStates.waiting_text)
async def process_review_text(message: types.Message, state: FSMContext):
    if message.text == "/skip":
        review_text = ""
    else:
        review_text = message.text.strip()
    
    data = await state.get_data()
    plugin_id = data["plugin_id"]
    rating = data["rating"]
    user_id = message.from_user.id
    
    success = db.add_review(plugin_id, user_id, rating, review_text)
    
    if success:
        await message.answer("✅ Отзыв добавлен!")
        
        # Возвращаем на страницу плагина
        plugin = db.get_plugin(plugin_id)
        if plugin:
            is_subscribed = db.is_subscribed(user_id, plugin_id)
            is_subscribed_to_author = db.is_subscribed_to_author(user_id, plugin['author_id'])
            
            author = db.get_user(plugin['author_id'])
            author_username = author.username if author else "unknown"
            
            stats = db.get_plugin_stats(plugin_id)
            rating_val = stats.get("rating", 0)
            downloads = stats.get("downloads", 0)
            subscribers = stats.get("subscribers", 0)
            reviews_count = stats.get("reviews_count", 0)
            
            text = (
                f"📦 <b>{plugin['name']}</b>\n\n"
                f"<b>Автор:</b> @{author_username}\n"
                f"<b>Категория:</b> {CATEGORIES_CONFIG.get(plugin['category'], plugin['category'])}\n"
                f"<b>Статус:</b> {DEV_STATUSES_CONFIG.get(plugin['status'], plugin['status'])}\n"
                f"<b>Описание:</b> {plugin['description']}\n\n"
                f"⭐ {rating_val:.1f} | 📥 {downloads} | 👥 {subscribers} | 💬 {reviews_count}"
            )
            
            keyboard = create_plugin_page_menu(
                plugin_id, 
                is_subscribed, 
                is_subscribed_to_author, 
                plugin['author_id']
            )
            
            await message.answer(text, reply_markup=keyboard)
    else:
        await message.answer("⚠️ Ошибка при добавлении отзыва.")
    
    await state.clear()


@router.callback_query(F.data.startswith("reviews_"))
async def show_reviews(callback_query: types.CallbackQuery):
    parts = callback_query.data.split("_")
    plugin_id = int(parts[1])
    page = int(parts[2]) if len(parts) > 2 else 1
    
    reviews = db.get_plugin_reviews(plugin_id)
    if not reviews:
        await callback_query.answer("📭 Отзывов пока нет.", show_alert=True)
        return
    
    total_pages = max(1, (len(reviews) + 4) // 5)
    page = max(1, min(page, total_pages))
    
    start_idx = (page - 1) * 5
    end_idx = start_idx + 5
    page_reviews = reviews[start_idx:end_idx]
    
    text = f"💬 <b>Отзывы</b> ({len(reviews)})\n\n"
    
    for review in page_reviews:
        user = db.get_user(review.user_id)
        username = user.username if user else "Anonymous"
        stars = "⭐" * review.rating
        text += f"<b>@{username}</b> {stars}\n"
        if review.text:
            text += f"{review.text}\n"
        text += f"<i>{review.created_at}</i>\n\n"
    
    keyboard_buttons = []
    if total_pages > 1:
        nav_buttons = []
        if page > 1:
            nav_buttons.append(InlineKeyboardButton(text=PAGINATION["prev"], callback_data=f"reviews_{plugin_id}_{page - 1}"))
        nav_buttons.append(InlineKeyboardButton(text=f"{page}/{total_pages}", callback_data="noop"))
        if page < total_pages:
            nav_buttons.append(InlineKeyboardButton(text=PAGINATION["next"], callback_data=f"reviews_{plugin_id}_{page + 1}"))
        keyboard_buttons.append(nav_buttons)
    
    keyboard_buttons.append([InlineKeyboardButton(text=PLUGIN_PAGE["back_to_plugin"], callback_data=f"plugin_{plugin_id}")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    await _edit_or_send(callback_query, text, reply_markup=keyboard)
    await callback_query.answer()


@router.callback_query(F.data.startswith("download_"))
async def download_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("download_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin or plugin['is_archived']:
        await callback_query.answer("❌ Плагин не найден.", show_alert=True)
        return
    
    try:
        await callback_query.bot.send_document(
            chat_id=callback_query.from_user.id,
            document=plugin['file_id'],
            caption=f"📦 {plugin['name']}\n\n{plugin['description']}"
        )
        
        db.increment_downloads(plugin_id)
        await callback_query.answer("✅ Файл отправлен!")
    except Exception as e:
        await callback_query.answer("⚠️ Ошибка при отправке файла.", show_alert=True)


@router.callback_query(F.data.startswith("manage_"))
async def manage_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("manage_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin or plugin['author_id'] != callback_query.from_user.id:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    keyboard = create_manage_menu(plugin_id, plugin['is_archived'])
    await _edit_or_send(callback_query, "⚙️ Управление плагином:", reply_markup=keyboard)
    await callback_query.answer()


@router.callback_query(F.data.startswith("archive_"))
async def archive_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("archive_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin or plugin['author_id'] != callback_query.from_user.id:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.update_plugin(plugin_id, is_archived=True)
    if success:
        await callback_query.answer("✅ Плагин архивирован.")
        await _edit_or_send(callback_query, "⚙️ Управление плагином:", 
                           reply_markup=create_manage_menu(plugin_id, True))
    else:
        await callback_query.answer("⚠️ Ошибка при архивации.", show_alert=True)


@router.callback_query(F.data.startswith("unarchive_"))
async def unarchive_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("unarchive_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin or plugin['author_id'] != callback_query.from_user.id:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.update_plugin(plugin_id, is_archived=False)
    if success:
        await callback_query.answer("✅ Плагин разархивирован.")
        await _edit_or_send(callback_query, "⚙️ Управление плагином:", 
                           reply_markup=create_manage_menu(plugin_id, False))
    else:
        await callback_query.answer("⚠️ Ошибка при разархивации.", show_alert=True)


@router.callback_query(F.data.startswith("update_"))
async def update_plugin(callback_query: types.CallbackQuery, state: FSMContext):
    plugin_id = int(callback_query.data.replace("update_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin or plugin['author_id'] != callback_query.from_user.id:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    await state.set_state(UploadStates.waiting_file)
    await state.update_data(update_plugin_id=plugin_id)
    await _edit_or_send(callback_query, 
        "📤 Отправьте новую версию файла плагина:",
        reply_markup=create_cancel_menu()
    )
    await callback_query.answer()


@router.callback_query(F.data == "menu")
async def back_to_menu(callback_query: types.CallbackQuery):
    await callback_query.answer(MESSAGES["back_to_menu"])
    await _edit_or_send(callback_query, MESSAGES["start"], reply_markup=create_main_menu())


@router.callback_query(F.data == "continue_upload")
async def continue_upload(callback_query: types.CallbackQuery, state: FSMContext):
    await state.set_state(UploadStates.waiting_name_and_photo)
    await _edit_or_send(callback_query, MESSAGES["upload_step2"])
    await callback_query.answer()


@router.callback_query(F.data == "replace_file")
async def replace_file(callback_query: types.CallbackQuery, state: FSMContext):
    await state.set_state(UploadStates.waiting_file)
    await _edit_or_send(callback_query, MESSAGES["upload_step1"])
    await callback_query.answer()


@router.callback_query(F.data.startswith("back_to_plugin_"))
async def back_to_plugin(callback_query: types.CallbackQuery):
    plugin_id_str = callback_query.data.replace("back_to_plugin_", "")
    if plugin_id_str == "0":
        await callback_query.answer()
        return
    
    plugin_id = int(plugin_id_str)
    plugin = db.get_plugin(plugin_id)
    
    if not plugin:
        await callback_query.answer("❌ Плагин не найден.", show_alert=True)
        return
    
    user_id = callback_query.from_user.id
    is_subscribed = db.is_subscribed(user_id, plugin_id)
    is_subscribed_to_author = db.is_subscribed_to_author(user_id, plugin['author_id'])
    
    author = db.get_user(plugin['author_id'])
    author_username = author.username if author else "unknown"
    
    stats = db.get_plugin_stats(plugin_id)
    rating = stats.get("rating", 0)
    downloads = stats.get("downloads", 0)
    subscribers = stats.get("subscribers", 0)
    reviews_count = stats.get("reviews_count", 0)
    
    text = (
        f"📦 <b>{plugin['name']}</b>\n\n"
        f"<b>Автор:</b> @{author_username}\n"
        f"<b>Категория:</b> {CATEGORIES_CONFIG.get(plugin['category'], plugin['category'])}\n"
        f"<b>Статус:</b> {DEV_STATUSES_CONFIG.get(plugin['status'], plugin['status'])}\n"
        f"<b>Описание:</b> {plugin['description']}\n\n"
        f"⭐ {rating:.1f} | 📥 {downloads} | 👥 {subscribers} | 💬 {reviews_count}"
    )
    
    keyboard = create_plugin_page_menu(
        plugin_id, 
        is_subscribed, 
        is_subscribed_to_author, 
        plugin['author_id']
    )
    
    await _edit_or_send(callback_query, text, reply_markup=keyboard)
    await callback_query.answer