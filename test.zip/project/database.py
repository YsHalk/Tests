import sqlite3
import os
import json
from datetime import datetime
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass


@dataclass
class User:
    user_id: int
    username: str
    display_name: str
    banner_photo_id: Optional[str] = None
    subscribers: int = 0
    created_at: Optional[str] = None


@dataclass
class Plugin:
    plugin_id: int
    name: str
    description: str
    file_id: str
    file_name: str
    file_size: int
    photo_id: Optional[str] = None
    author_id: int = 0
    category: str = ""
    status: str = ""
    tags: str = ""
    views: int = 0
    downloads: int = 0
    rating: float = 0.0
    rating_count: int = 0
    is_archived: bool = False
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class Rating:
    rating_id: int
    plugin_id: int
    user_id: int
    rating: int
    created_at: Optional[str] = None


@dataclass
class Review:
    review_id: int
    plugin_id: int
    user_id: int
    rating: int
    text: str
    created_at: Optional[str] = None


@dataclass
class Subscription:
    subscription_id: int
    user_id: int
    plugin_id: int
    created_at: Optional[str] = None


@dataclass
class AuthorSubscription:
    subscription_id: int
    user_id: int
    author_id: int
    created_at: Optional[str] = None


class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self._create_tables()
    
    def _create_tables(self):
        """Создание всех таблиц"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Таблица пользователей
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    display_name TEXT NOT NULL,
                    banner_photo_id TEXT,
                    subscribers INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Таблица плагинов
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS plugins (
                    plugin_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    description TEXT NOT NULL,
                    file_id TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    photo_id TEXT,
                    author_id INTEGER NOT NULL,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL,
                    tags TEXT,
                    views INTEGER DEFAULT 0,
                    downloads INTEGER DEFAULT 0,
                    rating REAL DEFAULT 0.0,
                    rating_count INTEGER DEFAULT 0,
                    is_archived BOOLEAN DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (author_id) REFERENCES users (user_id)
                )
            """)
            
            # Таблица оценок
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ratings (
                    rating_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plugin_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(plugin_id, user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Таблица отзывов
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    review_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plugin_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
                    text TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Таблица подписок на плагины
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS subscriptions (
                    subscription_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    plugin_id INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, plugin_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id)
                )
            """)
            
            # Таблица подписок на авторов
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS author_subscriptions (
                    subscription_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    author_id INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_id, author_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (author_id) REFERENCES users (user_id)
                )
            """)
            
            # Таблица заявок на загрузку
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS submissions (
                    submission_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    plugin_name TEXT NOT NULL,
                    description TEXT NOT NULL,
                    file_id TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    photo_id TEXT,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL,
                    tags TEXT,
                    state TEXT DEFAULT 'pending',
                    admin_message_id INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Таблица обновлений плагинов
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS updates (
                    update_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plugin_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    file_id TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    description TEXT,
                    state TEXT DEFAULT 'pending',
                    admin_message_id INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Создание индексов
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_plugins_name ON plugins(name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_plugins_author ON plugins(author_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_plugins_category ON plugins(category)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_plugins_status ON plugins(status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_plugins_archived ON plugins(is_archived)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON subscriptions(user_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_subscriptions_plugin ON subscriptions(plugin_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_reviews_plugin ON reviews(plugin_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_author_subscriptions_user ON author_subscriptions(user_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_author_subscriptions_author ON author_subscriptions(author_id)")
            
            conn.commit()

    # ========== INTERNAL HELPERS ==========

    def _get_connection(self) -> sqlite3.Connection:
        """Получить соединение с БД (внутренний хелпер)."""
        return sqlite3.connect(self.db_path)
    
    # ========== USER METHODS ==========
    
    def create_user(self, user_id: int, username: str, display_name: str) -> bool:
        """Создание нового пользователя"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR IGNORE INTO users 
                    (user_id, username, display_name) 
                    VALUES (?, ?, ?)
                """, (user_id, username.lower(), display_name))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error creating user: {e}")
            return False
    
    def get_user(self, user_id: int) -> Optional[User]:
        """Получение пользователя по ID"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
                row = cursor.fetchone()
                if row:
                    return User(*row)
                return None
        except Exception as e:
            print(f"Error getting user: {e}")
            return None
    
    def update_user(self, user_id: int, **kwargs) -> bool:
        """Обновление данных пользователя"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                fields = []
                values = []
                for key, value in kwargs.items():
                    if key in ["username", "display_name", "banner_url", "banner_photo_id", "subscribers"]:
                        fields.append(f"{key} = ?")
                        values.append(value)
                
                if fields:
                    values.append(user_id)
                    query = f"UPDATE users SET {', '.join(fields)} WHERE user_id = ?"
                    cursor.execute(query, values)
                    conn.commit()
                    return cursor.rowcount > 0
                return False
        except Exception as e:
            print(f"Error updating user: {e}")
            return False
    
    def get_user_stats(self, user_id: int) -> Dict[str, Any]:
        """Получение статистики пользователя"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Количество плагинов
                cursor.execute("""
                    SELECT COUNT(*) FROM plugins 
                    WHERE author_id = ? AND is_archived = 0
                """, (user_id,))
                plugin_count = cursor.fetchone()[0]
                
                # Общее количество скачиваний
                cursor.execute("""
                    SELECT SUM(downloads) FROM plugins 
                    WHERE author_id = ? AND is_archived = 0
                """, (user_id,))
                total_downloads = cursor.fetchone()[0] or 0
                
                # Общее количество просмотров
                cursor.execute("""
                    SELECT SUM(views) FROM plugins 
                    WHERE author_id = ? AND is_archived = 0
                """, (user_id,))
                total_views = cursor.fetchone()[0] or 0
                
                # Средний рейтинг
                cursor.execute("""
                    SELECT AVG(rating) FROM plugins 
                    WHERE author_id = ? AND is_archived = 0 AND rating_count > 0
                """, (user_id,))
                avg_rating = cursor.fetchone()[0] or 0.0
                
                # Подписчики
                cursor.execute("""
                    SELECT subscribers FROM users WHERE user_id = ?
                """, (user_id,))
                subscribers = cursor.fetchone()[0] or 0
                
                return {
                    "plugin_count": plugin_count,
                    "total_downloads": total_downloads,
                    "total_views": total_views,
                    "avg_rating": round(avg_rating, 2),
                    "subscribers": subscribers
                }
        except Exception as e:
            print(f"Error getting user stats: {e}")
            return {}
    
    def get_plugin_stats(self, plugin_id: int) -> Dict[str, Any]:
        """Получение статистики плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Получаем плагин
                cursor.execute("""
                    SELECT rating, downloads, views, rating_count 
                    FROM plugins WHERE plugin_id = ?
                """, (plugin_id,))
                row = cursor.fetchone()
                if not row:
                    return {}
                
                rating, downloads, views, rating_count = row
                
                # Количество подписчиков
                cursor.execute("""
                    SELECT COUNT(*) FROM subscriptions WHERE plugin_id = ?
                """, (plugin_id,))
                subscribers = cursor.fetchone()[0]
                
                # Количество отзывов
                cursor.execute("""
                    SELECT COUNT(*) FROM reviews WHERE plugin_id = ?
                """, (plugin_id,))
                reviews_count = cursor.fetchone()[0]
                
                return {
                    "rating": rating or 0.0,
                    "downloads": downloads or 0,
                    "views": views or 0,
                    "rating_count": rating_count or 0,
                    "subscribers": subscribers or 0,
                    "reviews_count": reviews_count or 0
                }
        except Exception as e:
            print(f"Error getting plugin stats: {e}")
            return {}
    
    # ========== PLUGIN METHODS ==========
    
    def create_plugin(self, plugin: Plugin) -> Optional[int]:
        """Создание нового плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO plugins 
                    (name, description, file_id, file_name, file_size, photo_id, 
                     author_id, category, status, tags) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    plugin.name, plugin.description, plugin.file_id, 
                    plugin.file_name, plugin.file_size, plugin.photo_id,
                    plugin.author_id, plugin.category, plugin.status, plugin.tags
                ))
                conn.commit()
                return cursor.lastrowid
        except Exception as e:
            print(f"Error creating plugin: {e}")
            return None
    
    def get_plugin(self, plugin_id: int) -> Optional[Plugin]:
        """Получение плагина по ID"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM plugins WHERE plugin_id = ?", (plugin_id,))
                row = cursor.fetchone()
                if row:
                    return Plugin(*row)
                return None
        except Exception as e:
            print(f"Error getting plugin: {e}")
            return None
    
    def get_plugin_with_author(self, plugin_id: int) -> Optional[Dict[str, Any]]:
        """Получение плагина с данными автора"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT p.*, u.username, u.display_name, u.banner_photo_id 
                    FROM plugins p 
                    JOIN users u ON p.author_id = u.user_id 
                    WHERE p.plugin_id = ?
                """, (plugin_id,))
                row = cursor.fetchone()
                if row:
                    plugin_data = dict(zip([
                        "plugin_id", "name", "description", "file_id", "file_name",
                        "file_size", "photo_id", "author_id", "category", "status",
                        "tags", "views", "downloads", "rating", "rating_count",
                        "is_archived", "created_at", "updated_at", "author_username", "author_display_name", "author_banner_photo_id"
                    ], row))
                    return plugin_data
                return None
        except Exception as e:
            print(f"Error getting plugin with author: {e}")
            return None
    
    def update_plugin(self, plugin_id: int, **kwargs) -> bool:
        """Обновление данных плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                fields = ["updated_at = CURRENT_TIMESTAMP"]
                values = []
                
                for key, value in kwargs.items():
                    if key in ["name", "description", "photo_id", "category", 
                              "status", "tags", "views", "downloads", "rating", 
                              "rating_count", "is_archived", "file_id", "file_name", "file_size"]:
                        fields.append(f"{key} = ?")
                        values.append(value)
                
                if fields:
                    values.append(plugin_id)
                    query = f"UPDATE plugins SET {', '.join(fields)} WHERE plugin_id = ?"
                    cursor.execute(query, values)
                    conn.commit()
                    return cursor.rowcount > 0
                return False
        except Exception as e:
            print(f"Error updating plugin: {e}")
            return False
    
    def delete_plugin(self, plugin_id: int) -> bool:
        """Удаление плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM plugins WHERE plugin_id = ?", (plugin_id,))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error deleting plugin: {e}")
            return False
    
    def increment_views(self, plugin_id: int) -> bool:
        """Увеличение счетчика просмотров"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE plugins SET views = views + 1 
                    WHERE plugin_id = ?
                """, (plugin_id,))
                conn.commit()
                return True
        except Exception as e:
            print(f"Error incrementing views: {e}")
            return False
    
    def increment_downloads(self, plugin_id: int) -> bool:
        """Увеличение счетчика скачиваний"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE plugins SET downloads = downloads + 1 
                    WHERE plugin_id = ?
                """, (plugin_id,))
                conn.commit()
                return True
        except Exception as e:
            print(f"Error incrementing downloads: {e}")
            return False
    
    def get_user_plugins(self, user_id: int, include_archived: bool = False) -> List[Dict[str, Any]]:
        """Получение плагинов пользователя"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                query = """
                    SELECT p.*, u.username, u.display_name 
                    FROM plugins p 
                    JOIN users u ON p.author_id = u.user_id 
                    WHERE p.author_id = ?
                """
                if not include_archived:
                    query += " AND p.is_archived = 0"
                query += " ORDER BY p.created_at DESC"
                
                cursor.execute(query, (user_id,))
                rows = cursor.fetchall()
                
                plugins = []
                for row in rows:
                    plugin_data = dict(zip([
                        "plugin_id", "name", "description", "file_id", "file_name",
                        "file_size", "photo_id", "author_id", "category", "status",
                        "tags", "views", "downloads", "rating", "rating_count",
                        "is_archived", "created_at", "updated_at", "author_username", "author_display_name"
                    ], row))
                    plugins.append(plugin_data)
                
                return plugins
        except Exception as e:
            print(f"Error getting user plugins: {e}")
            return []
    
    def get_popular_plugins(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Получение популярных плагинов"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT p.*, u.username, u.display_name 
                    FROM plugins p 
                    JOIN users u ON p.author_id = u.user_id 
                    WHERE p.is_archived = 0 
                    ORDER BY (p.downloads + p.views + p.rating_count * 10) DESC 
                    LIMIT ?
                """, (limit,))
                
                rows = cursor.fetchall()
                plugins = []
                for row in rows:
                    plugin_data = dict(zip([
                        "plugin_id", "name", "description", "file_id", "file_name",
                        "file_size", "photo_id", "author_id", "category", "status",
                        "tags", "views", "downloads", "rating", "rating_count",
                        "is_archived", "created_at", "updated_at", "author_username", "author_display_name"
                    ], row))
                    plugins.append(plugin_data)
                
                return plugins
        except Exception as e:
            print(f"Error getting popular plugins: {e}")
            return []
    
    def get_plugins_by_category(self, category: str, limit: int | None = None) -> List[Dict[str, Any]]:
        """Получение плагинов по категории."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                sql = """
                    SELECT p.*, u.username, u.display_name 
                    FROM plugins p 
                    JOIN users u ON p.author_id = u.user_id 
                    WHERE p.category = ? AND p.is_archived = 0 
                    ORDER BY p.created_at DESC
                """
                params: tuple[Any, ...] = (category,)
                if limit is not None:
                    sql += "\nLIMIT ?"
                    params = (category, int(limit))

                cursor.execute(sql, params)
                
                rows = cursor.fetchall()
                plugins = []
                for row in rows:
                    plugin_data = dict(zip([
                        "plugin_id", "name", "description", "file_id", "file_name",
                        "file_size", "photo_id", "author_id", "category", "status",
                        "tags", "views", "downloads", "rating", "rating_count",
                        "is_archived", "created_at", "updated_at", "author_username", "author_display_name"
                    ], row))
                    plugins.append(plugin_data)
                
                return plugins
        except Exception as e:
            print(f"Error getting plugins by category: {e}")
            return []
    
    def search_plugins(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Поиск плагинов по запросу."""
        q = (query or "").strip()
        if not q:
            return []

        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                # Быстрый SQL-поиск
                search_term = f"%{q.lower()}%"
                cursor.execute(
                    """
                    SELECT p.*, u.username, u.display_name
                    FROM plugins p
                    JOIN users u ON p.author_id = u.user_id
                    WHERE (
                        LOWER(p.name) LIKE ? OR
                        LOWER(p.description) LIKE ? OR
                        LOWER(p.tags) LIKE ? OR
                        LOWER(u.username) LIKE ? OR
                        LOWER(u.display_name) LIKE ?
                    ) AND p.is_archived = 0
                    ORDER BY
                        (CASE WHEN LOWER(p.name) LIKE ? THEN 10 ELSE 0 END +
                         CASE WHEN LOWER(u.username) LIKE ? THEN 8 ELSE 0 END +
                         p.downloads + p.views + p.rating_count * 2) DESC
                    LIMIT ?
                    """,
                    (
                        search_term,
                        search_term,
                        search_term,
                        search_term,
                        search_term,
                        search_term,
                        search_term,
                        limit,
                    ),
                )

                rows = cursor.fetchall()
                cols = [
                    "plugin_id", "name", "description", "file_id", "file_name",
                    "file_size", "photo_id", "author_id", "category", "status",
                    "tags", "views", "downloads", "rating", "rating_count",
                    "is_archived", "created_at", "updated_at", "author_username", "author_display_name",
                ]
                plugins = [dict(zip(cols, row)) for row in rows]
                if plugins:
                    return plugins

                # Unicode fallback
                cursor.execute(
                    """
                    SELECT p.*, u.username, u.display_name
                    FROM plugins p
                    JOIN users u ON p.author_id = u.user_id
                    WHERE p.is_archived = 0
                    ORDER BY p.downloads + p.views + p.rating_count * 2 DESC
                    LIMIT 500
                    """
                )
                candidates = [dict(zip(cols, row)) for row in cursor.fetchall()]

                needle = q.casefold()

                def haystack(p: Dict[str, Any]) -> str:
                    return " ".join(
                        [
                            str(p.get("name") or ""),
                            str(p.get("description") or ""),
                            str(p.get("tags") or ""),
                            str(p.get("author_username") or ""),
                            str(p.get("author_display_name") or ""),
                        ]
                    ).casefold()

                ranked = []
                for p in candidates:
                    h = haystack(p)
                    if needle in h:
                        score = 0
                        if needle in str(p.get("name") or "").casefold():
                            score += 50
                        if needle in str(p.get("author_username") or "").casefold():
                            score += 20
                        score += int(p.get("downloads") or 0)
                        score += int(p.get("views") or 0)
                        score += int(p.get("rating_count") or 0) * 2
                        ranked.append((score, p))

                ranked.sort(key=lambda x: x[0], reverse=True)
                return [p for _, p in ranked[:limit]]

        except Exception as e:
            print(f"Error searching plugins: {e}")
            return []
    
    # ========== RATING METHODS ==========
    
    def add_rating(self, plugin_id: int, user_id: int, rating: int) -> bool:
        """Добавление или обновление оценки"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO ratings (plugin_id, user_id, rating) 
                    VALUES (?, ?, ?) 
                    ON CONFLICT(plugin_id, user_id) 
                    DO UPDATE SET rating = excluded.rating
                """, (plugin_id, user_id, rating))
                
                # Обновляем средний рейтинг плагина
                cursor.execute("""
                    UPDATE plugins 
                    SET rating = (
                        SELECT AVG(rating) FROM ratings WHERE plugin_id = ?
                    ),
                    rating_count = (
                        SELECT COUNT(*) FROM ratings WHERE plugin_id = ?
                    )
                    WHERE plugin_id = ?
                """, (plugin_id, plugin_id, plugin_id))
                
                conn.commit()
                return True
        except Exception as e:
            print(f"Error adding rating: {e}")
            return False
    
    def get_user_rating(self, plugin_id: int, user_id: int) -> Optional[int]:
        """Получение оценки пользователя для плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT rating FROM ratings 
                    WHERE plugin_id = ? AND user_id = ?
                """, (plugin_id, user_id))
                row = cursor.fetchone()
                return row[0] if row else None
        except Exception as e:
            print(f"Error getting user rating: {e}")
            return None
    
    # ========== REVIEW METHODS ==========
    
    def add_review(self, plugin_id: int, user_id: int, rating: int, text: str) -> bool:
        """Добавление отзыва"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO reviews (plugin_id, user_id, rating, text) 
                    VALUES (?, ?, ?, ?)
                """, (plugin_id, user_id, rating, text))
                
                # Также обновляем рейтинг
                cursor.execute("""
                    INSERT INTO ratings (plugin_id, user_id, rating) 
                    VALUES (?, ?, ?) 
                    ON CONFLICT(plugin_id, user_id) 
                    DO UPDATE SET rating = excluded.rating
                """, (plugin_id, user_id, rating))
                
                # Обновляем средний рейтинг плагина
                cursor.execute("""
                    UPDATE plugins 
                    SET rating = (
                        SELECT AVG(rating) FROM ratings WHERE plugin_id = ?
                    ),
                    rating_count = (
                        SELECT COUNT(*) FROM ratings WHERE plugin_id = ?
                    )
                    WHERE plugin_id = ?
                """, (plugin_id, plugin_id, plugin_id))
                
                conn.commit()
                return True
        except Exception as e:
            print(f"Error adding review: {e}")
            return False
    
    def get_plugin_reviews(self, plugin_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """Получение отзывов плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT r.*, u.username, u.display_name 
                    FROM reviews r 
                    JOIN users u ON r.user_id = u.user_id 
                    WHERE r.plugin_id = ? 
                    ORDER BY r.created_at DESC
                    LIMIT ?
                """, (plugin_id, limit))
                
                rows = cursor.fetchall()
                reviews = []
                for row in rows:
                    review_data = dict(zip([
                        "review_id", "plugin_id", "user_id", "rating", "text", "created_at",
                        "username", "display_name"
                    ], row))
                    reviews.append(review_data)
                
                return reviews
        except Exception as e:
            print(f"Error getting plugin reviews: {e}")
            return []
    
    def get_user_review(self, plugin_id: int, user_id: int) -> Optional[Dict[str, Any]]:
        """Получение отзыва пользователя для плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM reviews 
                    WHERE plugin_id = ? AND user_id = ?
                """, (plugin_id, user_id))
                row = cursor.fetchone()
                if row:
                    keys = ["review_id", "plugin_id", "user_id", "rating", "text", "created_at"]
                    return dict(zip(keys, row))
                return None
        except Exception as e:
            print(f"Error getting user review: {e}")
            return None
    
    # ========== SUBSCRIPTION METHODS ==========
    
    def subscribe(self, user_id: int, plugin_id: int) -> bool:
        """Подписка на обновления плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR IGNORE INTO subscriptions (user_id, plugin_id) 
                    VALUES (?, ?)
                """, (user_id, plugin_id))
                
                # Увеличиваем счетчик подписчиков автора
                if cursor.rowcount > 0:
                    cursor.execute("""
                        UPDATE users 
                        SET subscribers = subscribers + 1 
                        WHERE user_id = (
                            SELECT author_id FROM plugins WHERE plugin_id = ?
                        )
                    """, (plugin_id,))
                
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error subscribing: {e}")
            return False
    
    def unsubscribe(self, user_id: int, plugin_id: int) -> bool:
        """Отписка от обновлений плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    DELETE FROM subscriptions 
                    WHERE user_id = ? AND plugin_id = ?
                """, (user_id, plugin_id))
                
                # Уменьшаем счетчик подписчиков автора
                if cursor.rowcount > 0:
                    cursor.execute("""
                        UPDATE users 
                        SET subscribers = MAX(0, subscribers - 1) 
                        WHERE user_id = (
                            SELECT author_id FROM plugins WHERE plugin_id = ?
                        )
                    """, (plugin_id,))
                
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error unsubscribing: {e}")
            return False
    
    # Алиасы для обратной совместимости
    def subscribe_to_plugin(self, user_id: int, plugin_id: int) -> bool:
        """Алиас для subscribe (обратная совместимость)"""
        return self.subscribe(user_id, plugin_id)
    
    def unsubscribe_from_plugin(self, user_id: int, plugin_id: int) -> bool:
        """Алиас для unsubscribe (обратная совместимость)"""
        return self.unsubscribe(user_id, plugin_id)
    
    def is_subscribed(self, user_id: int, plugin_id: int) -> bool:
        """Проверка подписки"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT 1 FROM subscriptions 
                    WHERE user_id = ? AND plugin_id = ?
                """, (user_id, plugin_id))
                return cursor.fetchone() is not None
        except Exception as e:
            print(f"Error checking subscription: {e}")
            return False
    
    def get_user_subscriptions(self, user_id: int) -> List[Dict[str, Any]]:
        """Получение списка подписок пользователя"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT p.*, u.username, u.display_name 
                    FROM subscriptions s 
                    JOIN plugins p ON s.plugin_id = p.plugin_id 
                    JOIN users u ON p.author_id = u.user_id 
                    WHERE s.user_id = ? AND p.is_archived = 0 
                    ORDER BY s.created_at DESC
                """, (user_id,))
                
                rows = cursor.fetchall()
                plugins = []
                for row in rows:
                    plugin_data = dict(zip([
                        "plugin_id", "name", "description", "file_id", "file_name",
                        "file_size", "photo_id", "author_id", "category", "status",
                        "tags", "views", "downloads", "rating", "rating_count",
                        "is_archived", "created_at", "updated_at", "author_username", "author_display_name"
                    ], row))
                    plugins.append(plugin_data)
                
                return plugins
        except Exception as e:
            print(f"Error getting user subscriptions: {e}")
            return []
    
    def get_plugin_subscribers(self, plugin_id: int) -> List[int]:
        """Получение списка подписчиков плагина"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT user_id FROM subscriptions 
                    WHERE plugin_id = ?
                """, (plugin_id,))
                return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            print(f"Error getting plugin subscribers: {e}")
            return []
    
    # ========== AUTHOR SUBSCRIPTION METHODS ==========
    
    def subscribe_to_author(self, user_id: int, author_id: int) -> bool:
        """Подписка на автора"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR IGNORE INTO author_subscriptions (user_id, author_id) 
                    VALUES (?, ?)
                """, (user_id, author_id))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error subscribing to author: {e}")
            return False
    
    def unsubscribe_from_author(self, user_id: int, author_id: int) -> bool:
        """Отписка от автора"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    DELETE FROM author_subscriptions 
                    WHERE user_id = ? AND author_id = ?
                """, (user_id, author_id))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            print(f"Error unsubscribing from author: {e}")
            return False
    
    def is_subscribed_to_author(self, user_id: int, author_id: int) -> bool:
        """Проверка подписки на автора"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT 1 FROM author_subscriptions 
                    WHERE user_id = ? AND author_id = ?
                """, (user_id, author_id))
                return cursor.fetchone() is not None
        except Exception as e:
            print(f"Error checking author subscription: {e}")
            return False
    
    def get_author_subscribers(self, author_id: int) -> List[int]:
        """Получение подписчиков автора"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT user_id FROM author_subscriptions 
                    WHERE author_id = ?
                """, (author_id,))
                return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            print(f"Error getting author subscribers: {e}")
            return []
    
    def get_user_author_subscriptions(self, user_id: int) -> List[Dict[str, Any]]:
        """Получение списка подписок пользователя на авторов"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT u.* 
                    FROM author_subscriptions s 
                    JOIN users u ON s.author_id = u.user_id 
                    WHERE s.user_id = ?
                    ORDER BY s.created_at DESC
                """, (user_id,))
                
                rows = cursor.fetchall()
                authors = []
                for row in rows:
                    author_data = dict(zip([
                        "user_id", "username", "display_name", "banner_photo_id", 
                        "subscribers", "created_at"
                    ], row))
                    authors.append(author_data)
                
                return authors
        except Exception as e:
            print(f"Error getting user author subscriptions: {e}")
            return []
    
    # ========== SUBMISSION METHODS ==========
    
    def create_submission(self, submission_data: Dict[str, Any]) -> Optional[int]:
        """Создание новой заявки"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO submissions 
                    (user_id, plugin_name, description, file_id, file_name, 
                     file_size, photo_id, category, status, tags, state) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
                """, (
                    submission_data["user_id"],
                    submission_data["plugin_name"],
                    submission_data["description"],
                    submission_data["file_id"],
                    submission_data["file_name"],
                    submission_data["file_size"],
                    submission_data.get("photo_id"),
                    submission_data["category"],
                    submission_data["status"],
                    submission_data.get("tags", "")
                ))
                conn.commit()
                return cursor.lastrowid
        except Exception as e:
            print(f"Error creating submission: {e}")
            return None
    
    def get_submission(self, submission_id: int) -> Optional[Dict[str, Any]]:
        """Получение заявки по ID"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT s.*, u.username, u.display_name 
                    FROM submissions s 
                    JOIN users u ON s.user_id = u.user_id 
                    WHERE s.submission_id = ?
                """, (submission_id,))
                row = cursor.fetchone()
                if row:
                    keys = ["submission_id", "user_id", "plugin_name", "description", 
                           "file_id", "file_name", "file_size", "photo_id", "category",
                           "status", "tags", "state", "admin_message_id", "created_at",
                           "username", "display_name"]
                    return dict(zip(keys, row))
                return None
        except Exception as e:
            print(f"Error getting submission: {e}")
            return None
    
    def update_submission(self, submission_id: int, **kwargs) -> bool:
        """Обновление заявки"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                fields = []
                values = []
                
                for key, value in kwargs.items():
                    if key in [
                        "state",
                        "admin_message_id",
                        "plugin_name",
                        "description",
                        "category",
                        "status",
                        "tags",
                        "photo_id",
                        "file_id",
                        "file_name",
                        "file_size",
                    ]:
                        fields.append(f"{key} = ?")
                        values.append(value)
                
                if fields:
                    values.append(submission_id)
                    query = f"UPDATE submissions SET {', '.join(fields)} WHERE submission_id = ?"
                    cursor.execute(query, values)
                    conn.commit()
                    return cursor.rowcount > 0
                return False
        except Exception as e:
            print(f"Error updating submission: {e}")
            return False
    
    def get_pending_submissions(self) -> List[Dict[str, Any]]:
        """Получение списка ожидающих заявок"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT s.*, u.username, u.display_name 
                    FROM submissions s 
                    JOIN users u ON s.user_id = u.user_id 
                    WHERE s.state = 'pending' 
                    ORDER BY s.created_at ASC
                """)
                
                rows = cursor.fetchall()
                submissions = []
                for row in rows:
                    keys = ["submission_id", "user_id", "plugin_name", "description", 
                           "file_id", "file_name", "file_size", "photo_id", "category",
                           "status", "tags", "state", "admin_message_id", "created_at",
                           "username", "display_name"]
                    submissions.append(dict(zip(keys, row)))
                
                return submissions
        except Exception as e:
            print(f"Error getting pending submissions: {e}")
            return []
    
    # ========== UPDATE METHODS ==========
    
    def create_update_request(self, update_data: Dict[str, Any]) -> Optional[int]:
        """Создание заявки на обновление"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO updates 
                    (plugin_id, user_id, file_id, file_name, description) 
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    update_data["plugin_id"],
                    update_data["user_id"],
                    update_data["file_id"],
                    update_data["file_name"],
                    update_data.get("description", "")
                ))
                conn.commit()
                return cursor.lastrowid
        except Exception as e:
            print(f"Error creating update request: {e}")
            return None
    
    def get_update_request(self, update_id: int) -> Optional[Dict[str, Any]]:
        """Получение заявки на обновление"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT u.*, p.name as plugin_name, us.username, us.display_name 
                    FROM updates u 
                    JOIN plugins p ON u.plugin_id = p.plugin_id 
                    JOIN users us ON u.user_id = us.user_id 
                    WHERE u.update_id = ?
                """, (update_id,))
                row = cursor.fetchone()
                if row:
                    keys = ["update_id", "plugin_id", "user_id", "file_id", 
                           "file_name", "description", "state", "admin_message_id", 
                           "created_at", "plugin_name", "username", "display_name"]
                    return dict(zip(keys, row))
                return None
        except Exception as e:
            print(f"Error getting update request: {e}")
            return None
    
    def get_pending_updates(self) -> List[Dict[str, Any]]:
        """Получение списка ожидающих обновлений"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT u.*, p.name as plugin_name, us.username, us.display_name 
                    FROM updates u 
                    JOIN plugins p ON u.plugin_id = p.plugin_id 
                    JOIN users us ON u.user_id = us.user_id 
                    WHERE u.state = 'pending' 
                    ORDER BY u.created_at ASC
                """)
                
                rows = cursor.fetchall()
                updates = []
                for row in rows:
                    keys = ["update_id", "plugin_id", "user_id", "file_id", 
                           "file_name", "description", "state", "admin_message_id", 
                           "created_at", "plugin_name", "username", "display_name"]
                    updates.append(dict(zip(keys, row)))
                
                return updates
        except Exception as e:
            print(f"Error getting pending updates: {e}")
            return []
    
    def update_update_request(self, update_id: int, **kwargs) -> bool:
        """Обновление заявки на обновление"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                fields = []
                values = []
                
                for key, value in kwargs.items():
                    if key in ["state", "admin_message_id"]:
                        fields.append(f"{key} = ?")
                        values.append(value)
                
                if fields:
                    values.append(update_id)
                    query = f"UPDATE updates SET {', '.join(fields)} WHERE update_id = ?"
                    cursor.execute(query, values)
                    conn.commit()
                    return cursor.rowcount > 0
                return False
        except Exception as e:
            print(f"Error updating update request: {e}")
            return False
