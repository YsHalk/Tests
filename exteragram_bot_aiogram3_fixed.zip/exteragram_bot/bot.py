#!/usr/bin/env python3
"""
Exteragram Plugin Library Bot - aiogram 3.x

Главный скрипт бота, объединяющий все модули.
Для запуска: python bot.py

Требования:
- aiogram==3.3.0
- python-dotenv
- aiofiles
"""

import asyncio
import logging
import os
import sys
from typing import List, Dict, Any

from aiogram import Bot, Dispatcher, types, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand
from aiogram.utils.keyboard import InlineKeyboardBuilder

# Импортируем модули
import buttons
from config import BOT_TOKEN, ADMIN_IDS, MESSAGES, DATABASE_PATH
from database import Database, Plugin
import user_functions
import admin_functions

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Инициализация
storage = MemoryStorage()
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=storage)

# Инициализация БД
db = Database(DATABASE_PATH)

# Подключаем роутеры
dp.include_router(user_functions.router)
dp.include_router(admin_functions.router)

# ========== ОСНОВНЫЕ ОБРАБОТЧИКИ ==========

@dp.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    await state.clear()
    
    user = db.get_user(message.from_user.id)
    if not user:
        await state.set_state(user_functions.RegistrationStates.waiting_display_name)
        await message.answer(MESSAGES["registration_required"], reply_markup=user_functions.create_cancel_menu())
    else:
        await message.answer(MESSAGES["start"], reply_markup=user_functions.create_main_menu())

@dp.message(Command("report"))
async def cmd_report(message: types.Message):
    text = message.text[7:].strip() if len(message.text) > 7 else ""
    if text:
        await message.answer("✅ Ваш отчет об ошибке отправлен разработчикам. Спасибо!")
    else:
        await message.answer("⚠️ Используйте: /report <текст ошибки>")

@dp.message(Command("admin"))
async def cmd_admin(message: types.Message):
    if message.from_user.id in ADMIN_IDS:
        keyboard = admin_functions.create_admin_menu()
        await message.answer("⚖️ Админская панель:", reply_markup=keyboard)
    else:
        await message.answer(MESSAGES["access_denied"])

# ========== ЗАГРУЗКА ПЛАГИНА ==========

@dp.message(F.document, StateFilter(user_functions.UploadStates.waiting_file))
async def process_upload_file(message: types.Message, state: FSMContext):
    file_info = message.document
    
    if file_info.file_size > 50 * 1024 * 1024:
        await message.answer("⚠️ Файл слишком большой. Максимальный размер - 50MB.")
        return
    
    await state.update_data(
        file_id=file_info.file_id,
        file_name=file_info.file_name,
        file_size=file_info.file_size
    )
    
    await state.set_state(user_functions.UploadStates.waiting_name_and_photo)
    await message.answer(MESSAGES["upload_step2"])

@dp.message(StateFilter(user_functions.UploadStates.waiting_name_and_photo))
async def process_upload_name_and_photo(message: types.Message, state: FSMContext):
    if message.text:
        name = message.text.strip()
        if len(name) < 2 or len(name) > 100:
            await message.answer("⚠️ Название должно быть от 2 до 100 символов.")
            return
        
        await state.update_data(name=name)
    
    if message.photo:
        photo_id = message.photo[-1].file_id
        await state.update_data(photo_id=photo_id)
    
    data = await state.get_data()
    if "name" in data:
        await state.set_state(user_functions.UploadStates.waiting_category)
        keyboard = user_functions.create_categories_menu(is_for_upload=True)
        await message.answer(MESSAGES["upload_step3"], reply_markup=keyboard)
    else:
        await message.answer("✏️ Отправьте название плагина:")

@dp.callback_query(F.data.startswith("upload_category_"))
async def process_upload_category(callback_query: types.CallbackQuery, state: FSMContext):
    category = callback_query.data.replace("upload_category_", "")
    await state.update_data(category=category)
    await state.set_state(user_functions.UploadStates.waiting_status)
    
    keyboard = user_functions.create_statuses_menu()
    await callback_query.message.answer(MESSAGES["upload_step4"], reply_markup=keyboard)
    await callback_query.answer()

@dp.callback_query(F.data.startswith("status_"))
async def process_upload_status(callback_query: types.CallbackQuery, state: FSMContext):
    status = callback_query.data.replace("status_", "")
    await state.update_data(status=status)
    await state.set_state(user_functions.UploadStates.waiting_tags)
    
    await callback_query.message.answer(MESSAGES["upload_step5"])
    await callback_query.answer()

@dp.message(StateFilter(user_functions.UploadStates.waiting_tags))
async def process_upload_tags(message: types.Message, state: FSMContext):
    tags = message.text.strip().lower()
    await state.update_data(tags=tags)
    
    data = await state.get_data()
    
    update_plugin_id = data.get("update_plugin_id")
    if update_plugin_id:
        # Это обновление существующего плагина
        update_data = {
            "plugin_id": update_plugin_id,
            "user_id": message.from_user.id,
            "file_id": data["file_id"],
            "file_name": data["file_name"],
            "description": data.get("description", "")
        }
        
        update_id = db.create_update_request(update_data)
        if update_id:
            update_data["update_id"] = update_id
            update_data["plugin_name"] = db.get_plugin(update_plugin_id).name
            update_data["username"] = message.from_user.username or str(message.from_user.id)
            update_data["display_name"] = message.from_user.full_name
            
            await admin_functions.notify_admins_about_update(update_data)
            
            await message.answer("✅ Заявка на обновление отправлена на модерацию!", reply_markup=user_functions.create_main_menu())
        else:
            await message.answer("⚠️ Произошла ошибка при создании заявки.")
    else:
        # Это новый плагин
        submission_data = {
            "user_id": message.from_user.id,
            "plugin_name": data["name"],
            "description": data["description"],
            "file_id": data["file_id"],
            "file_name": data["file_name"],
            "file_size": data["file_size"],
            "photo_id": data.get("photo_id"),
            "category": data["category"],
            "status": data["status"],
            "tags": tags
        }
        
        submission_id = db.create_submission(submission_data)
        if submission_id:
            submission_data["submission_id"] = submission_id
            submission_data["username"] = message.from_user.username or str(message.from_user.id)
            submission_data["display_name"] = message.from_user.full_name
            
            await admin_functions.notify_admins_about_submission(submission_data)
            
            await message.answer(MESSAGES["upload_complete"], reply_markup=user_functions.create_main_menu())
        else:
            await message.answer("⚠️ Произошла ошибка при создании заявки.")
    
    await state.clear()

# ========== ОБРАБОТЧИКИ CALLBACK ==========

@dp.callback_query(F.data.startswith("download_"))
async def download_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("download_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    db.increment_downloads(plugin_id)
    
    try:
        await callback_query.bot.send_document(
            chat_id=callback_query.from_user.id,
            document=plugin.file_id,
            caption=f"📥 {plugin.name}\n\nСпасибо за скачивание!"
        )
        await callback_query.answer(MESSAGES["download_ready"])
    except Exception as e:
        await callback_query.answer("⚠️ Ошибка при отправке файла.", show_alert=True)

# ========== АДМИНСКИЕ CALLBACK'И ==========

@dp.callback_query(F.data == "admin_submissions")
async def admin_submissions(callback_query: types.CallbackQuery):
    if not admin_functions.is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    submissions = db.get_pending_submissions()
    if not submissions:
        await callback_query.message.answer("📋 Нет ожидающих заявок.")
        await callback_query.answer()
        return
    
    text = f"📋 <b>Ожидающие заявки:</b> {len(submissions)}\n\n"
    
    keyboard_buttons = []
    for sub in submissions:
        keyboard_buttons.append([InlineKeyboardButton(
            text=f"#{sub['submission_id']} - {sub['plugin_name']} (от @{sub['username']})",
            callback_data=f"view_sub_{sub['submission_id']}"
        )])
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()

@dp.callback_query(F.data.startswith("view_sub_"))
async def view_submission(callback_query: types.CallbackQuery):
    if not admin_functions.is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    submission_id = int(callback_query.data.replace("view_sub_", ""))
    submission = db.get_submission(submission_id)
    
    if not submission:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return
    
    text = f"""📋 <b>Заявка #{submission_id}</b>

<b>От:</b> @{submission['username']} ({submission['display_name']})
<b>Плагин:</b> {submission['plugin_name']}
<b>Категория:</b> {buttons.CATEGORIES.get(submission['category'], submission['category'])}
<b>Статус:</b> {buttons.DEV_STATUSES.get(submission['status'], submission['status'])}

<b>Описание:</b>
{submission['description']}

<b>Теги:</b> {submission.get('tags', 'Нет тегов')}

<b>Файл:</b> {submission['file_name']} ({submission['file_size']} bytes)"""
    
    keyboard = admin_functions.create_submission_review_menu(submission_id)
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()

@dp.callback_query(F.data == "admin_updates")
async def admin_updates(callback_query: types.CallbackQuery):
    if not admin_functions.is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    updates = db.get_pending_updates()
    if not updates:
        await callback_query.message.answer("🔄 Нет ожидающих обновлений.")
        await callback_query.answer()
        return
    
    text = f"🔄 <b>Ожидающие обновления:</b> {len(updates)}\n\n"
    
    keyboard_buttons = []
    for upd in updates:
        keyboard_buttons.append([InlineKeyboardButton(
            text=f"#{upd['update_id']} - {upd['plugin_name']} (от @{upd['username']})",
            callback_data=f"view_upd_{upd['update_id']}"
        )])
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()

@dp.callback_query(F.data.startswith("view_upd_"))
async def view_update(callback_query: types.CallbackQuery):
    if not admin_functions.is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    update_id = int(callback_query.data.replace("view_upd_", ""))
    update_req = db.get_update_request(update_id)
    
    if not update_req:
        await callback_query.answer("Обновление не найдено", show_alert=True)
        return
    
    text = f"""🔄 <b>Обновление #{update_id}</b>

<b>Плагин:</b> {update_req['plugin_name']}
<b>От:</b> @{update_req['username']} ({update_req['display_name']})

<b>Описание обновления:</b>
{update_req.get('description', 'Без описания')}

<b>Файл:</b> {update_req['file_name']}"""
    
    keyboard = admin_functions.create_update_review_menu(update_id)
    await callback_query.message.answer(text, reply_markup=keyboard)
    await callback_query.answer()

# ========== ЗАПУСК ==========

async def on_startup():
    logger.info("Bot starting...")
    
    commands = [
        BotCommand(command="start", description="Запустить бота"),
        BotCommand(command="report", description="Сообщить об ошибке"),
    ]
    
    if ADMIN_IDS:
        commands.append(BotCommand(command="admin", description="Админская панель"))
    
    await bot.set_my_commands(commands)
    
    try:
        test_user = db.get_user(1)
        logger.info("Database connected successfully")
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        sys.exit(1)
    
    logger.info("Bot started successfully")

async def on_shutdown():
    logger.info("Bot shutting down...")
    await bot.session.close()
    await dp.storage.close()
    logger.info("Bot stopped")

async def main():
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)
    
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)
