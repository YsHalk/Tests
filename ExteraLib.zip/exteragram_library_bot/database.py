import sqlite3
import aiosqlite
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any

from config import DB_PATH, DATA_DIR


class Database:
    def __init__(self):
        self.db_path = DB_PATH
        self._ensure_db_exists()

    def _ensure_db_exists(self):
        """Создает БД если не существует"""
        if not DB_PATH.exists():
            DATA_DIR.mkdir(parents=True, exist_ok=True)

    async def initialize(self):
        """Инициализирует все таблицы"""
        async with aiosqlite.connect(self.db_path) as db:
            # Таблица пользователей
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    display_name TEXT NOT NULL,
                    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Таблица плагинов
            await db.execute("""
                CREATE TABLE IF NOT EXISTS plugins (
                    plugin_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    file_id TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    name TEXT NOT NULL,
                    description TEXT NOT NULL,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL,
                    tags TEXT,
                    photo_file_id TEXT,
                    downloads INTEGER DEFAULT 0,
                    views INTEGER DEFAULT 0,
                    rating REAL DEFAULT 0,
                    rating_count INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    approved BOOLEAN DEFAULT FALSE,
                    archived BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)

            # Таблица подписок
            await db.execute("""
                CREATE TABLE IF NOT EXISTS subscriptions (
                    subscription_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    target_user_id INTEGER,
                    plugin_id INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (target_user_id) REFERENCES users (user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id),
                    UNIQUE(user_id, target_user_id, plugin_id) ON CONFLICT IGNORE
                )
            """)

            # Таблица оценок
            await db.execute("""
                CREATE TABLE IF NOT EXISTS ratings (
                    rating_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    plugin_id INTEGER NOT NULL,
                    rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id),
                    UNIQUE(user_id, plugin_id) ON CONFLICT REPLACE
                )
            """)

            # Таблица заявок на добавление плагинов
            await db.execute("""
                CREATE TABLE IF NOT EXISTS plugin_requests (
                    request_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    plugin_id INTEGER,
                    status TEXT DEFAULT 'pending',  -- pending, approved, rejected, changes_requested
                    admin_message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    reviewed_at TIMESTAMP,
                    reviewed_by INTEGER,
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id),
                    FOREIGN KEY (reviewed_by) REFERENCES users (user_id)
                )
            """)

            # Таблица уведомлений администраторам
            await db.execute("""
                CREATE TABLE IF NOT EXISTS admin_notifications (
                    notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plugin_id INTEGER NOT NULL,
                    notification_type TEXT NOT NULL,  -- update, delete, report
                    message TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    processed BOOLEAN DEFAULT FALSE,
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id)
                )
            """)

            await db.commit()

    # User methods
    async def add_user(self, user_id: int, username: str, display_name: str):
        """Добавляет пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT OR IGNORE INTO users (user_id, username, display_name) VALUES (?, ?, ?)",
                (user_id, username, display_name)
            )
            await db.commit()

    async def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Получает пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute(
                "SELECT * FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    return dict(zip([d[0] for d in cursor.description], row))
                return None

    async def update_user(self, user_id: int, **kwargs):
        """Обновляет данные пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            set_clause = ", ".join([f"{k} = ?" for k in kwargs.keys()])
            values = list(kwargs.values()) + [user_id]
            await db.execute(f"UPDATE users SET {set_clause} WHERE user_id = ?", values)
            await db.commit()

    # Plugin methods
    async def add_plugin(self, user_id: int, file_id: str, file_name: str, name: str,
                        description: str, category: str, status: str, tags: str = None,
                        photo_file_id: str = None) -> int:
        """Добавляет плагин, возвращает ID"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """INSERT INTO plugins 
                (user_id, file_id, file_name, name, description, category, status, tags, photo_file_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (user_id, file_id, file_name, name, description, category, status, tags, photo_file_id)
            )
            await db.commit()
            return cursor.lastrowid

    async def get_plugin(self, plugin_id: int) -> Optional[Dict[str, Any]]:
        """Получает плагин с данными автора"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT p.*, u.username, u.display_name
                FROM plugins p
                JOIN users u ON p.user_id = u.user_id
                WHERE p.plugin_id = ?
            """, (plugin_id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    return dict(zip([d[0] for d in cursor.description], row))
                return None

    async def update_plugin(self, plugin_id: int, **kwargs):
        """Обновляет плагин"""
        async with aiosqlite.connect(self.db_path) as db:
            set_clause = ", ".join([f"{k} = ?" for k in kwargs.keys()])
            values = list(kwargs.values()) + [plugin_id]
            await db.execute(f"UPDATE plugins SET {set_clause} WHERE plugin_id = ?", values)
            await db.commit()

    async def get_user_plugins(self, user_id: int, include_archived: bool = False) -> List[Dict[str, Any]]:
        """Получает плагины пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            query = "SELECT * FROM plugins WHERE user_id = ?"
            if not include_archived:
                query += " AND archived = FALSE"
            query += " ORDER BY created_at DESC"
            
            async with db.execute(query, (user_id,)) as cursor:
                rows = await cursor.fetchall()
                return [dict(zip([d[0] for d in cursor.description], row)) for row in rows]

    async def get_plugins_by_category(self, category: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Получает плагины по категории"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT p.*, u.username, u.display_name
                FROM plugins p
                JOIN users u ON p.user_id = u.user_id
                WHERE p.approved = TRUE AND p.archived = FALSE AND p.category = ?
                ORDER BY p.downloads DESC, p.rating DESC
                LIMIT ?
            """, (category, limit)) as cursor:
                rows = await cursor.fetchall()
                return [dict(zip([d[0] for d in cursor.description], row)) for row in rows]

    # Search methods
    async def search_plugins(self, query: str, category: str = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Поиск плагинов по названию, описанию, тегам, автору"""
        async with aiosqlite.connect(self.db_path) as db:
            # Используем FTS или простой LIKE для SQLite
            sql_query = """
                SELECT p.*, u.username, u.display_name,
                       (
                           (p.name LIKE ?) * 10 +
                           (p.description LIKE ?) * 5 +
                           (p.tags LIKE ?) * 3 +
                           (u.display_name LIKE ?) * 2 +
                           (u.username LIKE ?) * 2
                       ) as relevance
                FROM plugins p
                JOIN users u ON p.user_id = u.user_id
                WHERE p.approved = TRUE AND p.archived = FALSE
                AND (
                    p.name LIKE ? OR 
                    p.description LIKE ? OR 
                    p.tags LIKE ? OR
                    u.display_name LIKE ? OR
                    u.username LIKE ?
                )
            """
            
            params = [f'%{query}%'] * 9
            
            if category:
                sql_query += " AND p.category = ?"
                params.append(category)
                
            sql_query += " ORDER BY relevance DESC, p.rating DESC, p.downloads DESC LIMIT ?"
            params.append(limit)
            
            async with db.execute(sql_query, params) as cursor:
                rows = await cursor.fetchall()
                return [dict(zip([d[0] for d in cursor.description], row)) for row in rows]

    async def get_popular_plugins(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Получает популярные плагины"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT p.*, u.username, u.display_name
                FROM plugins p
                JOIN users u ON p.user_id = u.user_id
                WHERE p.approved = TRUE AND p.archived = FALSE
                ORDER BY p.downloads DESC, p.rating DESC
                LIMIT ?
            """, (limit,)) as cursor:
                rows = await cursor.fetchall()
                return [dict(zip([d[0] for d in cursor.description], row)) for row in rows]

    # Subscription methods
    async def add_subscription(self, user_id: int, target_user_id: int = None, plugin_id: int = None):
        """Добавляет подписку"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT OR IGNORE INTO subscriptions (user_id, target_user_id, plugin_id) VALUES (?, ?, ?)",
                (user_id, target_user_id, plugin_id)
            )
            await db.commit()

    async def remove_subscription(self, user_id: int, target_user_id: int = None, plugin_id: int = None):
        """Удаляет подписку"""
        async with aiosqlite.connect(self.db_path) as db:
            query = "DELETE FROM subscriptions WHERE user_id = ?"
            params = [user_id]
            
            if target_user_id:
                query += " AND target_user_id = ?"
                params.append(target_user_id)
            elif plugin_id:
                query += " AND plugin_id = ?"
                params.append(plugin_id)
                
            await db.execute(query, params)
            await db.commit()

    async def is_subscribed(self, user_id: int, target_user_id: int = None, plugin_id: int = None) -> bool:
        """Проверяет подписку"""
        async with aiosqlite.connect(self.db_path) as db:
            query = "SELECT 1 FROM subscriptions WHERE user_id = ?"
            params = [user_id]
            
            if target_user_id:
                query += " AND target_user_id = ?"
                params.append(target_user_id)
            elif plugin_id:
                query += " AND plugin_id = ?"
                params.append(plugin_id)
                
            async with db.execute(query, params) as cursor:
                return await cursor.fetchone() is not None

    async def get_subscribers(self, target_user_id: int = None, plugin_id: int = None) -> List[int]:
        """Получает подписчиков"""
        async with aiosqlite.connect(self.db_path) as db:
            query = "SELECT user_id FROM subscriptions WHERE"
            params = []
            
            if target_user_id:
                query += " target_user_id = ?"
                params.append(target_user_id)
            elif plugin_id:
                query += " plugin_id = ?"
                params.append(plugin_id)
                
            async with db.execute(query, params) as cursor:
                rows = await cursor.fetchall()
                return [row[0] for row in rows]

    async def get_user_subscriptions_on_authors(self, user_id: int) -> List[Dict[str, Any]]:
        """Получает подписки пользователя на авторов"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT u.user_id, u.username, u.display_name
                FROM subscriptions s
                JOIN users u ON s.target_user_id = u.user_id
                WHERE s.user_id = ? AND s.target_user_id IS NOT NULL
                ORDER BY s.created_at DESC
            """, (user_id,)) as cursor:
                rows = await cursor.fetchall()
                return [dict(zip([d[0] for d in cursor.description], row)) for row in rows]

    async def get_user_subscriptions_on_plugins(self, user_id: int) -> List[Dict[str, Any]]:
        """Получает подписки пользователя на плагины"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT p.plugin_id, p.name
                FROM subscriptions s
                JOIN plugins p ON s.plugin_id = p.plugin_id
                WHERE s.user_id = ? AND s.plugin_id IS NOT NULL
                ORDER BY s.created_at DESC
            """, (user_id,)) as cursor:
                rows = await cursor.fetchall()
                return [dict(zip([d[0] for d in cursor.description], row)) for row in rows]

    # Rating methods
    async def add_rating(self, user_id: int, plugin_id: int, rating: int):
        """Добавляет или обновляет оценку"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "INSERT OR REPLACE INTO ratings (user_id, plugin_id, rating) VALUES (?, ?, ?)",
                (user_id, plugin_id, rating)
            )
            # Обновляем средний рейтинг плагина
            await db.execute("""
                UPDATE plugins 
                SET rating = (SELECT AVG(rating) FROM ratings WHERE plugin_id = ?),
                    rating_count = (SELECT COUNT(*) FROM ratings WHERE plugin_id = ?)
                WHERE plugin_id = ?
            """, (plugin_id, plugin_id, plugin_id))
            await db.commit()

    # Plugin request methods
    async def add_plugin_request(self, user_id: int, plugin_id: int) -> int:
        """Добавляет заявку на плагин"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "INSERT INTO plugin_requests (user_id, plugin_id) VALUES (?, ?)",
                (user_id, plugin_id)
            )
            await db.commit()
            return cursor.lastrowid

    async def get_plugin_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        """Получает заявку"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("""
                SELECT pr.*, p.name as plugin_name, u.display_name as user_name
                FROM plugin_requests pr
                JOIN plugins p ON pr.plugin_id = p.plugin_id
                JOIN users u ON pr.user_id = u.user_id
                WHERE pr.request_id = ?
            """, (request_id,)) as cursor:
                row = await cursor.fetchone()
                if row:
                    return dict(zip([d[0] for d in cursor.description], row))
                return None

    async def update_plugin_request(self, request_id: int, status: str, admin_message: str = None, reviewed_by: int = None):
        """Обновляет статус заявки"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                UPDATE plugin_requests 
                SET status = ?, admin_message = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
                WHERE request_id = ?
            """, (status, admin_message, reviewed_by, request_id))
            await db.commit()

    # Stats methods
    async def get_user_stats(self, user_id: int) -> Dict[str, Any]:
        """Получает статистику пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            # Статистика плагинов
            async with db.execute("""
                SELECT 
                    COUNT(*) as plugin_count,
                    SUM(downloads) as total_downloads,
                    SUM(views) as total_views,
                    AVG(rating) as avg_rating
                FROM plugins 
                WHERE user_id = ? AND approved = TRUE
            """, (user_id,)) as cursor:
                plugin_stats = await cursor.fetchone()
                
            # Количество подписчиков
            async with db.execute("""
                SELECT COUNT(*) as subscriber_count
                FROM subscriptions 
                WHERE target_user_id = ?
            """, (user_id,)) as cursor:
                subscriber_count = await cursor.fetchone()
                
            return {
                'plugin_count': plugin_stats[0] or 0,
                'total_downloads': plugin_stats[1] or 0,
                'total_views': plugin_stats[2] or 0,
                'avg_rating': plugin_stats[3] or 0,
                'subscriber_count': subscriber_count[0] or 0
            }

    async def increment_downloads(self, plugin_id: int):
        """Увеличивает счетчик скачиваний"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE plugins SET downloads = downloads + 1 WHERE plugin_id = ?",
                (plugin_id,)
            )
            await db.commit()

    async def increment_views(self, plugin_id: int):
        """Увеличивает счетчик просмотров"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE plugins SET views = views + 1 WHERE plugin_id = ?",
                (plugin_id,)
            )
            await db.commit()