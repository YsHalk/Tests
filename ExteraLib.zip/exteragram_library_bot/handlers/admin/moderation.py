from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from config import ADMIN_GROUP_ID, TOPIC_REQUESTS, TOPIC_SECURITY, TOPIC_NOTIFICATIONS, ADMINS
from database import Database
from states import AdminStates
import keyboards as kb

router = Router()
db = Database()


# ===== ОБРАБОТЧИКИ МОДЕРАЦИИ В АДМИН ГРУППЕ =====

@router.callback_query(F.data.startswith("approve_"))
async def moderation_approve(callback: CallbackQuery):
    """Одобрение плагина"""
    request_id = int(callback.data.replace("approve_", ""))
    admin_id = callback.from_user.id
    
    request = await db.get_plugin_request(request_id)
    if not request:
        await callback.answer("Заявка не найдена.", show_alert=True)
        return
    
    if request['status'] != 'pending':
        await callback.answer("Заявка уже обработана.", show_alert=True)
        return
    
    # Обновляем заявку
    await db.update_plugin_request(request_id, 'approved', reviewed_by=admin_id)
    
    # Одобряем плагин
    await db.update_plugin(request['plugin_id'], approved=True)
    
    plugin = await db.get_plugin(request['plugin_id'])
    
    # Уведомляем пользователя
    try:
        await callback.bot.send_message(
            request['user_id'],
            f"✅ <b>Ваш плагин одобрен!</b>\n\n"
            f"📦 <b>{plugin['name']}</b>\n\n"
            f"Плагин доступен в библиотеке.",
            reply_markup=kb.BACK_TO_MENU_KB
        )
    except Exception:
        pass
    
    # Обновляем сообщение в админской группе
    await callback.message.edit_text(
        f"✅ <b>ОДОБРЕНО</b>\n\n"
        f"📦 {plugin['name']}\n"
        f"👤 Автор: {request['user_name']}\n"
        f"✅ Одобрил: {callback.from_user.full_name}",
        reply_markup=None
    )
    
    await callback.answer("Плагин одобрен!")


@router.callback_query(F.data.startswith("reject_"))
async def moderation_reject(callback: CallbackQuery):
    """Отклонение плагина"""
    request_id = int(callback.data.replace("reject_", ""))
    admin_id = callback.from_user.id
    
    request = await db.get_plugin_request(request_id)
    if not request:
        await callback.answer("Заявка не найдена.", show_alert=True)
        return
    
    if request['status'] != 'pending':
        await callback.answer("Заявка уже обработана.", show_alert=True)
        return
    
    # Обновляем заявку
    await db.update_plugin_request(request_id, 'rejected', reviewed_by=admin_id)
    
    plugin = await db.get_plugin(request['plugin_id'])
    
    # Уведомляем пользователя
    try:
        await callback.bot.send_message(
            request['user_id'],
            f"❌ <b>Ваш плагин отклонен</b>\n\n"
            f"📦 <b>{plugin['name']}</b>\n\n"
            f"К сожалению, ваш плагин не прошел модерацию.\n"
            f"Для уточнений причин обратитесь в поддержку.",
            reply_markup=kb.BACK_TO_MENU_KB
        )
    except Exception:
        pass
    
    # Обновляем сообщение в админской группе
    await callback.message.edit_text(
        f"❌ <b>ОТКЛОНЕНО</b>\n\n"
        f"📦 {plugin['name']}\n"
        f"👤 Автор: {request['user_name']}\n"
        f"❌ Отклонил: {callback.from_user.full_name}",
        reply_markup=None
    )
    
    await callback.answer("Плагин отклонен!")


@router.callback_query(F.data.startswith("modify_"))
async def moderation_modify(callback: CallbackQuery, state: FSMContext):
    """Запрос на изменение плагина"""
    request_id = int(callback.data.replace("modify_", ""))
    
    request = await db.get_plugin_request(request_id)
    if not request:
        await callback.answer("Заявка не найдена.", show_alert=True)
        return
    
    # Сохраняем ID заявки в состоянии
    await state.set_state(AdminStates.waiting_changes)
    await state.update_data(request_id=request_id)
    
    await callback.message.answer(
        f"✏️ <b>Запрос на изменение</b>\n\n"
        f"📦 Плагин: {request['plugin_name']}\n"
        f"👤 Автор: {request['user_name']}\n\n"
        f"Отправьте сообщение с необходимыми изменениями:",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    await callback.answer()


@router.callback_query(F.data.startswith("accept_changes_"))
async def moderation_accept_changes(callback: CallbackQuery):
    """Пользователь принял изменения"""
    request_id = int(callback.data.replace("accept_changes_", ""))
    
    request = await db.get_plugin_request(request_id)
    if not request:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    # Автоматически одобряем
    await db.update_plugin_request(request_id, 'approved')
    await db.update_plugin(request['plugin_id'], approved=True)
    
    plugin = await db.get_plugin(request['plugin_id'])
    
    # Уведомляем пользователя
    await callback.message.edit_text(
        f"✅ <b>Изменения приняты!</b>\n\n"
        f"📦 <b>{plugin['name']}</b>\n\n"
        f"Плагин опубликован в библиотеке.",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    
    # Уведомляем админов
    try:
        await callback.bot.send_message(
            ADMIN_GROUP_ID,
            f"✅ Плагин одобрен автоматически\n\n"
            f"📦 {plugin['name']}\n"
            f"👤 {plugin['display_name']}\n\n"
            f"Пользователь принял изменения.",
            message_thread_id=TOPIC_NOTIFICATIONS
        )
    except Exception:
        pass
    
    await callback.answer()


@router.callback_query(F.data.startswith("decline_changes_"))
async def moderation_decline_changes(callback: CallbackQuery):
    """Пользователь отклонил изменения"""
    request_id = int(callback.data.replace("decline_changes_", ""))
    
    request = await db.get_plugin_request(request_id)
    if not request:
        await callback.answer("Ошибка.", show_alert=True)
        return
    
    # Уведомляем админов
    plugin = await db.get_plugin(request['plugin_id'])
    
    try:
        await callback.bot.send_message(
            ADMIN_GROUP_ID,
            f"❌ Пользователь отклонил изменения\n\n"
            f"📦 {plugin['name']}\n"
            f"👤 {plugin['display_name']}\n\n"
            f"Требуется ручная модерация.",
            message_thread_id=TOPIC_NOTIFICATIONS
        )
    except Exception:
        pass
    
    await callback.message.edit_text(
        "❌ Вы отклонили изменения.\n\n"
        "Администраторы рассмотрят вашу заявку.\n"
        "Для связи с поддержкой нажмите кнопку ниже.",
        reply_markup=kb.BACK_TO_MENU_KB
    )
    
    await callback.answer()


# ===== УВЕДОМЛЕНИЯ АДМИНИСТРАТОРАМ =====

async def notify_admin_plugin_update(bot, plugin_id: int, author_id: int, update_description: str):
    """Уведомление об обновлении плагина"""
    plugin = await db.get_plugin(plugin_id)
    author = await db.get_user(author_id)
    
    try:
        await bot.send_message(
            ADMIN_GROUP_ID,
            f"🔄 <b>Плагин обновлен</b>\n\n"
            f"📦 <b>{plugin['name']}</b>\n"
            f"👤 Автор: {author['display_name']}\n\n"
            f"📝 Описание обновления:\n{update_description}\n\n"
            f"Подписчики уже получили уведомления.",
            message_thread_id=TOPIC_NOTIFICATIONS
        )
    except Exception as e:
        print(f"Failed to notify admins: {e}")


async def notify_admin_plugin_delete(bot, plugin_id: int, reason: str):
    """Уведомление об удалении плагина"""
    plugin = await db.get_plugin(plugin_id)
    
    try:
        await bot.send_message(
            ADMIN_GROUP_ID,
            f"🗑️ <b>Плагин удален</b>\n\n"
            f"📦 <b>{plugin['name']}</b>\n"
            f"👤 Автор: {plugin['display_name']}\n\n"
            f"📋 Причина: {reason}",
            message_thread_id=TOPIC_NOTIFICATIONS
        )
    except Exception as e:
        print(f"Failed to notify admins: {e}")


async def notify_admin_report(bot, plugin_id: int, reporter_id: int, reason: str):
    """Уведомление о жалобе на плагин"""
    plugin = await db.get_plugin(plugin_id)
    reporter = await db.get_user(reporter_id)
    
    try:
        await bot.send_message(
            ADMIN_GROUP_ID,
            f"⚠️ <b>Жалоба на плагин</b>\n\n"
            f"📦 <b>{plugin['name']}</b>\n"
            f"👤 Автор: {plugin['display_name']}\n"
            f"🚨 Жалоба от: {reporter['display_name']}\n\n"
            f"📋 Причина: {reason}\n\n"
            f"Требуется проверка.",
            message_thread_id=TOPIC_NOTIFICATIONS
        )
    except Exception as e:
        print(f"Failed to notify admins: {e}")