from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from config import ADMIN_GROUP_ID, TOPIC_REQUESTS, TOPIC_SECURITY, CATEGORIES
from database import Database
from states import UploadStates
import keyboards as kb

router = Router()
db = Database()


# ===== ПРОДОЛЖЕНИЕ ЗАГРУЗКИ =====

@router.callback_query(F.data == "upload_continue")
async def upload_continue(callback: CallbackQuery, state: FSMContext):
    """Продолжение загрузки после получения файла"""
    data = await state.get_data()
    step = data.get('upload_step', 2)
    
    if step == 2:
        # Переходим к вводу названия
        await state.set_state(UploadStates.waiting_name)
        await callback.message.edit_text(
            "[2/5] Отправьте <b>название плагина</b> и, при желании, прикрепите <b>фото для обложки</b>.",
            reply_markup=None
        )
    
    await callback.answer()


@router.callback_query(F.data == "upload_replace_file")
async def upload_replace_file(callback: CallbackQuery, state: FSMContext):
    """Замена файла"""
    await state.set_state(UploadStates.waiting_file)
    await callback.message.edit_text(
        "📎 Отправьте новый файл плагина:",
        reply_markup=None
    )
    await callback.answer()


# ===== ПОЛУЧЕНИЕ НАЗВАНИЯ И ОБЛОЖКИ =====

@router.message(UploadStates.waiting_name)
async def upload_receive_name(message: Message, state: FSMContext):
    """Получение названия и обложки"""
    name = message.text.strip()
    
    if len(name) < 3 or len(name) > 100:
        await message.answer("Название должно быть от 3 до 100 символов.")
        return
    
    # Сохраняем название
    await state.update_data(name=name, upload_step=3)
    
    # Сохраняем file_id обложки если есть
    if message.photo:
        photo_file_id = message.photo[-1].file_id
        await state.update_data(photo_file_id=photo_file_id)
    elif message.document and message.document.mime_type.startswith('image/'):
        photo_file_id = message.document.file_id
        await state.update_data(photo_file_id=photo_file_id)
    
    # Переходим к выбору категории
    await state.set_state(UploadStates.waiting_category)
    await message.answer(
        "[3/5] Отлично! Теперь выберите категорию:",
        reply_markup=kb.get_categories_keyboard()
    )


# ===== ВЫБОР КАТЕГОРИИ =====

@router.callback_query(F.data.startswith("category_"), UploadStates.waiting_category)
async def upload_select_category(callback: CallbackQuery, state: FSMContext):
    """Выбор категории"""
    category = callback.data.replace("category_", "")
    
    # Сохраняем категорию
    await state.update_data(category=category, upload_step=4)
    
    # Переходим к выбору статуса
    await state.set_state(UploadStates.waiting_status)
    await callback.message.edit_text(
        "[4/5] Укажите статус разработки:",
        reply_markup=kb.get_statuses_keyboard()
    )
    await callback.answer()


# ===== ВЫБОР СТАТУСА =====

@router.callback_query(F.data.startswith("status_"), UploadStates.waiting_status)
async def upload_select_status(callback: CallbackQuery, state: FSMContext):
    """Выбор статуса"""
    status = callback.data.replace("status_", "")
    
    # Сохраняем статус
    await state.update_data(status=status, upload_step=5)
    
    # Переходим к вводу тегов
    await state.set_state(UploadStates.waiting_tags)
    await callback.message.edit_text(
        "[5/5] Введите теги через пробел:\n\n"
        "Каждое слово - отдельный тег. Не злоупотребляйте количеством.",
        reply_markup=None
    )
    await callback.answer()


# ===== ПОЛУЧЕНИЕ ТЕГОВ =====

@router.message(UploadStates.waiting_tags)
async def upload_receive_tags(message: Message, state: FSMContext):
    """Получение тегов"""
    tags = message.text.strip()
    
    # Проверяем количество тегов (макс 10)
    tag_list = tags.split()
    if len(tag_list) > 10:
        await message.answer("Слишком много тегов. Максимум 10.")
        return
    
    # Сохраняем теги
    await state.update_data(tags=tags)
    
    # Показываем предпросмотр
    data = await state.get_data()
    
    category_names = dict(kb.CATEGORIES)
    status_names = kb.STATUSES
    
    text = "📋 <b>Проверьте данные:</b>\n\n"
    text += f"📦 <b>Название:</b> {data['name']}\n"
    text += f"📂 <b>Категория:</b> {category_names.get(data['category'], data['category'])}\n"
    text += f"📊 <b>Статус:</b> {status_names.get(data['status'], data['status'])}\n"
    text += f"🏷 <b>Теги:</b> {tags}\n"
    
    if data.get('photo_file_id'):
        text += "🖼 Обложка: Да\n"
    else:
        text += "🖼 Обложка: Нет\n"
    
    text += "\nВсе верно?"
    
    await state.set_state(UploadStates.confirm_data)
    await message.answer(text, reply_markup=kb.get_upload_confirm_keyboard())


# ===== ПОДТВЕРЖДЕНИЕ =====

@router.callback_query(F.data == "upload_confirm", UploadStates.confirm_data)
async def upload_confirm(callback: CallbackQuery, state: FSMContext):
    """подтверждение загрузки"""
    user_id = callback.from_user.id
    data = await state.get_data()
    
    # Создаем плагин в БД
    plugin_id = await db.add_plugin(
        user_id=user_id,
        file_id=data['file_id'],
        file_name=data['file_name'],
        name=data['name'],
        description=f"Плагин {data['name']} от пользователя {user_id}",  # Временное описание
        category=data['category'],
        status=data['status'],
        tags=data.get('tags'),
        photo_file_id=data.get('photo_file_id')
    )
    
    # Создаем заявку на модерацию
    request_id = await db.add_plugin_request(user_id, plugin_id)
    
    # Отправляем файл в тему безопасности
    try:
        await callback.bot.send_document(
            chat_id=ADMIN_GROUP_ID,
            document=data['file_id'],
            caption=f"📎 Файл плагина: {data['file_name']}\n"
                   f"ID: {plugin_id}\n"
                   f"Автор: {callback.from_user.full_name}",
            message_thread_id=TOPIC_SECURITY
        )
    except Exception as e:
        print(f"Failed to send file to security: {e}")
    
    # Отправляем заявку в тему заявок
    try:
        category_names = dict(kb.CATEGORIES)
        status_names = kb.STATUSES
        
        request_text = f"📋 <b>Новая заявка #{request_id}</b>\n\n"
        request_text += f"📦 <b>{data['name']}</b>\n"
        request_text += f"👤 Автор: {callback.from_user.full_name}\n"
        request_text += f"📂 Категория: {category_names.get(data['category'], data['category'])}\n"
        request_text += f"📊 Статус: {status_names.get(data['status'], data['status'])}\n"
        request_text += f"🏷 Теги: {data.get('tags', 'Нет')}\n\n"
        request_text += f"📎 Файл: {data['file_name']}"
        
        keyboard = kb.get_moderation_keyboard(request_id)
        
        await callback.bot.send_message(
            ADMIN_GROUP_ID,
            request_text,
            reply_markup=keyboard,
            message_thread_id=TOPIC_REQUESTS
        )
    except Exception as e:
        print(f"Failed to send request: {e}")
    
    # Очищаем состояние
    await state.clear()
    
    # Уведомляем пользователя
    await callback.message.edit_text(
        f"✅ <b>Заявка отправлена!</b>\n\n"
        f"📦 <b>{data['name']}</b>\n\n"
        f"Ваш плагин отправлен на модерацию.\n"
        f"Ожидайте одобрения.",
        reply_markup=None
    )
    
    await callback.answer()


@router.callback_query(F.data == "upload_edit", UploadStates.confirm_data)
async def upload_edit(callback: CallbackQuery, state: FSMContext):
    """Редактирование данных"""
    # Возвращаем к началу
    await state.set_state(UploadStates.waiting_name)
    await state.update_data(upload_step=2)
    
    await callback.message.edit_text(
        "[2/5] Отправьте <b>название плагина</b> и, при желании, прикрепите <b>фото для обложки</b>.",
        reply_markup=None
    )
    await callback.answer()


@router.callback_query(F.data == "cancel_upload")
async def upload_cancel(callback: CallbackQuery, state: FSMContext):
    """Отмена загрузки"""
    await state.clear()
    await callback.message.edit_text("Загрузка отменена.", reply_markup=None)
    await callback.answer()


@router.callback_query(F.data == "back_upload")
async def upload_back(callback: CallbackQuery, state: FSMContext):
    """Назад при загрузке"""
    current_state = await state.get_state()
    
    if current_state == UploadStates.waiting_status.state:
        await state.set_state(UploadStates.waiting_category)
        await callback.message.edit_text(
            "[3/5] Выберите категорию:",
            reply_markup=kb.get_categories_keyboard()
        )
    
    await callback.answer()