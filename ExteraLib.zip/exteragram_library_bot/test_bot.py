#!/usr/bin/env python3
"""
Тестовый скрипт для проверки бота на ошибки
Проверяет: импорты, клавиатуры, callback'и, структуру
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Проверка импортов"""
    print("🔍 Проверка импортов...")
    
    modules = [
        'config', 'database', 'keyboards', 'states', 'utils',
        'handlers.user.search', 'handlers.user.profile', 
        'handlers.user.upload', 'handlers.user.subscriptions',
        'handlers.admin.moderation'
    ]
    
    all_ok = True
    for module in modules:
        try:
            __import__(module)
            print(f"✅ {module} - OK")
        except Exception as e:
            print(f"❌ {module} - Ошибка: {e}")
            all_ok = False
    
    return all_ok

def test_config():
    """Проверка конфигурации"""
    print("\n🔍 Проверка конфигурации...")
    
    try:
        from config import CATEGORIES, STATUSES, DB_PATH, is_admin
        
        print(f"✅ Категории: {len(CATEGORIES)} шт")
        print(f"✅ Статусы: {len(STATUSES)} шт")
        print(f"✅ Путь к БД: {DB_PATH}")
        print(f"✅ Функция is_admin: {callable(is_admin)}")
        
        # Проверяем что путь существует
        from pathlib import Path
        db_dir = Path(DB_PATH).parent
        print(f"✅ Директория БД: {db_dir}")
        
        return True
    except Exception as e:
        print(f"❌ Config - Ошибка: {e}")
        return False

def test_database():
    """Проверка базы данных"""
    print("\n🔍 Проверка базы данных...")
    
    try:
        from database import Database
        db = Database()
        print("✅ Database инициализирован - OK")
        
        # Проверяем SQL синтаксис
        import sqlite3
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        
        # Проверяем таблицу users
        cursor.execute("""
            CREATE TABLE users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                display_name TEXT NOT NULL,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("✅ SQL таблицы users - OK")
        
        # Проверяем таблицу plugins
        cursor.execute("""
            CREATE TABLE plugins (
                plugin_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                file_id TEXT NOT NULL,
                file_name TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                category TEXT NOT NULL,
                status TEXT NOT NULL,
                tags TEXT,
                photo_file_id TEXT,
                downloads INTEGER DEFAULT 0,
                views INTEGER DEFAULT 0,
                rating REAL DEFAULT 0,
                rating_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                approved BOOLEAN DEFAULT FALSE,
                archived BOOLEAN DEFAULT FALSE,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        """)
        print("✅ SQL таблицы plugins - OK")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Database - Ошибка: {e}")
        return False

def test_keyboards():
    """Проверка клавиатур"""
    print("\n🔍 Проверка клавиатур...")
    
    try:
        import keyboards as kb
        
        # Проверяем главное меню
        menu = kb.get_main_menu()
        print("✅ Главное меню - OK")
        
        # Проверяем категории
        cat_kb = kb.get_categories_keyboard()
        print("✅ Категории - OK")
        
        # Проверяем статусы
        status_kb = kb.get_statuses_keyboard()
        print("✅ Статусы - OK")
        
        # Проверяем страницу плагина
        plugin_kb = kb.get_plugin_page_keyboard(1, 1, 1)
        print("✅ Страница плагина - OK")
        
        # Проверяем управление плагином
        manage_kb = kb.get_manage_plugin_keyboard(1)
        print("✅ Управление плагином - OK")
        
        # Проверяем оценку
        rating_kb = kb.get_rating_keyboard(1)
        print("✅ Оценка - OK")
        
        # Проверяем модерацию
        mod_kb = kb.get_moderation_keyboard(123)
        print("✅ Модерация - OK")
        
        return True
        
    except Exception as e:
        print(f"❌ Keyboards - Ошибка: {e}")
        return False

def test_states():
    """Проверка состояний"""
    print("\n🔍 Проверка состояний...")
    
    try:
        from states import UploadStates, EditProfileStates, SearchStates, BroadcastStates, PluginUpdateStates, AdminStates
        
        # Проверяем, что все состояния определены
        states_list = [
            UploadStates.waiting_file,
            UploadStates.waiting_name,
            UploadStates.waiting_category,
            UploadStates.waiting_status,
            UploadStates.waiting_tags,
            EditProfileStates.waiting_nickname,
            EditProfileStates.waiting_username,
            SearchStates.waiting_query,
            BroadcastStates.waiting_message,
            PluginUpdateStates.waiting_file,
            AdminStates.waiting_changes
        ]
        
        for state in states_list:
            if state is None:
                raise ValueError("Состояние не определено")
        
        print("✅ Все состояния определены - OK")
        return True
        
    except Exception as e:
        print(f"❌ States - Ошибка: {e}")
        return False

def test_handlers_structure():
    """Проверка структуры хэндлеров"""
    print("\n🔍 Проверка структуры хэндлеров...")
    
    required_files = [
        'handlers/user/search.py',
        'handlers/user/profile.py',
        'handlers/user/upload.py',
        'handlers/user/subscriptions.py',
        'handlers/admin/moderation.py'
    ]
    
    all_ok = True
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file} - существует")
        else:
            print(f"❌ {file} - отсутствует")
            all_ok = False
    
    return all_ok

def test_callback_patterns():
    """Проверка шаблонов callback'ов"""
    print("\n🔍 Проверка callback patterns...")
    
    try:
        # Читаем keyboards.py и ищем все callback_data
        with open('keyboards.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        import re
        callbacks = re.findall(r'callback_data=["\']([^"\']+)["\']', content)
        dynamic_callbacks = re.findall(r'callback_data=f["\']([^"\']+)["\']', content)
        
        print(f"✅ Найдено callback'ов: {len(callbacks) + len(dynamic_callbacks)}")
        print(f"   Статические: {len(callbacks)}")
        print(f"   Динамические: {len(dynamic_callbacks)}")
        
        # Проверяем основные
        required_patterns = ['main_menu', 'plugin_', 'author_', 'category_', 'download_']
        for pattern in required_patterns:
            if pattern in content:
                print(f"✅ Паттерн '{pattern}' найден")
            else:
                print(f"❌ Паттерн '{pattern}' отсутствует")
        
        return True
        
    except Exception as e:
        print(f"❌ Callback patterns - Ошибка: {e}")
        return False

def test_router_registrations():
    """Проверка регистрации роутеров"""
    print("\n🔍 Проверка роутеров...")
    
    try:
        from handlers.user.search import router as search_router
        from handlers.user.profile import router as profile_router
        from handlers.user.upload import router as upload_router
        from handlers.user.subscriptions import router as subs_router
        from handlers.admin.moderation import router as mod_router
        
        routers = [search_router, profile_router, upload_router, subs_router, mod_router]
        
        for i, router in enumerate(routers):
            if router is not None:
                print(f"✅ Router {i+1} - OK")
            else:
                print(f"❌ Router {i+1} - None")
                return False
        
        return True
        
    except Exception as e:
        print(f"❌ Routers - Ошибка: {e}")
        return False

def test_imports_from_handlers():
    """Проверка импортов внутри хэндлеров"""
    print("\n🔍 Проверка импортов в хэндлерах...")
    
    handler_files = [
        'handlers/user/search.py',
        'handlers/user/profile.py',
        'handlers/user/upload.py',
        'handlers/user/subscriptions.py',
        'handlers/admin/moderation.py'
    ]
    
    all_ok = True
    for file in handler_files:
        try:
            # Проверяем, что файл можно импортировать
            module_path = file.replace('/', '.').replace('.py', '')
            __import__(module_path)
            print(f"✅ {file} - импорт OK")
        except Exception as e:
            print(f"❌ {file} - ошибка импорта: {e}")
            all_ok = False
    
    return all_ok

def main():
    """Главная функция тестирования"""
    print("🚀 Запуск комплексного тестирования бота...\n")
    print("="*60)
    
    all_passed = True
    
    # 1. Тест импортов
    if not test_imports():
        all_passed = False
    
    # 2. Тест конфигурации
    if not test_config():
        all_passed = False
    
    # 3. Тест базы данных
    if not test_database():
        all_passed = False
    
    # 4. Тест клавиатур
    if not test_keyboards():
        all_passed = False
    
    # 5. Тест состояний
    if not test_states():
        all_passed = False
    
    # 6. Тест структуры хэндлеров
    if not test_handlers_structure():
        all_passed = False
    
    # 7. Тест callback patterns
    if not test_callback_patterns():
        all_passed = False
    
    # 8. Тест роутеров
    if not test_router_registrations():
        all_passed = False
    
    # 9. Тест импортов хэндлеров
    if not test_imports_from_handlers():
        all_passed = False
    
    print("\n" + "="*60)
    
    if all_passed:
        print("🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
        print("\n📋 Что дальше:")
        print("1. Установите зависимости: pip install -r requirements.txt")
        print("2. Создайте файл .env с BOT_TOKEN и ADMIN_GROUP_ID")
        print("3. Запустите бота: python main.py")
        print("\n⚠️  ВАЖНО:")
        print("- Создайте административную группу в Telegram")
        print("- Добавьте бота в группу как администратора")
        print("- Создайте 3 темы (topics) в группе")
        print("- Укажите ID группы и тем в .env файле")
        print("\n✅ Бот готов к работе!")
    else:
        print("❌ Обнаружены ошибки!")
        print("\nИсправьте ошибки выше и запустите тест снова.")
        sys.exit(1)

if __name__ == "__main__":
    main()