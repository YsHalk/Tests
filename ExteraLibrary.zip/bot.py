#!/usr/bin/env python3
"""
Exteragram Plugin Library Bot - aiogram 3.x

Главный скрипт бота, объединяющий все модули.
Для запуска: python bot.py

Требования:
- aiogram==3.4.1
- python-dotenv
- aiofiles
"""

import asyncio
import logging
import os
import sys
from typing import List, Dict, Any

from aiogram import Bot, Dispatcher, types, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand
from aiogram.utils.keyboard import InlineKeyboardBuilder

# Импортируем модули
import buttons
import config
import database
import user_functions
import admin_functions

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Инициализация
storage = MemoryStorage()

# Жёсткая проверка токена
if not config.BOT_TOKEN or config.BOT_TOKEN.strip() in {"YOUR_BOT_TOKEN_HERE", "CHANGE_ME"}:
    raise RuntimeError(
        "BOT_TOKEN не задан. Создайте файл .env рядом с bot.py и укажите BOT_TOKEN=... "
        "(или задайте переменную окружения BOT_TOKEN)."
    )

bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=storage)

# Инициализация БД
db = database.Database(config.DATABASE_PATH)

# Подключаем роутеры
dp.include_router(user_functions.router)
dp.include_router(admin_functions.router)

# ========== ОСНОВНЫЕ ОБРАБОТЧИКИ ==========

@dp.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    await state.clear()
    
    user = db.get_user(message.from_user.id)
    if not user:
        await state.set_state(user_functions.RegistrationStates.waiting_display_name)
        await message.answer(config.MESSAGES["registration_required"], reply_markup=user_functions.create_cancel_menu())
    else:
        await message.answer(config.MESSAGES["start"], reply_markup=user_functions.create_main_menu())

@dp.message(Command("report"))
async def cmd_report(message: types.Message):
    text = message.text[7:].strip() if len(message.text) > 7 else ""
    if text:
        await message.answer("✅ Ваш отчет об ошибке отправлен разработчикам. Спасибо!")
    else:
        await message.answer("⚠️ Используйте: /report <текст ошибки>")

@dp.message(Command("admin"))
async def cmd_admin(message: types.Message):
    if message.from_user.id in config.ADMIN_IDS:
        keyboard = admin_functions.create_admin_menu()
        await message.answer("⚖️ Админская панель:", reply_markup=keyboard)
    else:
        await message.answer(config.MESSAGES["access_denied"])

# ========== ЗАГРУЗКА ПЛАГИНА ==========

@dp.message(F.document, StateFilter(user_functions.UploadStates.waiting_file))
async def process_upload_file(message: types.Message, state: FSMContext):
    file_info = message.document
    
    if file_info.file_size > 50 * 1024 * 1024:
        await message.answer("⚠️ Файл слишком большой. Максимальный размер - 50MB.")
        return
    
    await state.update_data(
        file_id=file_info.file_id,
        file_name=file_info.file_name,
        file_size=file_info.file_size
    )
    
    await message.answer(
        config.MESSAGES["upload_continue"],
        reply_markup=user_functions.create_file_replace_menu()
    )

@dp.message(StateFilter(user_functions.UploadStates.waiting_name_and_photo))
async def process_upload_name_and_photo(message: types.Message, state: FSMContext):
    """Шаг 2: название (и опционально описание) + опционально фото."""
    text_src = None
    if message.text:
        text_src = message.text.strip()
    elif message.caption:
        text_src = message.caption.strip()

    if text_src:
        parts = [p for p in text_src.split("\n", 1)]
        name = parts[0].strip()
        description = parts[1].strip() if len(parts) > 1 else ""
        if len(name) < 2 or len(name) > 100:
            await message.answer("⚠️ Название должно быть от 2 до 100 символов.")
            return
        await state.update_data(name=name, description=description)

    if message.photo:
        photo_id = message.photo[-1].file_id
        await state.update_data(photo_id=photo_id)

    data = await state.get_data()
    if "name" in data:
        await state.set_state(user_functions.UploadStates.waiting_category)
        keyboard = user_functions.create_categories_menu(is_for_upload=True)
        await message.answer(config.MESSAGES["upload_step3"], reply_markup=keyboard)
    else:
        await message.answer("✏️ Отправьте название плагина (можно с описанием со следующей строки):")

@dp.callback_query(F.data.startswith("upload_category_"))
async def process_upload_category(callback_query: types.CallbackQuery, state: FSMContext):
    category = callback_query.data.replace("upload_category_", "")
    await state.update_data(category=category)
    await state.set_state(user_functions.UploadStates.waiting_status)

    keyboard = user_functions.create_statuses_menu()
    try:
        await callback_query.message.edit_text(config.MESSAGES["upload_step4"], reply_markup=keyboard)
    except Exception:
        await callback_query.message.answer(config.MESSAGES["upload_step4"], reply_markup=keyboard)
    await callback_query.answer()

@dp.callback_query(F.data.startswith("status_"))
async def process_upload_status(callback_query: types.CallbackQuery, state: FSMContext):
    status = callback_query.data.replace("status_", "")
    await state.update_data(status=status)
    await state.set_state(user_functions.UploadStates.waiting_tags)

    try:
        await callback_query.message.edit_text(config.MESSAGES["upload_step5"])
    except Exception:
        await callback_query.message.answer(config.MESSAGES["upload_step5"])
    await callback_query.answer()

@dp.message(StateFilter(user_functions.UploadStates.waiting_tags))
async def process_upload_tags(message: types.Message, state: FSMContext):
    tags = message.text.strip().lower()
    await state.update_data(tags=tags)
    
    data = await state.get_data()
    
    update_plugin_id = data.get("update_plugin_id")
    if update_plugin_id:
        # Это обновление существующего плагина
        update_data = {
            "plugin_id": update_plugin_id,
            "user_id": message.from_user.id,
            "file_id": data["file_id"],
            "file_name": data["file_name"],
            "description": data.get("description", "")
        }
        
        update_id = db.create_update_request(update_data)
        if update_id:
            update_data["update_id"] = update_id
            update_data["plugin_name"] = db.get_plugin(update_plugin_id).name
            update_data["username"] = message.from_user.username or str(message.from_user.id)
            update_data["display_name"] = message.from_user.full_name
            
            await admin_functions.notify_admins_about_update(bot, update_data)
            
            await message.answer("✅ Заявка на обновление отправлена на модерацию!", reply_markup=user_functions.create_main_menu())
        else:
            await message.answer("⚠️ Произошла ошибка при создании заявки.")
    else:
        # Это новый плагин
        submission_data = {
            "user_id": message.from_user.id,
            "plugin_name": data["name"],
            "description": data.get("description", ""),
            "file_id": data["file_id"],
            "file_name": data["file_name"],
            "file_size": data["file_size"],
            "photo_id": data.get("photo_id"),
            "category": data["category"],
            "status": data["status"],
            "tags": tags
        }
        
        submission_id = db.create_submission(submission_data)
        if submission_id:
            submission_data["submission_id"] = submission_id
            submission_data["username"] = message.from_user.username or str(message.from_user.id)
            submission_data["display_name"] = message.from_user.full_name
            
            await admin_functions.notify_admins_about_submission(bot, submission_data)
            
            await message.answer(config.MESSAGES["upload_complete"], reply_markup=user_functions.create_main_menu())
        else:
            await message.answer("⚠️ Произошла ошибка при создании заявки.")
    
    await state.clear()

# ========== ЗАПУСК ==========

async def on_startup():
    # Базовая проверка конфигурации
    if not config.BOT_TOKEN or config.BOT_TOKEN == 'YOUR_BOT_TOKEN_HERE':
        logger.error('BOT_TOKEN не задан. Создайте .env и укажите BOT_TOKEN=...')
        raise RuntimeError('BOT_TOKEN is not set')

    logger.info("Bot starting...")
    
    commands = [
        BotCommand(command="start", description="Запустить бота"),
        BotCommand(command="report", description="Сообщить об ошибке"),
    ]
    
    if config.ADMIN_IDS:
        commands.append(BotCommand(command="admin", description="Админская панель"))
    
    await bot.set_my_commands(commands)
    
    try:
        test_user = db.get_user(1)
        logger.info("Database connected successfully")
    except Exception as e:
        logger.error(f"Database connection error: {e}")
        sys.exit(1)
    
    logger.info("Bot started successfully")

async def on_shutdown():
    logger.info("Bot shutting down...")
    await bot.session.close()
    await dp.storage.close()
    logger.info("Bot stopped")

async def main():
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)
    
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)
