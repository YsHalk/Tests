import aiosqlite
import json
from datetime import datetime
from typing import Optional, List, Dict, Any
from config import Config


class Database:
    def __init__(self):
        self.db_path = Config.DATABASE_PATH
    
    async def initialize(self):
        """Инициализация базы данных и создание таблиц"""
        async with aiosqlite.connect(self.db_path) as db:
            # Таблица пользователей
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    nickname TEXT NOT NULL,
                    user_tag TEXT,
                    banner_photo_id TEXT,
                    subscribers_count INTEGER DEFAULT 0,
                    total_downloads INTEGER DEFAULT 0,
                    total_views INTEGER DEFAULT 0,
                    total_rating REAL DEFAULT 0,
                    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Таблица плагинов
            await db.execute("""
                CREATE TABLE IF NOT EXISTS plugins (
                    plugin_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    file_id TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    photo_id TEXT,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL,
                    tags TEXT,
                    views INTEGER DEFAULT 0,
                    downloads INTEGER DEFAULT 0,
                    rating_sum REAL DEFAULT 0,
                    rating_count INTEGER DEFAULT 0,
                    is_archived INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            # Таблица подписок
            await db.execute("""
                CREATE TABLE IF NOT EXISTS subscriptions (
                    user_id INTEGER NOT NULL,
                    plugin_id INTEGER NOT NULL,
                    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, plugin_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id)
                )
            """)
            
            # Таблица оценок
            await db.execute("""
                CREATE TABLE IF NOT EXISTS ratings (
                    user_id INTEGER NOT NULL,
                    plugin_id INTEGER NOT NULL,
                    rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
                    rated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, plugin_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id)
                )
            """)
            
            # Таблица заявок на загрузку
            await db.execute("""
                CREATE TABLE IF NOT EXISTS upload_requests (
                    request_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    plugin_id INTEGER,
                    security_file_id TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',  # pending, approved, rejected, changes_requested
                    admin_comment TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    reviewed_at TIMESTAMP,
                    reviewed_by INTEGER,
                    FOREIGN KEY (user_id) REFERENCES users (user_id),
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id)
                )
            """)
            
            # Таблица отзывов
            await db.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    review_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    plugin_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    text TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (plugin_id) REFERENCES plugins (plugin_id),
                    FOREIGN KEY (user_id) REFERENCES users (user_id)
                )
            """)
            
            await db.commit()
    
    # ===== Пользователи =====
    
    async def create_user(self, user_id: int, username: str, nickname: str, user_tag: str) -> bool:
        """Создание нового пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            try:
                await db.execute(
                    "INSERT INTO users (user_id, username, nickname, user_tag) VALUES (?, ?, ?, ?)",
                    (user_id, username, nickname, user_tag)
                )
                await db.commit()
                return True
            except aiosqlite.IntegrityError:
                return False
    
    async def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Получение данных пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM users WHERE user_id = ?", (user_id,)
            )
            row = await cursor.fetchone()
            if row:
                return dict(zip([d[0] for d in cursor.description], row))
            return None
    
    async def update_user(self, user_id: int, **kwargs) -> bool:
        """Обновление данных пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            sets = ", ".join([f"{k} = ?" for k in kwargs.keys()])
            values = list(kwargs.values()) + [user_id]
            
            cursor = await db.execute(f"UPDATE users SET {sets} WHERE user_id = ?", values)
            await db.commit()
            return cursor.rowcount > 0
    
    # ===== Плагины =====
    
    async def create_plugin(self, user_id: int, file_id: str, file_name: str, title: str, 
                           description: str, category: str, status: str, tags: str,
                           photo_id: Optional[str] = None) -> int:
        """Создание нового плагина"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """INSERT INTO plugins 
                (user_id, file_id, file_name, title, description, photo_id, category, status, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (user_id, file_id, file_name, title, description, photo_id, category, status, tags)
            )
            await db.commit()
            return cursor.lastrowid
    
    async def get_plugin(self, plugin_id: int) -> Optional[Dict[str, Any]]:
        """Получение данных плагина"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM plugins WHERE plugin_id = ?", (plugin_id,)
            )
            row = await cursor.fetchone()
            if row:
                return dict(zip([d[0] for d in cursor.description], row))
            return None
    
    async def get_plugins_by_user(self, user_id: int, include_archived: bool = False) -> List[Dict[str, Any]]:
        """Получение всех плагинов пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            query = "SELECT * FROM plugins WHERE user_id = ?"
            if not include_archived:
                query += " AND is_archived = 0"
            
            cursor = await db.execute(query, (user_id,))
            rows = await cursor.fetchall()
            
            plugins = []
            for row in rows:
                plugins.append(dict(zip([d[0] for d in cursor.description], row)))
            return plugins
    
    async def update_plugin(self, plugin_id: int, **kwargs) -> bool:
        """Обновление данных плагина"""
        async with aiosqlite.connect(self.db_path) as db:
            kwargs['updated_at'] = datetime.now()
            sets = ", ".join([f"{k} = ?" for k in kwargs.keys()])
            values = list(kwargs.values()) + [plugin_id]
            
            cursor = await db.execute(f"UPDATE plugins SET {sets} WHERE plugin_id = ?", values)
            await db.commit()
            return cursor.rowcount > 0
    
    async def increment_plugin_views(self, plugin_id: int):
        """Увеличение счетчика просмотров"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE plugins SET views = views + 1 WHERE plugin_id = ?", (plugin_id,)
            )
            await db.commit()
    
    async def increment_plugin_downloads(self, plugin_id: int):
        """Увеличение счетчика скачиваний"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                "UPDATE plugins SET downloads = downloads + 1 WHERE plugin_id = ?", (plugin_id,)
            )
            await db.commit()
    
    async def get_popular_plugins(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Получение популярных плагинов"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """SELECT * FROM plugins 
                WHERE is_archived = 0 
                ORDER BY (downloads * 0.7 + views * 0.3) DESC 
                LIMIT ?""",
                (limit,)
            )
            rows = await cursor.fetchall()
            
            plugins = []
            for row in rows:
                plugins.append(dict(zip([d[0] for d in cursor.description], row)))
            return plugins
    
    async def get_plugins_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Получение плагинов по категории"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM plugins WHERE category = ? AND is_archived = 0",
                (category,)
            )
            rows = await cursor.fetchall()
            
            plugins = []
            for row in rows:
                plugins.append(dict(zip([d[0] for d in cursor.description], row)))
            return plugins
    
    # ===== Поиск =====
    
    async def search_plugins(self, query: str) -> List[Dict[str, Any]]:
        """Поиск плагинов по запросу"""
        async with aiosqlite.connect(self.db_path) as db:
            search_term = f"%{query.lower()}%"
            cursor = await db.execute(
                """SELECT * FROM plugins 
                WHERE is_archived = 0 
                AND (LOWER(title) LIKE ? 
                     OR LOWER(description) LIKE ? 
                     OR LOWER(tags) LIKE ? 
                     OR plugin_id IN (
                         SELECT plugin_id FROM plugins p 
                         JOIN users u ON p.user_id = u.user_id 
                         WHERE LOWER(u.nickname) LIKE ? 
                         OR LOWER(u.user_tag) LIKE ?
                     ))
                ORDER BY plugin_id DESC""",
                (search_term, search_term, search_term, search_term, search_term)
            )
            rows = await cursor.fetchall()
            
            plugins = []
            for row in rows:
                plugins.append(dict(zip([d[0] for d in cursor.description], row)))
            return plugins
    
    # ===== Подписки =====
    
    async def subscribe_to_plugin(self, user_id: int, plugin_id: int) -> bool:
        """Подписка на плагин"""
        async with aiosqlite.connect(self.db_path) as db:
            try:
                await db.execute(
                    "INSERT INTO subscriptions (user_id, plugin_id) VALUES (?, ?)",
                    (user_id, plugin_id)
                )
                await db.commit()
                
                # Увеличиваем счетчик подписчиков автора
                cursor = await db.execute(
                    "SELECT user_id FROM plugins WHERE plugin_id = ?", (plugin_id,)
                )
                author_row = await cursor.fetchone()
                if author_row:
                    author_id = author_row[0]
                    await db.execute(
                        "UPDATE users SET subscribers_count = subscribers_count + 1 WHERE user_id = ?",
                        (author_id,)
                    )
                    await db.commit()
                
                return True
            except aiosqlite.IntegrityError:
                return False
    
    async def unsubscribe_from_plugin(self, user_id: int, plugin_id: int) -> bool:
        """Отписка от плагина"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "DELETE FROM subscriptions WHERE user_id = ? AND plugin_id = ?",
                (user_id, plugin_id)
            )
            await db.commit()
            
            if cursor.rowcount > 0:
                # Уменьшаем счетчик подписчиков автора
                cursor = await db.execute(
                    "SELECT user_id FROM plugins WHERE plugin_id = ?", (plugin_id,)
                )
                author_row = await cursor.fetchone()
                if author_row:
                    author_id = author_row[0]
                    await db.execute(
                        "UPDATE users SET subscribers_count = MAX(0, subscribers_count - 1) WHERE user_id = ?",
                        (author_id,)
                    )
                    await db.commit()
                
                return True
            return False
    
    async def is_subscribed(self, user_id: int, plugin_id: int) -> bool:
        """Проверка подписки"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT 1 FROM subscriptions WHERE user_id = ? AND plugin_id = ?",
                (user_id, plugin_id)
            )
            return await cursor.fetchone() is not None
    
    async def get_user_subscriptions(self, user_id: int) -> List[Dict[str, Any]]:
        """Получение подписок пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """SELECT p.* FROM plugins p 
                JOIN subscriptions s ON p.plugin_id = s.plugin_id 
                WHERE s.user_id = ? AND p.is_archived = 0""",
                (user_id,)
            )
            rows = await cursor.fetchall()
            
            plugins = []
            for row in rows:
                plugins.append(dict(zip([d[0] for d in cursor.description], row)))
            return plugins
    
    async def get_plugin_subscribers(self, plugin_id: int) -> List[int]:
        """Получение подписчиков плагина"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT user_id FROM subscriptions WHERE plugin_id = ?", (plugin_id,)
            )
            rows = await cursor.fetchall()
            return [row[0] for row in rows]
    
    # ===== Оценки =====
    
    async def rate_plugin(self, user_id: int, plugin_id: int, rating: int) -> bool:
        """Оценка плагина"""
        if rating < Config.MIN_RATING or rating > Config.MAX_RATING:
            return False
        
        async with aiosqlite.connect(self.db_path) as db:
            try:
                await db.execute(
                    "INSERT INTO ratings (user_id, plugin_id, rating) VALUES (?, ?, ?)",
                    (user_id, plugin_id, rating)
                )
                await db.commit()
                
                # Обновляем рейтинг плагина
                await db.execute(
                    """UPDATE plugins 
                    SET rating_sum = (SELECT SUM(rating) FROM ratings WHERE plugin_id = ?),
                        rating_count = (SELECT COUNT(*) FROM ratings WHERE plugin_id = ?)
                    WHERE plugin_id = ?""",
                    (plugin_id, plugin_id, plugin_id)
                )
                await db.commit()
                
                return True
            except aiosqlite.IntegrityError:
                return False
    
    async def update_rating(self, user_id: int, plugin_id: int, rating: int) -> bool:
        """Обновление оценки плагина"""
        if rating < Config.MIN_RATING or rating > Config.MAX_RATING:
            return False
        
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "UPDATE ratings SET rating = ? WHERE user_id = ? AND plugin_id = ?",
                (rating, user_id, plugin_id)
            )
            await db.commit()
            
            if cursor.rowcount > 0:
                # Обновляем рейтинг плагина
                await db.execute(
                    """UPDATE plugins 
                    SET rating_sum = (SELECT SUM(rating) FROM ratings WHERE plugin_id = ?),
                        rating_count = (SELECT COUNT(*) FROM ratings WHERE plugin_id = ?)
                    WHERE plugin_id = ?""",
                    (plugin_id, plugin_id, plugin_id)
                )
                await db.commit()
                return True
            return False
    
    async def get_user_rating(self, user_id: int, plugin_id: int) -> Optional[int]:
        """Получение оценки пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT rating FROM ratings WHERE user_id = ? AND plugin_id = ?",
                (user_id, plugin_id)
            )
            row = await cursor.fetchone()
            return row[0] if row else None
    
    async def get_plugin_rating(self, plugin_id: int) -> tuple:
        """Получение рейтинга плагина (сумма, количество)"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT rating_sum, rating_count FROM plugins WHERE plugin_id = ?",
                (plugin_id,)
            )
            row = await cursor.fetchone()
            return (row[0] or 0, row[1] or 0) if row else (0, 0)
    
    # ===== Заявки на загрузку =====
    
    async def create_upload_request(self, user_id: int, plugin_id: int, security_file_id: str) -> int:
        """Создание заявки на загрузку"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """INSERT INTO upload_requests 
                (user_id, plugin_id, security_file_id) 
                VALUES (?, ?, ?)""",
                (user_id, plugin_id, security_file_id)
            )
            await db.commit()
            return cursor.lastrowid
    
    async def get_upload_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        """Получение заявки на загрузку"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM upload_requests WHERE request_id = ?", (request_id,)
            )
            row = await cursor.fetchone()
            if row:
                return dict(zip([d[0] for d in cursor.description], row))
            return None
    
    async def update_upload_request(self, request_id: int, **kwargs) -> bool:
        """Обновление заявки на загрузку"""
        async with aiosqlite.connect(self.db_path) as db:
            sets = ", ".join([f"{k} = ?" for k in kwargs.keys()])
            values = list(kwargs.values()) + [request_id]
            
            cursor = await db.execute(f"UPDATE upload_requests SET {sets} WHERE request_id = ?", values)
            await db.commit()
            return cursor.rowcount > 0
    
    # ===== Отзывы =====
    
    async def add_review(self, plugin_id: int, user_id: int, text: str) -> int:
        """Добавление отзыва"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "INSERT INTO reviews (plugin_id, user_id, text) VALUES (?, ?, ?)",
                (plugin_id, user_id, text)
            )
            await db.commit()
            return cursor.lastrowid
    
    async def get_plugin_reviews(self, plugin_id: int, limit: int = 10) -> List[Dict[str, Any]]:
        """Получение отзывов плагина"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                """SELECT r.*, u.nickname, u.user_tag 
                FROM reviews r 
                JOIN users u ON r.user_id = u.user_id 
                WHERE r.plugin_id = ? 
                ORDER BY r.created_at DESC 
                LIMIT ?""",
                (plugin_id, limit)
            )
            rows = await cursor.fetchall()
            
            reviews = []
            for row in rows:
                reviews.append(dict(zip([d[0] for d in cursor.description], row)))
            return reviews    
    async def get_user_subscribers_count(self, user_id: int) -> int:
        """Получение количества подписчиков пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT subscribers_count FROM users WHERE user_id = ?", (user_id,)
            )
            row = await cursor.fetchone()
            return row[0] if row and row[0] else 0    async def get_plugins_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Получение плагинов по категории"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute(
                "SELECT * FROM plugins WHERE category = ? AND is_archived = 0 ORDER BY created_at DESC",
                (category,)
            )
            rows = await cursor.fetchall()
            
            plugins = []
            for row in rows:
                plugins.append(dict(zip([d[0] for d in cursor.description], row)))
            return plugins