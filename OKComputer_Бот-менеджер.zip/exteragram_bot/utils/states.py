from aiogram.fsm.state import StatesGroup, State


class UserStates(StatesGroup):
    """Состояния пользователя"""
    
    # Регистрация
    waiting_nickname = State()  # Ожидание никнейма
    waiting_usertag = State()   # Ожидание юз тега
    
    # Поиск
    waiting_search_query = State()  # Ожидание поискового запроса
    
    # Профиль
    editing_nickname = State()  # Редактирование никнейма
    editing_usertag = State()   # Редактирование юз тега
    editing_banner = State()    # Редактирование баннера
    
    # Отзывы
    writing_review = State()    # Написание отзыва
    
    # Рассылка
    writing_broadcast = State()  # Написание сообщения для рассылки


class UploadStates(StatesGroup):
    """Состояния загрузки плагина"""
    
    waiting_file = State()          # Ожидание файла плагина
    waiting_title = State()         # Ожидание названия
    waiting_photo = State()         # Ожидание фото обложки
    waiting_category = State()      # Ожидание выбора категории
    waiting_status = State()        # Ожидание выбора статуса
    waiting_tags = State()          # Ожидание тегов
    waiting_confirmation = State()  # Ожидание подтверждения


class AdminStates(StatesGroup):
    """Состояния администратора"""
    
    # Редактирование заявки
    editing_title = State()       # Редактирование названия
    editing_description = State() # Редактирование описания
    editing_tags = State()        # Редактирование тегов
    editing_category = State()    # Редактирование категории
    editing_status = State()      # Редактирование статуса
    
    # Рассылка
    writing_broadcast_admin = State()  # Написание сообщения для рассылки от админа