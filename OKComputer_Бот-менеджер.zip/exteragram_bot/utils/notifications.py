from aiogram import Bot
from aiogram.exceptions import TelegramAPIError
from database import db
from config import Config
import logging

logger = logging.getLogger(__name__)


class NotificationManager:
    """Менеджер уведомлений"""
    
    def __init__(self, bot: Bot):
        self.bot = bot
    
    async def notify_plugin_update(self, plugin_id: int, update_text: str):
        """Уведомить подписчиков об обновлении плагина"""
        try:
            # Получаем плагин
            plugin = await db.get_plugin(plugin_id)
            if not plugin:
                return
            
            # Получаем подписчиков
            subscribers = await db.get_plugin_subscribers(plugin_id)
            
            # Получаем автора
            author = await db.get_user(plugin['user_id'])
            
            message_text = (
                f"🔔 <b>Плагин обновлен!</b>\n\n"
                f"📦 <b>{plugin['title']}</b>\n\n"
                f"📝 <i>{update_text}</i>\n\n"
                f"👤 Автор: {author['nickname']}"
            )
            
            # Отправляем всем подписчикам
            for user_id in subscribers:
                try:
                    await self.bot.send_message(
                        user_id,
                        message_text,
                        parse_mode="HTML",
                        reply_markup=self._get_plugin_button(plugin_id)
                    )
                except TelegramAPIError as e:
                    logger.error(f"Failed to notify user {user_id}: {e}")
        
        except Exception as e:
            logger.error(f"Error in notify_plugin_update: {e}")
    
    async def notify_moderation_result(self, user_id: int, plugin_title: str, 
                                      status: str, comment: str = None):
        """Уведомить пользователя о результате модерации"""
        try:
            status_texts = {
                'approved': ("✅ Плагин одобрен!", 
                           f"Ваш плагин <b>{plugin_title}</b> был одобрен и добавлен в библиотеку!"),
                'rejected': ("❌ Плагин отклонен", 
                           f"Ваш плагин <b>{plugin_title}</b> был отклонен."),
                'changes_requested': ("✏️ Требуются изменения", 
                                    f"Для плагина <b>{plugin_title}</b> требуются изменения.")
            }
            
            emoji, text = status_texts.get(status, ("📋", "Результат модерации"))
            
            message_text = f"{emoji} <b>{text}</b>\n\n"
            
            if comment:
                message_text += f"💬 Комментарий модератора:\n<i>{comment}</i>"
            
            await self.bot.send_message(user_id, message_text, parse_mode="HTML")
        
        except Exception as e:
            logger.error(f"Error in notify_moderation_result: {e}")
    
    async def notify_plugin_deleted(self, user_id: int, plugin_title: str, reason: str = None):
        """Уведомить автора об удалении плагина"""
        try:
            message_text = (
                f"🗑 <b>Плагин удален</b>\n\n"
                f"Плагин <b>{plugin_title}</b> был удален модератором.\n\n"
            )
            
            if reason:
                message_text += f"📌 Причина: <i>{reason}</i>\n\n"
            
            message_text += "Если у вас есть вопросы, обратитесь в поддержку."
            
            await self.bot.send_message(user_id, message_text, parse_mode="HTML")
        
        except Exception as e:
            logger.error(f"Error in notify_plugin_deleted: {e}")
    
    async def notify_new_request(self, request_id: int, user_id: int, plugin_title: str):
        """Уведомить админов о новой заявке"""
        try:
            user = await db.get_user(user_id)
            
            message_text = (
                f"📋 <b>Новая заявка на загрузку</b>\n\n"
                f"📦 <b>{plugin_title}</b>\n"
                f"👤 Автор: {user['nickname']}\n"
                f"🆔 Заявка: #{request_id}"
            )
            
            await self.bot.send_message(
                Config.ADMIN_GROUP_ID,
                message_text,
                parse_mode="HTML",
                message_thread_id=Config.REQUESTS_TOPIC_ID
            )
        
        except Exception as e:
            logger.error(f"Error in notify_new_request: {e}")
    
    async def notify_security_file(self, file_id: str, file_name: str, user_id: int):
        """Отправить файл в топик безопасности"""
        try:
            user = await db.get_user(user_id)
            
            await self.bot.send_document(
                Config.ADMIN_GROUP_ID,
                file_id,
                caption=f"📁 <b>{file_name}</b>\n👤 От: {user['nickname']}",
                parse_mode="HTML",
                message_thread_id=Config.SECURITY_TOPIC_ID
            )
        
        except Exception as e:
            logger.error(f"Error in notify_security_file: {e}")
    
    async def notify_new_author_subscription(self, author_id: int, subscriber_id: int):
        """Уведомить автора о новом подписчике"""
        try:
            subscriber = await db.get_user(subscriber_id)
            
            message_text = (
                f"❤️ <b>Новый подписчик!</b>\n\n"
                f"На вас подписался <b>{subscriber['nickname']}</b>\n\n"
                f"Всего подписчиков: {await db.get_user_subscribers_count(author_id)}"
            )
            
            await self.bot.send_message(author_id, message_text, parse_mode="HTML")
        
        except Exception as e:
            logger.error(f"Error in notify_new_author_subscription: {e}")
    
    @staticmethod
    def _get_plugin_button(plugin_id: int):
        """Кнопка для перехода к плагину"""
        from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
        
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📄 Страница плагина", callback_data=f"plugin_{plugin_id}")]
        ])
        return kb