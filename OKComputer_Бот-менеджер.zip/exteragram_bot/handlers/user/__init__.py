from aiogram import Dispatcher
from .start import register_start_handlers
from .search import register_search_handlers
from .upload import register_upload_handlers
from .profile import register_profile_handlers
from .plugins import register_plugins_handlers


def register_user_handlers(dp: Dispatcher):
    """Регистрация всех обработчиков пользователя"""
    register_start_handlers(dp)
    register_search_handlers(dp)
    register_upload_handlers(dp)
    register_profile_handlers(dp)
    register_plugins_handlers(dp)