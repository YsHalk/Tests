from aiogram import Dispatcher
from .moderation import register_moderation_handlers
from .broadcast import register_broadcast_handlers


def register_admin_handlers(dp: Dispatcher):
    """Регистрация всех обработчиков администратора"""
    register_moderation_handlers(dp)
    register_broadcast_handlers(dp)