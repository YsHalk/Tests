from aiogram import Dispatcher, types, F
from aiogram.fsm.context import FSMContext
from keyboards.admin_kb import AdminKeyboards
from keyboards.user_kb import UserKeyboards
from utils.states import AdminStates, UploadStates
from utils.notifications import NotificationManager
from database import db
from config import Config
import logging

logger = logging.getLogger(__name__)


async def approve_request(callback: types.CallbackQuery, bot):
    """Одобрить заявку"""
    request_id = int(callback.data.replace('approve_', ''))
    
    request = await db.get_upload_request(request_id)
    if not request:
        await callback.answer("❌ Заявка не найдена", show_alert=True)
        return
    
    # Обновляем статус заявки
    await db.update_upload_request(
        request_id,
        status='approved',
        reviewed_at='now',
        reviewed_by=callback.from_user.id
    )
    
    # Получаем плагин
    plugin = await db.get_plugin(request['plugin_id'])
    
    # Уведомляем пользователя
    nm = NotificationManager(bot)
    await nm.notify_moderation_result(
        request['user_id'],
        plugin['title'],
        'approved'
    )
    
    # Удаляем сообщение с заявкой
    await callback.message.delete()
    
    await callback.answer("✅ Заявка одобрена")


async def reject_request(callback: types.CallbackQuery, bot):
    """Отклонить заявку"""
    request_id = int(callback.data.replace('reject_', ''))
    
    request = await db.get_upload_request(request_id)
    if not request:
        await callback.answer("❌ Заявка не найдена", show_alert=True)
        return
    
    # Обновляем статус заявки
    await db.update_upload_request(
        request_id,
        status='rejected',
        reviewed_at='now',
        reviewed_by=callback.from_user.id,
        admin_comment="Заявка отклонена"
    )
    
    # Получаем плагин
    plugin = await db.get_plugin(request['plugin_id'])
    
    # Уведомляем пользователя
    nm = NotificationManager(bot)
    await nm.notify_moderation_result(
        request['user_id'],
        plugin['title'],
        'rejected',
        "Заявка отклонена модератором"
    )
    
    # Удаляем плагин
    # await db.delete_plugin(request['plugin_id'])
    
    await callback.message.delete()
    await callback.answer("❌ Заявка отклонена")


async def edit_request(callback: types.CallbackQuery, state: FSMContext):
    """Редактировать заявку"""
    request_id = int(callback.data.replace('edit_', ''))
    
    await callback.message.edit_reply_markup(
        reply_markup=AdminKeyboards.edit_request_fields(request_id)
    )
    await callback.answer()


async def edit_request_title(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование названия"""
    request_id = int(callback.data.replace('edit_title_', ''))
    
    request = await db.get_upload_request(request_id)
    plugin = await db.get_plugin(request['plugin_id'])
    
    await callback.message.edit_text(
        f"📝 <b>Редактирование названия</b>\n\n"
        f"Текущее: <b>{plugin['title']}</b>\n\n"
        "Введите новое название:",
        parse_mode="HTML"
    )
    await state.update_data(edit_request_id=request_id, edit_field='title')
    await state.set_state(AdminStates.editing_title)
    await callback.answer()


async def edit_request_description(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование описания"""
    request_id = int(callback.data.replace('edit_desc_', ''))
    
    await callback.message.edit_text(
        "📝 <b>Редактирование описания</b>\n\n"
        "Введите новое описание:",
        parse_mode="HTML"
    )
    await state.update_data(edit_request_id=request_id, edit_field='description')
    await state.set_state(AdminStates.editing_description)
    await callback.answer()


async def edit_request_tags(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование тегов"""
    request_id = int(callback.data.replace('edit_tags_', ''))
    
    await callback.message.edit_text(
        "🏷 <b>Редактирование тегов</b>\n\n"
        "Введите новые теги:",
        parse_mode="HTML"
    )
    await state.update_data(edit_request_id=request_id, edit_field='tags')
    await state.set_state(AdminStates.editing_tags)
    await callback.answer()


async def edit_request_category(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование категории"""
    request_id = int(callback.data.replace('edit_cat_', ''))
    
    await callback.message.edit_text(
        "📂 <b>Редактирование категории</b>\n\n"
        "Выберите новую категорию:",
        parse_mode="HTML",
        reply_markup=UserKeyboards.select_category()
    )
    await state.update_data(edit_request_id=request_id, edit_field='category')
    await state.set_state(AdminStates.editing_category)
    await callback.answer()


async def edit_request_status(callback: types.CallbackQuery, state: FSMContext):
    """Редактирование статуса"""
    request_id = int(callback.data.replace('edit_status_', ''))
    
    await callback.message.edit_text(
        "🛠 <b>Редактирование статуса</b>\n\n"
        "Выберите новый статус:",
        parse_mode="HTML",
        reply_markup=UserKeyboards.select_status()
    )
    await state.update_data(edit_request_id=request_id, edit_field='status')
    await state.set_state(AdminStates.editing_status)
    await callback.answer()


async def process_edit_field(message: types.Message, state: FSMContext, bot):
    """Обработка редактирования поля"""
    data = await state.get_data()
    request_id = data['edit_request_id']
    field = data['edit_field']
    
    request = await db.get_upload_request(request_id)
    plugin_id = request['plugin_id']
    
    value = message.text.strip()
    
    # Сохраняем изменения
    if field == 'title':
        await db.update_plugin(plugin_id, title=value)
    elif field == 'description':
        await db.update_plugin(plugin_id, description=value)
    elif field == 'tags':
        await db.update_plugin(plugin_id, tags=value)
    elif field == 'category':
        # Обработка категории из callback
        return
    elif field == 'status':
        # Обработка статуса из callback
        return
    
    await message.answer(
        "✅ Изменения сохранены!\n\n"
        "Продолжите редактирование или нажмите 'Готово':",
        reply_markup=AdminKeyboards.edit_request_fields(request_id)
    )
    await state.clear()


async def edit_request_done(callback: types.CallbackQuery, state: FSMContext, bot):
    """Завершение редактирования"""
    request_id = int(callback.data.replace('edit_done_', ''))
    
    request = await db.get_upload_request(request_id)
    plugin = await db.get_plugin(request['plugin_id'])
    
    # Обновляем статус заявки
    await db.update_upload_request(
        request_id,
        status='changes_requested',
        reviewed_at='now',
        reviewed_by=callback.from_user.id
    )
    
    # Уведомляем пользователя об изменениях
    nm = NotificationManager(bot)
    await nm.notify_moderation_result(
        request['user_id'],
        plugin['title'],
        'changes_requested',
        "Администратор внес изменения. Пожалуйста, проверьте и подтвердите."
    )
    
    # Отправляем пользователю запрос на подтверждение
    try:
        await bot.send_message(
            request['user_id'],
            f"📋 <b>Заявка #{request_id} изменена</b>\n\n"
            f"Плагин: <b>{plugin['title']}</b>\n\n"
            f"Администратор внес изменения. Пожалуйста, проверьте и подтвердите:",
            parse_mode="HTML",
            reply_markup=AdminKeyboards.user_confirm_changes(request_id)
        )
    except Exception as e:
        logger.error(f"Failed to send confirmation to user: {e}")
    
    await callback.message.delete()
    await callback.answer("✅ Пользователь уведомлен")


async def accept_changes(callback: types.CallbackQuery, bot):
    """Пользователь принял изменения"""
    request_id = int(callback.data.replace('accept_changes_', ''))
    
    request = await db.get_upload_request(request_id)
    if not request:
        await callback.answer("❌ Заявка не найдена", show_alert=True)
        return
    
    # Одобряем заявку
    await db.update_upload_request(
        request_id,
        status='approved',
        reviewed_at='now',
        reviewed_by=request['reviewed_by'] or Config.OWNER_ID
    )
    
    plugin = await db.get_plugin(request['plugin_id'])
    
    # Уведомляем админов
    await bot.send_message(
        Config.ADMIN_GROUP_ID,
        f"✅ <b>Изменения подтверждены</b>\n\n"
        f"Плагин: <b>{plugin['title']}</b>\n"
        f"Автор подтвердил изменения",
        parse_mode="HTML",
        message_thread_id=Config.REQUESTS_TOPIC_ID
    )
    
    await callback.message.edit_text(
        "✅ Изменения подтверждены! Плагин добавлен в библиотеку.",
        reply_markup=UserKeyboards.back_to_menu()
    )


async def decline_changes(callback: types.CallbackQuery):
    """Пользователь отклонил изменения"""
    request_id = int(callback.data.replace('decline_changes_', ''))
    
    await callback.message.edit_text(
        "❌ Изменения отклонены.\n\n"
        "Свяжитесь с поддержкой для уточнения деталей.",
        reply_markup=UserKeyboards.back_to_menu()
    )


def register_moderation_handlers(dp: Dispatcher):
    """Регистрация обработчиков модерации"""
    dp.callback_query.register(approve_request, F.data.startswith("approve_"))
    dp.callback_query.register(reject_request, F.data.startswith("reject_"))
    dp.callback_query.register(edit_request, F.data.startswith("edit_"))
    dp.callback_query.register(edit_request_title, F.data.startswith("edit_title_"))
    dp.callback_query.register(edit_request_description, F.data.startswith("edit_desc_"))
    dp.callback_query.register(edit_request_tags, F.data.startswith("edit_tags_"))
    dp.callback_query.register(edit_request_category, F.data.startswith("edit_cat_"))
    dp.callback_query.register(edit_request_status, F.data.startswith("edit_status_"))
    dp.callback_query.register(edit_request_done, F.data.startswith("edit_done_"))
    dp.callback_query.register(accept_changes, F.data.startswith("accept_changes_"))
    dp.callback_query.register(decline_changes, F.data.startswith("decline_changes_"))
    
    dp.message.register(process_edit_field, AdminStates.editing_title, F.text)
    dp.message.register(process_edit_field, AdminStates.editing_description, F.text)
    dp.message.register(process_edit_field, AdminStates.editing_tags, F.text)