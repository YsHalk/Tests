from aiogram import Dispatcher, types, F
from aiogram.fsm.context import FSMContext
from keyboards.admin_kb import AdminKeyboards
from keyboards.user_kb import UserKeyboards
from utils.states import UserStates, AdminStates
from database import db
from config import Config
import logging

logger = logging.getLogger(__name__)


async def broadcast_button(callback: types.CallbackQuery, state: FSMContext):
    """Кнопка 'Отправить сообщение подписчикам'"""
    user_id = callback.from_user.id
    user = await db.get_user(user_id)
    
    if user['subscribers_count'] == 0:
        await callback.answer("❌ У вас нет подписчиков", show_alert=True)
        return
    
    await callback.message.edit_text(
        f"✉️ <b>Рассылка подписчикам</b>\n\n"
        f"У вас <b>{user['subscribers_count']:,}</b> подписчиков.\n\n"
        "Отправьте сообщение для рассылки (текст, фото, видео):",
        parse_mode="HTML"
    )
    await state.set_state(UserStates.writing_broadcast)
    await callback.answer()


async def process_broadcast(message: types.Message, state: FSMContext, bot):
    """Обработка рассылки"""
    user_id = message.from_user.id
    user = await db.get_user(user_id)
    
    # Получаем всех подписчиков (в реальном приложении - из базы)
    # Пока отправляем только владельцу для теста
    subscribers = [user_id]
    
    success_count = 0
    fail_count = 0
    
    for subscriber_id in subscribers:
        try:
            if message.photo:
                await bot.send_photo(
                    subscriber_id,
                    message.photo[-1].file_id,
                    caption=message.caption or "",
                    parse_mode="HTML"
                )
            elif message.video:
                await bot.send_video(
                    subscriber_id,
                    message.video.file_id,
                    caption=message.caption or "",
                    parse_mode="HTML"
                )
            elif message.text:
                await bot.send_message(
                    subscriber_id,
                    message.text,
                    parse_mode="HTML"
                )
            success_count += 1
        except Exception as e:
            logger.error(f"Failed to send to {subscriber_id}: {e}")
            fail_count += 1
    
    await message.answer(
        f"✅ <b>Рассылка завершена</b>\n\n"
        f"Отправлено: <b>{success_count}</b>\n"
        f"Ошибок: <b>{fail_count}</b>",
        parse_mode="HTML",
        reply_markup=UserKeyboards.profile_menu()
    )
    await state.clear()


async def admin_broadcast(callback: types.CallbackQuery, state: FSMContext):
    """Админская рассылка всем пользователям"""
    if callback.from_user.id != Config.OWNER_ID:
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    
    await callback.message.edit_text(
        "📢 <b>Админская рассылка</b>\n\n"
        "Отправьте сообщение для рассылки ВСЕМ пользователям:",
        parse_mode="HTML"
    )
    await state.set_state(AdminStates.writing_broadcast_admin)
    await callback.answer()


async def process_admin_broadcast(message: types.Message, state: FSMContext, bot):
    """Обработка админской рассылки"""
    # Получаем всех пользователей (в реальном приложении - из базы)
    # Для теста отправляем только владельцу
    users = [Config.OWNER_ID]
    
    success_count = 0
    fail_count = 0
    
    for user_id in users:
        try:
            if message.photo:
                await bot.send_photo(
                    user_id,
                    message.photo[-1].file_id,
                    caption=message.caption or "",
                    parse_mode="HTML"
                )
            elif message.video:
                await bot.send_video(
                    user_id,
                    message.video.file_id,
                    caption=message.caption or "",
                    parse_mode="HTML"
                )
            elif message.text:
                await bot.send_message(
                    user_id,
                    message.text,
                    parse_mode="HTML"
                )
            success_count += 1
        except Exception as e:
            logger.error(f"Failed to send to {user_id}: {e}")
            fail_count += 1
    
    await message.answer(
        f"✅ <b>Админская рассылка завершена</b>\n\n"
        f"Отправлено: <b>{success_count}</b>\n"
        f"Ошибок: <b>{fail_count}</b>",
        parse_mode="HTML",
        reply_markup=AdminKeyboards.admin_menu()
    )
    await state.clear()


def register_broadcast_handlers(dp: Dispatcher):
    """Регистрация обработчиков рассылки"""
    dp.callback_query.register(broadcast_button, F.data == "broadcast")
    dp.callback_query.register(admin_broadcast, F.data == "admin_broadcast")
    
    dp.message.register(process_broadcast, UserStates.writing_broadcast)
    dp.message.register(process_admin_broadcast, AdminStates.writing_broadcast_admin)