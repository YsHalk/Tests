from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class User:
    user_id: int
    username: Optional[str]
    nickname: str
    user_tag: Optional[str]
    banner_photo_id: Optional[str]
    subscribers_count: int
    total_downloads: int
    total_views: int
    total_rating: float
    registered_at: datetime
    
    @property
    def display_name(self) -> str:
        """Отображаемое имя"""
        return self.nickname or f"Пользователь #{self.user_id}"
    
    @property
    def mention(self) -> str:
        """Упоминание пользователя"""
        if self.user_tag:
            return f"@{self.user_tag}"
        if self.username:
            return f"@{self.username}"
        return self.display_name