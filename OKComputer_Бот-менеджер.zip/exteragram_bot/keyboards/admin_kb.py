from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


class AdminKeyboards:
    """Клавиатуры для администраторов - ЛЕГКО РЕДАКТИРОВАТЬ!"""
    
    # === МОДЕРАЦИЯ ЗАЯВКИ ===
    @staticmethod
    def moderation_request(request_id: int) -> InlineKeyboardMarkup:
        """Кнопки модерации заявки"""
        kb = InlineKeyboardBuilder()
        
        kb.button(text="✅ Одобрить", callback_data=f"approve_{request_id}")
        kb.button(text="✏️ Изменить", callback_data=f"edit_{request_id}")
        kb.button(text="❌ Отклонить", callback_data=f"reject_{request_id}")
        
        kb.adjust(3)
        return kb.as_markup()
    
    # === РЕДАКТИРОВАНИЕ ЗАЯВКИ (админ) ===
    @staticmethod
    def edit_request_fields(request_id: int) -> InlineKeyboardMarkup:
        """Выбор поля для редактирования"""
        kb = InlineKeyboardBuilder()
        
        kb.button(text="📝 Название", callback_data=f"edit_title_{request_id}")
        kb.button(text="📄 Описание", callback_data=f"edit_desc_{request_id}")
        kb.button(text="🏷 Теги", callback_data=f"edit_tags_{request_id}")
        kb.button(text="📂 Категория", callback_data=f"edit_cat_{request_id}")
        kb.button(text="🎭 Статус", callback_data=f"edit_status_{request_id}")
        kb.button(text="✅ Готово", callback_data=f"edit_done_{request_id}")
        
        kb.adjust(2, 2, 2)
        return kb.as_markup()
    
    # === ПОДТВЕРЖДЕНИЕ ИЗМЕНЕНИЙ (пользователю) ===
    @staticmethod
    def user_confirm_changes(request_id: int) -> InlineKeyboardMarkup:
        """Пользователь подтверждает изменения"""
        kb = InlineKeyboardBuilder()
        
        kb.button(text="✅ Принять изменения", callback_data=f"accept_changes_{request_id}")
        kb.button(text="❌ Отклонить", callback_data=f"decline_changes_{request_id}")
        
        kb.adjust(1)
        return kb.as_markup()
    
    # === АДМИН МЕНЮ ===
    @staticmethod
    def admin_menu() -> InlineKeyboardMarkup:
        """Админское меню"""
        kb = InlineKeyboardBuilder()
        
        kb.button(text="📋 Активные заявки", callback_data="admin_requests")
        kb.button(text="📊 Статистика", callback_data="admin_stats")
        kb.button(text="🔧 Настройки", callback_data="admin_settings")
        kb.button(text="📢 Рассылка", callback_data="admin_broadcast")
        
        kb.adjust(2, 2)
        return kb.as_markup()
    
    # === СТАТИСТИКА ===
    @staticmethod
    def refresh_stats() -> InlineKeyboardMarkup:
        """Обновить статистику"""
        kb = InlineKeyboardBuilder()
        kb.button(text="🔄 Обновить", callback_data="refresh_stats")
        return kb.as_markup()
    
    # === УВЕДОМЛЕНИЕ АВТОРУ (о действиях модерации) ===
    @staticmethod
    def notify_author_action(plugin_id: int, action: str) -> InlineKeyboardMarkup:
        """Кнопки для уведомления автора"""
        kb = InlineKeyboardBuilder()
        
        if action == "deleted":
            kb.button(text="📞 Поддержка", callback_data="support")
        elif action == "updated":
            kb.button(text="📄 Страница плагина", callback_data=f"plugin_{plugin_id}")
        
        kb.button(text="🏠 Меню", callback_data="back_main")
        kb.adjust(1)
        return kb.as_markup()