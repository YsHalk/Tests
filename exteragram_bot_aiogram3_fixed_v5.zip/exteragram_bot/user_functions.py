import os
from typing import Dict, List, Optional, Any
from aiogram import types, F, Router
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from datetime import datetime

try:
    from . import buttons
except ImportError:
    import buttons
try:
    from .database import Database, Plugin
except ImportError:
    from database import Database, Plugin, User
from config import DATABASE_PATH, PLUGIN_STORAGE_PATH, PHOTO_STORAGE_PATH, MESSAGES, CATEGORIES, DEV_STATUSES

os.makedirs(PLUGIN_STORAGE_PATH, exist_ok=True)
os.makedirs(PHOTO_STORAGE_PATH, exist_ok=True)

db = Database(DATABASE_PATH)

router = Router()

async def _edit_or_send(callback_query: types.CallbackQuery, text: str, reply_markup=None):
    """Для inline-кнопок: пытаемся отредактировать текущее сообщение, иначе шлём новое."""
    msg = callback_query.message
    try:
        is_media = any(getattr(msg, attr, None) for attr in ("photo", "document", "video", "animation", "audio", "voice"))
        if is_media:
            await msg.edit_caption(caption=text, reply_markup=reply_markup)
        else:
            await msg.edit_text(text, reply_markup=reply_markup)
    except Exception:
        await msg.answer(text, reply_markup=reply_markup)


class RegistrationStates(StatesGroup):
    waiting_display_name = State()
    waiting_username = State()

class UploadStates(StatesGroup):
    waiting_file = State()
    waiting_name_and_photo = State()
    waiting_category = State()
    waiting_status = State()
    waiting_tags = State()

class SearchStates(StatesGroup):
    waiting_query = State()

class ProfileEditStates(StatesGroup):
    waiting_display_name = State()
    waiting_username = State()
    waiting_banner = State()

class BroadcastStates(StatesGroup):
    waiting_message = State()

def create_main_menu() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text=buttons.MAIN_MENU["search"])
    builder.button(text=buttons.MAIN_MENU["upload"])
    builder.button(text=buttons.MAIN_MENU["popular"])
    builder.button(text=buttons.MAIN_MENU["categories"])
    builder.button(text=buttons.MAIN_MENU["subscriptions"])
    builder.button(text=buttons.MAIN_MENU["profile"])
    builder.adjust(3, 3)
    return builder.as_markup(resize_keyboard=True)


def create_cancel_menu() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text=buttons.COMMON["cancel"])
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True)


def create_categories_menu(is_for_upload: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, value in buttons.CATEGORIES.items():
        callback_data = f"upload_category_{key}" if is_for_upload else f"browse_category_{key}"
        builder.button(text=value, callback_data=callback_data)
    builder.button(text=buttons.COMMON["cancel"], callback_data="cancel")
    builder.adjust(1)
    return builder.as_markup()


def create_statuses_menu() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, value in buttons.DEV_STATUSES.items():
        builder.button(text=value, callback_data=f"status_{key}")
    builder.button(text=buttons.COMMON["cancel"], callback_data="cancel")
    builder.adjust(1)
    return builder.as_markup()


def create_plugin_menu(plugin_id: int, user_id: int, is_author: bool = False, is_subscribed: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=buttons.PLUGIN_PAGE["download"], callback_data=f"download_{plugin_id}"),
        InlineKeyboardButton(
            text=buttons.PLUGIN_PAGE["unsubscribe"] if is_subscribed else buttons.PLUGIN_PAGE["subscribe"],
            callback_data=f"{'unsubscribe' if is_subscribed else 'subscribe'}_{plugin_id}",
        ),
    )
    builder.row(
        InlineKeyboardButton(text=buttons.PLUGIN_PAGE["author"], callback_data=f"author_{plugin_id}"),
        InlineKeyboardButton(text=buttons.PLUGIN_PAGE["reviews"], callback_data=f"reviews_{plugin_id}"),
        InlineKeyboardButton(text=buttons.PLUGIN_PAGE["rate"], callback_data=f"rate_{plugin_id}"),
    )
    if is_author:
        builder.row(InlineKeyboardButton(text=buttons.PLUGIN_PAGE["manage"], callback_data=f"manage_{plugin_id}"))
    return builder.as_markup()


def create_manage_menu(plugin_id: int, is_archived: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text=buttons.PLUGIN_PAGE["restore"] if is_archived else buttons.PLUGIN_PAGE["archive"],
            callback_data=f"{'restore' if is_archived else 'archive'}_{plugin_id}",
        ),
        InlineKeyboardButton(text=buttons.PLUGIN_PAGE["delete"], callback_data=f"delete_{plugin_id}"),
    )
    builder.row(
        InlineKeyboardButton(text=buttons.PLUGIN_PAGE["update"], callback_data=f"update_{plugin_id}"),
        InlineKeyboardButton(text=buttons.COMMON["back"], callback_data=f"back_to_plugin_{plugin_id}"),
    )
    return builder.as_markup()


def create_rating_menu(plugin_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for rating in range(1, 6):
        builder.button(text=str(rating), callback_data=f"rate_{plugin_id}_{rating}")
    builder.adjust(5)
    builder.row(InlineKeyboardButton(text=buttons.COMMON["back"], callback_data=f"back_to_plugin_{plugin_id}"))
    return builder.as_markup()




@router.message(RegistrationStates.waiting_display_name)
async def process_registration_display_name(message: types.Message, state: FSMContext):
    display_name = message.text.strip()
    if len(display_name) < 2 or len(display_name) > 50:
        await message.answer("⚠️ Никнейм должен быть от 2 до 50 символов. Попробуйте еще раз:")
        return
    
    await state.update_data(display_name=display_name)
    await state.set_state(RegistrationStates.waiting_username)
    await message.answer(MESSAGES["registration_username"])

@router.message(RegistrationStates.waiting_username)
async def process_registration_username(message: types.Message, state: FSMContext):
    username = message.text.strip().replace("@", "")
    if len(username) < 3 or len(username) > 32:
        await message.answer("⚠️ Username должен быть от 3 до 32 символов. Попробуйте еще раз:")
        return
    
    user_data = await state.get_data()
    display_name = user_data["display_name"]
    
    success = db.create_user(message.from_user.id, username, display_name)
    if success:
        await state.clear()
        await message.answer(MESSAGES["registration_complete"], reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка при регистрации. Попробуйте еще раз.")

@router.message(lambda message: message.text == buttons.MAIN_MENU["search"])
async def menu_search(message: types.Message, state: FSMContext):
    await state.set_state(SearchStates.waiting_query)
    await message.answer(MESSAGES["search_prompt"], reply_markup=create_cancel_menu())

@router.message(SearchStates.waiting_query)
async def process_search_query(message: types.Message, state: FSMContext):
    query = message.text.strip()
    if len(query) < 2:
        await message.answer("⚠️ Запрос слишком короткий. Попробуйте еще раз:")
        return
    
    results = db.search_plugins(query, 10)
    await state.clear()
    
    if not results:
        await message.answer(MESSAGES["search_no_results"], reply_markup=create_main_menu())
        return
    
    await message.answer(f"🔍 Возможно, вы искали.. (найдено {len(results)})", reply_markup=create_main_menu())
    
    for plugin in results[:5]:
        text = format_plugin_preview(plugin)
        photo_id = plugin.get("photo_id")
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=f"📥 {plugin['name']}", callback_data=f"plugin_{plugin['plugin_id']}")
        ]])
        
        if photo_id:
            await message.answer_photo(photo=photo_id, caption=text, reply_markup=keyboard)
        else:
            await message.answer(text=text, reply_markup=keyboard)

def format_plugin_preview(plugin: Dict[str, Any]) -> str:
    return f"""<b>{plugin['name']}</b>

<blockquote>{plugin['description'][:100]}...</blockquote>

👤 Автор: @{plugin['author_username']}
📂 Категория: {buttons.CATEGORIES.get(plugin['category'], plugin['category'])}
👁 Просмотров: {plugin['views']}
📥 Скачиваний: {plugin['downloads']}
⭐ Рейтинг: {plugin['rating']:.1f} ({plugin['rating_count']} оценок)"""

@router.message(lambda message: message.text == buttons.MAIN_MENU["popular"])
async def menu_popular(message: types.Message):
    plugins = db.get_popular_plugins(10)
    
    if not plugins:
        await message.answer("😔 Плагинов пока нет. Будьте первым!")
        return
    
    await message.answer("⭐ Популярные плагины:", reply_markup=create_main_menu())
    
    for plugin in plugins[:5]:
        text = format_plugin_preview(plugin)
        photo_id = plugin.get("photo_id")
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=f"📥 {plugin['name']}", callback_data=f"plugin_{plugin['plugin_id']}")
        ]])
        
        if photo_id:
            await message.answer_photo(photo=photo_id, caption=text, reply_markup=keyboard)
        else:
            await message.answer(text=text, reply_markup=keyboard)

@router.message(lambda message: message.text == buttons.MAIN_MENU["categories"])
async def menu_categories(message: types.Message):
    keyboard = create_categories_menu(is_for_upload=False)
    await message.answer("📂 Выберите категорию:", reply_markup=keyboard)

@router.callback_query(F.data.startswith("browse_category_"))
async def process_browse_category(callback_query: types.CallbackQuery):
    category = callback_query.data.replace("browse_category_", "")
    category_name = buttons.CATEGORIES.get(category, category)

    plugins = db.get_plugins_by_category(category, limit=10)

    if not plugins:
        text = f"""📂 <b>{category_name}</b>

😔 В этой категории пока нет плагинов."""
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=buttons.COMMON["back"], callback_data="browse_categories")]
        ])
        await _edit_or_send(callback_query, text, reply_markup=keyboard)
        await callback_query.answer()
        return

    lines = [
        f"📂 <b>{category_name}</b>",
        "",
        "Выберите плагин:",
        "",
    ]

    keyboard_rows = []
    for i, pl in enumerate(plugins[:10], 1):
        rating = float(getattr(pl, "rating", 0) or 0)
        downloads = int(getattr(pl, "downloads", 0) or 0)
        lines.append(f"{i}. {pl.name}  ⭐ {rating:.1f}  📥 {downloads}")
        keyboard_rows.append([
            InlineKeyboardButton(text=f"{i}. {pl.name}", callback_data=f"plugin_{pl.plugin_id}")
        ])

    keyboard_rows.append([InlineKeyboardButton(text=buttons.COMMON["back"], callback_data="browse_categories")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_rows)

    await _edit_or_send(callback_query, "\n".join(lines), reply_markup=keyboard)
    await callback_query.answer()


@router.message(lambda message: message.text == buttons.MAIN_MENU["subscriptions"])
async def menu_subscriptions(message: types.Message):
    subscriptions = db.get_user_subscriptions(message.from_user.id)
    
    if not subscriptions:
        await message.answer("🔕 У вас пока нет подписок. Подпишитесь на интересные плагины!")
        return
    
    await message.answer(f"🔔 Ваши подписки ({len(subscriptions)}):", reply_markup=create_main_menu())
    
    for plugin in subscriptions[:5]:
        text = format_plugin_preview(plugin)
        photo_id = plugin.get("photo_id")
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=f"📥 {plugin['name']}", callback_data=f"plugin_{plugin['plugin_id']}")
        ]])
        
        if photo_id:
            await message.answer_photo(photo=photo_id, caption=text, reply_markup=keyboard)
        else:
            await message.answer(text=text, reply_markup=keyboard)

@router.message(lambda message: message.text == buttons.MAIN_MENU["profile"])
async def menu_profile(message: types.Message):
    user = db.get_user(message.from_user.id)
    if not user:
        await message.answer("⚠️ Профиль не найден. Пройдите регистрацию заново.")
        return
    
    stats = db.get_user_stats(message.from_user.id)
    
    text = f"""👤 <b>Ваш профиль</b>

<b>Никнейм:</b> {user.display_name}
<b>Username:</b> @{user.username}

📊 <b>Статистика:</b>
└ Плагинов: {stats.get('plugin_count', 0)}
└ Подписчиков: {stats.get('subscribers', 0)}
└ Скачиваний: {stats.get('total_downloads', 0)}
└ Просмотров: {stats.get('total_views', 0)}
└ Средний рейтинг: {stats.get('avg_rating', 0.0)}/5.0"""
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=buttons.PROFILE["my_plugins"], callback_data="my_plugins")],
        [InlineKeyboardButton(text=buttons.PROFILE["edit_profile"], callback_data="edit_profile")],
        [InlineKeyboardButton(text=buttons.PROFILE["send_to_subscribers"], callback_data="broadcast_to_subscribers")]
    ])
    
    if user.banner_url:
        await message.answer_photo(photo=user.banner_url, caption=text, reply_markup=keyboard)
    else:
        await message.answer(text=text, reply_markup=keyboard)

@router.callback_query(F.data == "my_plugins")
async def show_my_plugins(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    plugins = db.get_user_plugins(user_id, include_archived=True)
    
    await callback_query.answer()
    
    if not plugins:
        await _edit_or_send(callback_query, "📦 У вас пока нет плагинов.")
        return
    
    active_plugins = [p for p in plugins if not p["is_archived"]]
    archived_plugins = [p for p in plugins if p["is_archived"]]
    
    text = f"📦 <b>Ваши плагины</b>\n\n<b>Активные:</b> {len(active_plugins)}\n<b>В архиве:</b> {len(archived_plugins)}"
    
    keyboard_buttons = []
    for plugin in plugins:
        status_icon = "📦" if plugin["is_archived"] else "📥"
        keyboard_buttons.append([InlineKeyboardButton(
            text=f"{status_icon} {plugin['name']}",
            callback_data=f"plugin_{plugin['plugin_id']}"
        )])
    
    keyboard_buttons.append([InlineKeyboardButton(text=buttons.COMMON["back"], callback_data="back_to_profile")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)
    
    await _edit_or_send(callback_query, text, reply_markup=keyboard)

@router.callback_query(F.data == "edit_profile")
async def edit_profile_menu(callback_query: types.CallbackQuery):
    await callback_query.answer()
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=buttons.PROFILE["edit_username"], callback_data="edit_username")],
        [InlineKeyboardButton(text=buttons.PROFILE["edit_display_name"], callback_data="edit_display_name")],
        [InlineKeyboardButton(text=buttons.PROFILE["change_banner"], callback_data="edit_banner")],
        [InlineKeyboardButton(text=buttons.COMMON["back"], callback_data="back_to_profile")]
    ])
    
    await _edit_or_send(callback_query, "✏️ Что вы хотите изменить?", reply_markup=keyboard)

@router.callback_query(F.data == "edit_username")
async def start_edit_username(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer()
    await state.set_state(ProfileEditStates.waiting_username)
    await _edit_or_send(callback_query, 
        "📝 Введите новый username (без @):",
        reply_markup=create_cancel_menu()
    )

@router.message(ProfileEditStates.waiting_username)
async def process_edit_username(message: types.Message, state: FSMContext):
    username = message.text.strip().replace("@", "")
    if len(username) < 3 or len(username) > 32:
        await message.answer("⚠️ Username должен быть от 3 до 32 символов. Попробуйте еще раз:")
        return
    
    success = db.update_user(message.from_user.id, username=username)
    await state.clear()
    
    if success:
        await message.answer("✅ Username обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка. Попробуйте позже.", reply_markup=create_main_menu())

@router.callback_query(F.data == "edit_display_name")
async def start_edit_display_name(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer()
    await state.set_state(ProfileEditStates.waiting_display_name)
    await _edit_or_send(callback_query, 
        "📛 Введите новый никнейм:",
        reply_markup=create_cancel_menu()
    )

@router.message(ProfileEditStates.waiting_display_name)
async def process_edit_display_name(message: types.Message, state: FSMContext):
    display_name = message.text.strip()
    if len(display_name) < 2 or len(display_name) > 50:
        await message.answer("⚠️ Никнейм должен быть от 2 до 50 символов. Попробуйте еще раз:")
        return
    
    success = db.update_user(message.from_user.id, display_name=display_name)
    await state.clear()
    
    if success:
        await message.answer("✅ Никнейм обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка. Попробуйте позже.", reply_markup=create_main_menu())

@router.callback_query(F.data == "edit_banner")
async def start_edit_banner(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer()
    await state.set_state(ProfileEditStates.waiting_banner)
    await _edit_or_send(callback_query, 
        "🖼 Отправьте изображение для баннера профиля:",
        reply_markup=create_cancel_menu()
    )

@router.message(ProfileEditStates.waiting_banner)
async def process_edit_banner(message: types.Message, state: FSMContext):
    if not message.photo:
        await message.answer("⚠️ Пожалуйста, отправьте изображение:")
        return
    
    photo_id = message.photo[-1].file_id
    success = db.update_user(message.from_user.id, banner_url=photo_id)
    await state.clear()
    
    if success:
        await message.answer("✅ Баннер профиля обновлен!", reply_markup=create_main_menu())
    else:
        await message.answer("⚠️ Произошла ошибка. Попробуйте позже.", reply_markup=create_main_menu())

@router.callback_query(F.data.startswith("plugin_"))
async def show_plugin_page(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("plugin_", ""))
    plugin = db.get_plugin_with_author(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return

    db.increment_views(plugin_id)

    is_author = plugin["author_id"] == callback_query.from_user.id
    is_subscribed = db.is_subscribed(callback_query.from_user.id, plugin_id)

    text = format_plugin_page_text(plugin, is_author)
    keyboard = create_plugin_menu(plugin_id, callback_query.from_user.id, is_author=is_author, is_subscribed=is_subscribed)

    await _edit_or_send(callback_query, text, reply_markup=keyboard)
    await callback_query.answer()

@router.callback_query(F.data.startswith("subscribe_"))
async def subscribe_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("subscribe_", ""))
    user_id = callback_query.from_user.id
    
    success = db.subscribe(user_id, plugin_id)
    
    if success:
        await callback_query.answer("🔔 Вы подписались на уведомления об обновлениях!")
        
        keyboard = create_plugin_menu(plugin_id, user_id, is_subscribed=True)
        try:
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
        except:
            pass
    else:
        await callback_query.answer("⚠️ Произошла ошибка.", show_alert=True)

@router.callback_query(F.data.startswith("unsubscribe_"))
async def unsubscribe_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("unsubscribe_", ""))
    user_id = callback_query.from_user.id
    
    success = db.unsubscribe(user_id, plugin_id)
    
    if success:
        await callback_query.answer("🔕 Вы отписались от уведомлений.")
        
        keyboard = create_plugin_menu(plugin_id, user_id, is_subscribed=False)
        try:
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
        except:
            pass
    else:
        await callback_query.answer("⚠️ Произошла ошибка.", show_alert=True)

@router.callback_query(F.data.startswith("rate_"))
async def rate_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("rate_", ""))
    keyboard = create_rating_menu(plugin_id)
    await _edit_or_send(callback_query, "⭐ Оцените плагин:", reply_markup=keyboard)
    await callback_query.answer()

@router.callback_query(F.data.startswith("set_rating_"))
async def set_rating(callback_query: types.CallbackQuery):
    parts = callback_query.data.split("_")
    plugin_id = int(parts[2])
    rating = int(parts[3])
    user_id = callback_query.from_user.id
    
    success = db.add_rating(plugin_id, user_id, rating)
    
    if success:
        await callback_query.answer(f"⭐ Спасибо за оценку: {rating}/5!")
        
        try:
            await callback_query.message.delete()
        except:
            pass
    else:
        await callback_query.answer("⚠️ Произошла ошибка.", show_alert=True)

@router.callback_query(F.data.startswith("author_"))
async def show_author_info(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("author_", ""))
    plugin = db.get_plugin_with_author(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return

    author_id = plugin["author_id"]
    author_plugins = db.get_user_plugins(author_id)
    author_stats = db.get_user_stats(author_id)

    text = f"""<b>{plugin['author_display_name']}</b>

👤 <b>Username:</b> @{plugin['author_username']}
👥 <b>Подписчиков:</b> {author_stats.get('subscribers', 0)}

📊 <b>Статистика плагинов:</b>
└ 📥 Всего скачиваний: {author_stats.get('total_downloads', 0)}
└ 👁 Всего просмотров: {author_stats.get('total_views', 0)}
└ ⭐ Средний рейтинг: {author_stats.get('avg_rating', 0.0)}/5.0

📦 <b>Плагины автора:</b>"""

    keyboard_buttons = []
    for author_plugin in author_plugins[:5]:
        keyboard_buttons.append([InlineKeyboardButton(
            text=f"📥 {author_plugin['name']}",
            callback_data=f"plugin_{author_plugin['plugin_id']}"
        )])

    keyboard_buttons.append([InlineKeyboardButton(text=buttons.COMMON["back"], callback_data=f"back_to_plugin_{plugin_id}")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)

    await _edit_or_send(callback_query, text, reply_markup=keyboard)
    await callback_query.answer()

@router.callback_query(F.data.startswith("reviews_"))
async def show_reviews(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("reviews_", ""))
    plugin = db.get_plugin_with_author(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    text = f"""💬 <b>Отзывы о плагине "{plugin['name']}"</b>

⭐ <b>Рейтинг:</b> {plugin['rating']:.1f}/5.0
📊 <b>Оценок:</b> {plugin['rating_count']}

"""
    
    if plugin["rating_count"] == 0:
        text += "😔 Пока нет оценок. Будьте первым!"
    else:
        with db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT rating, COUNT(*) as count 
                FROM ratings 
                WHERE plugin_id = ? 
                GROUP BY rating 
                ORDER BY rating DESC
            """, (plugin_id,))
            
            ratings = cursor.fetchall()
            for rating, count in ratings:
                bar = "█" * min(count, 10)
                text += f"{rating}⭐ {bar} {count}\n"
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=buttons.COMMON["back"], callback_data=f"back_to_plugin_{plugin_id}")
    ]])
    
    await _edit_or_send(callback_query, text, reply_markup=keyboard)
    await callback_query.answer()

@router.callback_query(F.data.startswith("manage_"))
async def manage_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("manage_", ""))
    plugin = db.get_plugin(plugin_id)
    
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in [7188906494]
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    keyboard = create_manage_menu(plugin_id, plugin.is_archived)
    await _edit_or_send(callback_query, "⚙️ Управление плагином:", reply_markup=keyboard)
    await callback_query.answer()

@router.callback_query(F.data.startswith("archive_"))
async def archive_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("archive_", ""))
    
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in [7188906494]
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.update_plugin(plugin_id, is_archived=True)
    
    if success:
        await callback_query.answer("📦 Плагин перемещен в архив.")
        
        keyboard = create_manage_menu(plugin_id, True)
        try:
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при архивировании.", show_alert=True)

@router.callback_query(F.data.startswith("restore_"))
async def restore_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("restore_", ""))
    
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in [7188906494]
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.update_plugin(plugin_id, is_archived=False)
    
    if success:
        await callback_query.answer("📂 Плагин восстановлен из архива.")
        
        keyboard = create_manage_menu(plugin_id, False)
        try:
            await callback_query.message.edit_reply_markup(reply_markup=keyboard)
        except:
            pass
    else:
        await callback_query.answer("⚠️ Ошибка при восстановлении.", show_alert=True)

@router.callback_query(F.data.startswith("delete_"))
async def delete_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("delete_", ""))
    
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    is_author = plugin.author_id == callback_query.from_user.id
    is_admin = callback_query.from_user.id in [7188906494]
    
    if not (is_author or is_admin):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    success = db.delete_plugin(plugin_id)
    
    if success:
        await callback_query.answer("🗑 Плагин удален.")
        await callback_query.message.delete()
    else:
        await callback_query.answer("⚠️ Ошибка при удалении.", show_alert=True)

@router.callback_query(F.data.startswith("update_"))
async def update_plugin(callback_query: types.CallbackQuery, state: FSMContext):
    plugin_id = int(callback_query.data.replace("update_", ""))
    
    plugin = db.get_plugin(plugin_id)
    if not plugin:
        await callback_query.answer(MESSAGES["plugin_not_found"], show_alert=True)
        return
    
    if plugin.author_id != callback_query.from_user.id:
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    await state.set_state(UploadStates.waiting_file)
    await state.update_data(update_plugin_id=plugin_id)
    await _edit_or_send(callback_query, 
        "📤 Отправьте новую версию файла плагина:",
        reply_markup=create_cancel_menu()
    )
    await callback_query.answer()

@router.callback_query(F.data.startswith("back_to_plugin_"))
async def back_to_plugin(callback_query: types.CallbackQuery):
    plugin_id = int(callback_query.data.replace("back_to_plugin_", ""))
    await show_plugin_page(callback_query)

@router.callback_query(F.data == "back_to_profile")
async def back_to_profile(callback_query: types.CallbackQuery):
    await callback_query.answer()
    await menu_profile(callback_query.message)

@router.callback_query(F.data == "broadcast_to_subscribers")
async def broadcast_to_subscribers(callback_query: types.CallbackQuery, state: FSMContext):
    user = db.get_user(callback_query.from_user.id)
    if not user or user.subscribers == 0:
        await callback_query.answer("⚠️ У вас нет подписчиков.", show_alert=True)
        return
    
    await state.set_state(BroadcastStates.waiting_message)
    await _edit_or_send(callback_query, 
        "📢 Отправьте сообщение для ваших подписчиков:",
        reply_markup=create_cancel_menu()
    )
    await callback_query.answer()

@router.message(BroadcastStates.waiting_message)
async def process_subscriber_broadcast(message: types.Message, state: FSMContext):
    user = db.get_user(message.from_user.id)
    if not user or user.subscribers == 0:
        await message.answer("⚠️ У вас нет подписчиков.", reply_markup=create_main_menu())
        await state.clear()
        return
    
    subscribers = db.get_plugin_subscribers(user.user_id)
    
    success_count = 0
    fail_count = 0
    
    for subscriber_id in subscribers:
        try:
            if message.photo:
                await message.bot.send_photo(subscriber_id, message.photo[-1].file_id, caption=message.caption)
            elif message.text:
                await message.bot.send_message(subscriber_id, message.text)
            success_count += 1
            await asyncio.sleep(0.1)
        except:
            fail_count += 1
    
    await state.clear()
    await message.answer(
        f"✅ Сообщение отправлено {success_count} подписчикам! (Не удалось: {fail_count})",
        reply_markup=create_main_menu()
    )

@router.callback_query(F.data == "menu")
async def back_to_menu(callback_query: types.CallbackQuery):
    await callback_query.answer(MESSAGES["back_to_menu"])
    await _edit_or_send(callback_query, MESSAGES["start"], reply_markup=create_main_menu())

@router.callback_query(F.data == "cancel")
async def cancel_callback(callback_query: types.CallbackQuery):
    await callback_query.answer()
    await callback_query.message.delete()

@router.message(lambda message: message.text == buttons.COMMON["cancel"])
async def cancel_action(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer(MESSAGES["cancelled"], reply_markup=create_main_menu())

@router.callback_query(F.data == "noop")
async def noop(callback_query: types.CallbackQuery):
    await callback_query.answer()
