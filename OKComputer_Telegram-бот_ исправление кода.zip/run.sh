#!/bin/bash

# Скрипт для запуска Exteragram Plugin Library Bot

echo "🚀 Exteragram Plugin Library Bot"
echo "==============================="

# Проверка Python
echo -n "Проверка Python... "
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo "✅ $PYTHON_VERSION"
else
    echo "❌ Python3 не найден"
    exit 1
fi

# Проверка виртуального окружения
if [ -d "venv" ]; then
    echo "📦 Активация виртуального окружения..."
    source venv/bin/activate
else
    echo "⚠️  Виртуальное окружение не найдено"
    echo "📦 Создание виртуального окружения..."
    python3 -m venv venv
    source venv/bin/activate
    echo "📥 Установка зависимостей..."
    pip install -r requirements.txt
fi

# Проверка .env файла
if [ ! -f ".env" ]; then
    echo "⚠️  Файл .env не найден"
    echo "📋 Создайте файл .env на основе .env.example"
    echo "cp .env.example .env"
    echo "и отредактируйте его"
    exit 1
fi

# Проверка директории data
if [ ! -d "data" ]; then
    echo "📁 Создание директории data..."
    mkdir -p data
fi

# Запуск тестов
echo ""
echo "🧪 Запуск тестирования..."
python3 test_bot.py

TEST_RESULT=$?

if [ $TEST_RESULT -ne 0 ]; then
    echo "❌ Тесты не пройдены. Исправьте ошибки перед запуском."
    exit 1
fi

echo ""
echo "🚀 Запуск бота..."
echo "Для остановки нажмите Ctrl+C"
echo ""

python3 bot.py
