import os
from dotenv import load_dotenv

load_dotenv()

# Bot Configuration
# Токен и IDs читаются из .env (или переменных окружения). В репозитории держим плейсхолдер.
BOT_TOKEN = (os.getenv("BOT_TOKEN") or "").strip() or "YOUR_BOT_TOKEN_HERE"

# ADMIN_IDS можно задавать списком через запятую, например: "123,456"
_admin_ids_raw = (os.getenv("ADMIN_IDS") or "").strip()
ADMIN_IDS = [int(x) for x in _admin_ids_raw.split(",") if x.strip().lstrip("-").isdigit()]
ADMIN_GROUP_ID = int((os.getenv("ADMIN_GROUP_ID") or "0").strip() or "0")

# Topic IDs for admin group
TOPIC_SUBMISSIONS = int((os.getenv("TOPIC_SUBMISSIONS") or "0").strip() or "0")
TOPIC_STORAGE = int((os.getenv("TOPIC_STORAGE") or "0").strip() or "0")
TOPIC_SECURITY = int((os.getenv("TOPIC_SECURITY") or "0").strip() or "0")

# Database
DATABASE_PATH = "data/bot.db"

# File storage
PLUGIN_STORAGE_PATH = "data/plugins"
PHOTO_STORAGE_PATH = "data/photos"

# Search settings
MAX_SEARCH_RESULTS = 10
SIMILARITY_THRESHOLD = 0.3

# Pagination
PLUGINS_PER_PAGE = 5

# Rating settings
MIN_RATING = 1
MAX_RATING = 5

# Development statuses
DEV_STATUSES = {
    "in_progress": "🔧 В работе",
    "updates_possible": "🔄 Возможны обновления", 
    "completed": "✅ Завершено"
}

# Plugin categories
CATEGORIES = {
    "tools": "🔧 Инструменты",
    "fun": "🎉 Веселье",
    "bots": "🤖 Боты",
    "security": "🔒 Безопасность",
    "integrations": "🔗 Интеграции"
}

# Messages
MESSAGES = {
    "start": "🎉 Добро пожаловать в библиотеку плагинов Exteragram!\n\nВыберите действие из меню ниже:",
    "registration_required": "⚠️ Для использования бота необходимо пройти регистрацию.\n\nВведите ваш никнейм:",
    "registration_username": "Отлично! Теперь введите ваш @username (без @):",
    "registration_complete": "✅ Регистрация завершена! Добро пожаловать в библиотеку!",
    "search_prompt": "🔍 Введите название/автора либо просто опишите плагин - я найду вам самый подходящий!",
    "search_no_results": "😔 К сожалению, по вашему запросу ничего не найдено. Попробуйте переформулировать.",
    "upload_step1": "[1/5] 📎 Пожалуйста, загрузите файл плагина (мы сразу же отправим на модерацию)",
    "upload_step2": "[2/5] ✏️ Отправьте название плагина и вместе с ним загрузите фото для обложки (можно без обложки)",
    "upload_step3": "[3/5] 📂 Выберите категорию плагина:",
    "upload_step4": "[4/5] 📊 Укажите статус разработки:",
    "upload_step5": "[5/5] 🏷 Пожалуйста, введите теги. Каждое слово через пробел - отдельный тег.",
    "upload_complete": "✅ Отлично! Ваша заявка отправлена на модерацию. Ожидайте решения.",
    "upload_file_replace": "📎 Отправьте другой файл, если хотите заменить предыдущий.",
    "subscription_on": "🔔 Вы подписались на уведомления об обновлениях!",
    "subscription_off": "🔕 Вы отписались от уведомлений.",
    "plugin_approved": "✅ Ваш плагин '{name}' одобрен и добавлен в библиотеку!",
    "plugin_rejected": "❌ Ваш плагин '{name}' отклонен. Причина: {reason}\n\nСвяжитесь с поддержкой для уточнений.",
    "plugin_updated": "🔄 Плагин '{name}' обновлен!",
    "plugin_archived": "📦 Плагин перемещен в архив.",
    "plugin_restored": "📂 Плагин восстановлен из архива.",
    "plugin_deleted": "🗑 Плагин удален.",
    "update_available": "🔄 Доступно обновление для плагина '{name}'!",
    "moderation_required": "⚠️ Требуется модерация плагина",
    "back_to_menu": "🏠 Возвращаемся в главное меню...",
    "cancelled": "❌ Действие отменено",
    "invalid_input": "⚠️ Неверный ввод. Попробуйте еще раз.",
    "try_again": "🔄 Попробуйте еще раз",
    "confirm_action": "Подтвердите действие",
    "yes": "✅ Да",
    "no": "❌ Нет",
    "unknown_error": "😞 Произошла ошибка. Попробуйте позже или обратитесь в поддержку.",
    "plugin_not_found": "🔍 Плагин не найден",
    "access_denied": "🚫 Доступ запрещен",
    "admin_only": "⚠️ Эта функция доступна только администраторам"
}