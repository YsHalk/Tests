"""
МОДУЛЬ КНОПОК - ЛЕГКО РЕДАКТИРОВАТЬ ДАЖЕ 5-ЛЕТНЕМУ РЕБЕНКУ :)

Здесь собраны ВСЕ кнопки бота. Чтобы изменить текст кнопки - просто поменяйте значение.
Чтобы добавить новую кнопку - скопируйте шаблон и измените.

Формат:
    "код_кнопки": "Текст кнопки"

Код кнопки используется в коде бота, текст - то, что видит пользователь.
"""

# ========== ГЛАВНОЕ МЕНЮ (Reply Keyboard) ==========
MAIN_MENU = {
    "search": "🔍 Найти",
    "upload": "📤 Загрузить",
    "popular": "⭐ Популярное",
    "categories": "📂 Категории",
    "subscriptions": "🔔 Подписки",
    "profile": "👤 Мой профиль"
}

# ========== ОБЩИЕ КНОПКИ ==========
COMMON = {
    "back": "⬅️ Назад",
    "cancel": "❌ Отмена",
    "menu": "🏠 Меню",
    "confirm": "✅ Подтвердить",
    "yes": "✅ Да",
    "no": "❌ Нет",
    "close": "🚪 Закрыть",
    "skip": "⏭ Пропустить",
    "try_again": "🔄 Попробовать снова"
}

# ========== ПОИСК ==========
SEARCH = {
    "search_again": "🔍 Новый поиск",
    "show_all": "📋 Показать все"
}

# ========== СТРАНИЦА ПЛАГИНА (Inline) ==========
PLUGIN_PAGE = {
    "download": "📥 Скачать",
    "subscribe": "🔔 Подписаться",
    "unsubscribe": "🔕 Отписаться",
    "author": "👤 Автор",
    "reviews": "💬 Отзывы",
    "rate": "⭐ Оценить",
    "manage": "⚙️ Управление",
    "update": "🔄 Обновить",
    "archive": "📦 В архив",
    "restore": "📂 Вернуть",
    "delete": "🗑 Удалить"
}

# ========== ОЦЕНКА ==========
RATING = {
    "rate_1": "⭐",
    "rate_2": "⭐⭐",
    "rate_3": "⭐⭐⭐",
    "rate_4": "⭐⭐⭐⭐",
    "rate_5": "⭐⭐⭐⭐⭐"
}

# ========== КАТЕГОРИИ ==========
CATEGORIES = {
    "tools": "🔧 Инструменты",
    "fun": "🎉 Веселье",
    "bots": "🤖 Боты",
    "security": "🔒 Безопасность",
    "integrations": "🔗 Интеграции"
}

# ========== СТАТУСЫ РАЗРАБОТКИ ==========
DEV_STATUSES = {
    "in_progress": "🔧 В работе",
    "updates_possible": "🔄 Возможны обновления",
    "completed": "✅ Завершено"
}

# ========== ЗАГРУЗКА ПЛАГИНА ==========
UPLOAD = {
    "continue": "➡️ Продолжить",
    "replace_file": "🔄 Заменить файл",
    "select_category": "📂 Выбрать категорию",
    "select_status": "📊 Выбрать статус"
}

# ========== ПРОФИЛЬ ==========
PROFILE = {
    "my_plugins": "📦 Мои плагины",
    "edit_profile": "✏️ Изменить профиль",
    "edit_username": "📝 Изменить никнейм",
    "edit_display_name": "📛 Изменить отображаемое имя",
    "add_banner": "🖼 Добавить баннер",
    "change_banner": "🖼 Изменить баннер",
    "send_to_subscribers": "📢 Отправить подписчикам",
    "view_subscribers": "👥 Подписчики"
}

# ========== АДМИНИСТРИРОВАНИЕ ==========
ADMIN = {
    "approve": "✅ Одобрить",
    "reject": "❌ Отклонить",
    "edit": "✏️ Изменить",
    "ban_user": "🚫 Забанить",
    "view_submission": "📋 Посмотреть заявку",
    "moderation": "⚖️ Модерация",
    "pending_submissions": "📋 Заявки на загрузку",
    "pending_updates": "🔄 Заявки на обновление",
    "broadcast": "📢 Рассылка",
    "stats": "📊 Статистика"
}

# ========== ПАГИНАЦИЯ ==========
PAGINATION = {
    "prev": "◀️ Предыдущая",
    "next": "▶️ Следующая",
    "page_info": "📄 {current}/{total}"
}

# ========== СПИСОК ВСЕХ КНОПОК (для проверки дубликатов) ==========
ALL_BUTTONS = {}

for category in [MAIN_MENU, COMMON, SEARCH, PLUGIN_PAGE, RATING, CATEGORIES, 
                DEV_STATUSES, UPLOAD, PROFILE, ADMIN, PAGINATION]:
    ALL_BUTTONS.update(category)

def get_button_text(button_code: str) -> str:
    return ALL_BUTTONS.get(button_code, button_code)

def get_button_code(button_text: str) -> Optional[str]:
    for code, text in ALL_BUTTONS.items():
        if text == button_text:
            return code
    return None
