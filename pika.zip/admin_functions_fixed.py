import os
from typing import Dict, List, Optional, Any
from aiogram import types, F, Router, Bot
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardMarkup,
    KeyboardButton,
)
from datetime import datetime
import asyncio

from buttons import (
    COMMON, CATEGORIES, DEV_STATUSES, ADMIN
)
from database import Database, Plugin
from config import (
    DATABASE_PATH,
    ADMIN_IDS,
    ADMIN_GROUP_ID,
    TOPIC_SUBMISSIONS,
    TOPIC_STORAGE,
    TOPIC_SECURITY,
    MESSAGES,
    CATEGORIES as CATEGORIES_CONFIG,
    DEV_STATUSES as DEV_STATUSES_CONFIG,
)

db = Database(DATABASE_PATH)
router = Router()

async def _edit_or_send(callback_query: types.CallbackQuery, text: str, reply_markup=None):
    """Для inline-кнопок: редактируем текущее сообщение, иначе шлём новое."""
    msg = callback_query.message
    try:
        await msg.edit_text(text, reply_markup=reply_markup)
    except Exception:
        await msg.answer(text, reply_markup=reply_markup)


class EditSubmissionStates(StatesGroup):
    waiting_field = State()
    waiting_value = State()

class BroadcastStates(StatesGroup):
    waiting_message = State()

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

def create_admin_menu() -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=ADMIN["pending_submissions"], callback_data="admin_submissions")],
        [InlineKeyboardButton(text=ADMIN["pending_updates"], callback_data="admin_updates")],
        [InlineKeyboardButton(text=ADMIN["broadcast"], callback_data="admin_broadcast")],
        [InlineKeyboardButton(text=ADMIN["stats"], callback_data="admin_stats")]
    ])
    return keyboard

def create_submission_review_menu(submission_id: int) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=ADMIN["approve"], callback_data=f"approve_sub_{submission_id}"),
            InlineKeyboardButton(text=ADMIN["edit"], callback_data=f"edit_sub_{submission_id}"),
            InlineKeyboardButton(text=ADMIN["reject"], callback_data=f"reject_sub_{submission_id}")
        ]
    ])
    return keyboard

def create_update_review_menu(update_id: int) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=ADMIN["approve"], callback_data=f"approve_upd_{update_id}"),
            InlineKeyboardButton(text=ADMIN["reject"], callback_data=f"reject_upd_{update_id}")
        ]
    ])
    return keyboard

def create_edit_field_menu(submission_id: int) -> InlineKeyboardMarkup:
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Название", callback_data=f"edit_field_{submission_id}_name")],
        [InlineKeyboardButton(text="Описание", callback_data=f"edit_field_{submission_id}_description")],
        [InlineKeyboardButton(text="Категория", callback_data=f"edit_field_{submission_id}_category")],
        [InlineKeyboardButton(text="Статус", callback_data=f"edit_field_{submission_id}_status")],
        [InlineKeyboardButton(text="Теги", callback_data=f"edit_field_{submission_id}_tags")],
        [InlineKeyboardButton(text="✅ Сохранить", callback_data=f"save_changes_{submission_id}")],
        [InlineKeyboardButton(text=COMMON["back"], callback_data=f"back_to_sub_{submission_id}")]
    ])
    return keyboard

def create_category_selection_menu(submission_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, value in CATEGORIES.items():
        builder.button(text=value, callback_data=f"select_category_{submission_id}_{key}")
    builder.button(text=COMMON["back"], callback_data=f"edit_field_{submission_id}_category")
    builder.adjust(1)
    return builder.as_markup()

def create_status_selection_menu(submission_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for key, value in DEV_STATUSES.items():
        builder.button(text=value, callback_data=f"select_status_{submission_id}_{key}")
    builder.button(text=COMMON["back"], callback_data=f"edit_field_{submission_id}_status")
    builder.adjust(1)
    return builder.as_markup()

async def send_to_topic(bot: Bot, topic_id: int, text: str, file_id: str = None, 
                       reply_markup: InlineKeyboardMarkup = None) -> Optional[int]:
    try:
        if not ADMIN_GROUP_ID:
            return None

        if file_id:
            kwargs = dict(chat_id=ADMIN_GROUP_ID, document=file_id, caption=text, reply_markup=reply_markup)
            if topic_id:
                kwargs["message_thread_id"] = topic_id
            message = await bot.send_document(**kwargs)
        else:
            kwargs = dict(chat_id=ADMIN_GROUP_ID, text=text, reply_markup=reply_markup)
            if topic_id:
                kwargs["message_thread_id"] = topic_id
            message = await bot.send_message(**kwargs)
        return message.message_id
    except Exception as e:
        print(f"Error sending to topic: {e}")
        return None


def format_submission_message(sub: Dict[str, Any]) -> str:
    return (
        "📥 <b>Новая заявка на загрузку</b>\n\n"
        f"<b>ID:</b> {sub.get('submission_id')}\n"
        f"<b>Плагин:</b> {sub.get('plugin_name')}\n"
        f"<b>Автор:</b> @{sub.get('username')} ({sub.get('display_name')})\n"
        f"<b>Категория:</b> {CATEGORIES.get(sub.get('category'), sub.get('category'))}\n"
        f"<b>Статус:</b> {DEV_STATUSES.get(sub.get('status'), sub.get('status'))}\n"
        f"<b>Теги:</b> {sub.get('tags', '')}\n\n"
        f"<b>Описание:</b> {sub.get('description', '')}"
    )


def format_update_message(upd: Dict[str, Any]) -> str:
    return (
        "🔄 <b>Заявка на обновление</b>\n\n"
        f"<b>ID:</b> {upd.get('update_id')}\n"
        f"<b>Плагин:</b> {upd.get('plugin_name')}\n"
        f"<b>Автор:</b> @{upd.get('username')} ({upd.get('display_name')})\n\n"
        f"<b>Описание обновления:</b> {upd.get('description', '') or '—'}"
    )


async def notify_admins_about_submission(bot: Bot, submission_data: Dict[str, Any]):
    """Уведомляет админов о новой заявке."""
    # 1) файл — в тему безопасности
    await send_to_topic(
        bot,
        TOPIC_SECURITY,
        f"🔒 <b>Файл для проверки</b>\n\n{submission_data.get('plugin_name')}",
        file_id=submission_data.get("file_id"),
    )
    # 2) карточка заявки — в тему заявок
    await send_to_topic(
        bot,
        TOPIC_SUBMISSIONS,
        format_submission_message(submission_data),
        reply_markup=create_submission_review_menu(submission_data["submission_id"]),
    )


async def notify_admins_about_update(bot: Bot, update_data: Dict[str, Any]):
    """Уведомляет админов о заявке на обновление."""
    await send_to_topic(
        bot,
        TOPIC_SECURITY,
        f"🔒 <b>Файл обновления для проверки</b>\n\n{update_data.get('plugin_name')}",
        file_id=update_data.get("file_id"),
    )
    await send_to_topic(
        bot,
        TOPIC_SUBMISSIONS,
        format_update_message(update_data),
        reply_markup=create_update_review_menu(update_data["update_id"]),
    )


async def notify_author_subscribers_about_new_plugin(bot: Bot, plugin_id: int, author_id: int):
    """Уведомляет подписчиков автора о новом плагине"""
    try:
        plugin = db.get_plugin_with_author(plugin_id)
        if not plugin:
            return
        
        subscribers = db.get_author_subscribers(author_id)
        
        for subscriber_id in subscribers:
            try:
                text = f"""🎉 <b>Новый плагин от автора!</b>

Автор <b>{plugin['author_display_name']}</b> (@{plugin['author_username']}) опубликовал новый плагин!

<b>Плагин:</b> {plugin['name']}
<b>Категория:</b> {CATEGORIES.get(plugin['category'], plugin['category'])}
<b>Описание:</b> {plugin['description'][:100]}..."""
                
                keyboard = InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="📥 Перейти к плагину", callback_data=f"plugin_{plugin_id}")]
                ])
                
                await bot.send_message(subscriber_id, text, reply_markup=keyboard)
                await asyncio.sleep(0.1)
            except:
                pass
    except Exception as e:
        print(f"Error notifying author subscribers: {e}")


@router.callback_query(F.data == "admin_submissions")
async def admin_submissions(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    pending = db.get_pending_submissions()
    if not pending:
        await _edit_or_send(callback_query, "✅ Нет заявок на загрузку в ожидании.", reply_markup=create_admin_menu())
        await callback_query.answer()
        return

    text = "📥 <b>Ожидающие заявки</b>\n\n" + "\n".join(
        [f"• <b>{s['submission_id']}</b>: {s['plugin_name']} (@{s['username']})" for s in pending[:20]]
    )
    await _edit_or_send(callback_query, text, reply_markup=create_admin_menu())
    await callback_query.answer()


@router.callback_query(F.data == "admin_updates")
async def admin_updates(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    pending = db.get_pending_updates()
    if not pending:
        await _edit_or_send(callback_query, "✅ Нет заявок на обновление в ожидании.", reply_markup=create_admin_menu())
        await callback_query.answer()
        return

    text = "🔄 <b>Ожидающие обновления</b>\n\n" + "\n".join(
        [f"• <b>{u['update_id']}</b>: {u['plugin_name']} (@{u['username']})" for u in pending[:20]]
    )
    await _edit_or_send(callback_query, text, reply_markup=create_admin_menu())
    await callback_query.answer()


@router.callback_query(F.data.startswith("approve_sub_"))
async def approve_submission(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    submission_id = int(callback_query.data.replace("approve_sub_", ""))
    sub = db.get_submission(submission_id)
    if not sub:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return

    plugin = Plugin(
        plugin_id=0,
        name=sub["plugin_name"],
        description=sub["description"],
        file_id=sub["file_id"],
        file_name=sub["file_name"],
        file_size=sub["file_size"],
        photo_id=sub.get("photo_id"),
        author_id=sub["user_id"],
        category=sub["category"],
        status=sub["status"],
        tags=sub.get("tags", ""),
    )

    plugin_id = db.create_plugin(plugin)
    if not plugin_id:
        await callback_query.answer("Ошибка при публикации", show_alert=True)
        return

    db.update_submission(submission_id, state="approved")

    # уведомление автору
    try:
        await callback_query.bot.send_message(
            sub["user_id"],
            MESSAGES["plugin_approved"].format(name=sub["plugin_name"]),
        )
    except Exception:
        pass

    # Уведомляем подписчиков автора о новом плагине
    await notify_author_subscribers_about_new_plugin(callback_query.bot, plugin_id, sub["user_id"])

    await callback_query.answer("✅ Одобрено")
    try:
        await callback_query.message.edit_text(
            f"✅ <b>Заявка одобрена</b>\n\nID: {submission_id}\nПлагин: {sub['plugin_name']}\nОпубликовал: @{callback_query.from_user.username}",
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("reject_sub_"))
async def reject_submission(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    submission_id = int(callback_query.data.replace("reject_sub_", ""))
    sub = db.get_submission(submission_id)
    if not sub:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return

    db.update_submission(submission_id, state="rejected")
    try:
        await callback_query.bot.send_message(
            sub["user_id"],
            MESSAGES["plugin_rejected"].format(name=sub["plugin_name"], reason="без указания причины"),
        )
    except Exception:
        pass

    await callback_query.answer("❌ Отклонено")
    try:
        await callback_query.message.edit_text(
            f"❌ <b>Заявка отклонена</b>\n\nID: {submission_id}\nПлагин: {sub['plugin_name']}\nОтклонил: @{callback_query.from_user.username}",
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("edit_sub_"))
async def edit_submission(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    submission_id = int(callback_query.data.replace("edit_sub_", ""))
    sub = db.get_submission(submission_id)
    if not sub:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return

    await state.update_data(submission_id=submission_id)
    await _edit_or_send(callback_query, "✏️ Что изменить?", reply_markup=create_edit_field_menu(submission_id))
    await callback_query.answer()


@router.callback_query(F.data.startswith("edit_field_"))
async def edit_submission_field(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    parts = callback_query.data.split("_")
    submission_id = int(parts[2])
    field = parts[3]
    
    await state.update_data(submission_id=submission_id, field=field)
    
    if field == "category":
        keyboard = create_category_selection_menu(submission_id)
        await _edit_or_send(callback_query, "📂 Выберите категорию:", reply_markup=keyboard)
    elif field == "status":
        keyboard = create_status_selection_menu(submission_id)
        await _edit_or_send(callback_query, "📊 Выберите статус:", reply_markup=keyboard)
    else:
        await state.set_state(EditSubmissionStates.waiting_value)
        field_names = {
            "name": "название",
            "description": "описание",
            "tags": "теги"
        }
        await _edit_or_send(callback_query, f"Отправьте новое {field_names.get(field, field)}:")
    
    await callback_query.answer()


@router.callback_query(F.data.startswith("select_category_"))
async def select_category(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    parts = callback_query.data.split("_")
    submission_id = int(parts[2])
    category = "_".join(parts[3:])
    
    db.update_submission(submission_id, category=category)
    
    await callback_query.answer("✅ Категория обновлена!")
    await _edit_or_send(callback_query, "✏️ Что изменить?", reply_markup=create_edit_field_menu(submission_id))


@router.callback_query(F.data.startswith("select_status_"))
async def select_status(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    parts = callback_query.data.split("_")
    submission_id = int(parts[2])
    status = "_".join(parts[3:])
    
    db.update_submission(submission_id, status=status)
    
    await callback_query.answer("✅ Статус обновлен!")
    await _edit_or_send(callback_query, "✏️ Что изменить?", reply_markup=create_edit_field_menu(submission_id))


@router.message(EditSubmissionStates.waiting_value)
async def save_edited_field(message: types.Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["access_denied"])
        return
    
    data = await state.get_data()
    submission_id = data["submission_id"]
    field = data["field"]
    
    submission = db.get_submission(submission_id)
    if not submission:
        await message.answer("Заявка не найдена")
        await state.clear()
        return
    
    new_value = (message.text or "").strip()

    field_map = {
        "name": "plugin_name",
        "description": "description",
        "tags": "tags",
    }
    db_field = field_map.get(field)
    if not db_field:
        await message.answer("Неизвестное поле для редактирования")
        await state.clear()
        return
    
    if field == "name" and (len(new_value) < 2 or len(new_value) > 100):
        await message.answer("Название должно быть от 2 до 100 символов")
        return
    
    db.update_submission(submission_id, **{db_field: new_value})

    # Уведомляем автора (без inline подтверждения — callback_data имеет жесткий лимит 64 байта)
    try:
        await message.bot.send_message(
            submission["user_id"],
            "⚠️ <b>Ваша заявка была отредактирована модератором</b>\n\n"
            f"<b>Плагин:</b> {submission['plugin_name']}\n"
            f"<b>Изменено:</b> {db_field}\n"
            f"<b>Новое значение:</b> {new_value}\n\n"
            "После проверки заявка будет одобрена или отклонена.",
        )
    except Exception:
        pass

    await message.answer("✅ Значение обновлено!")
    
    # Возвращаемся к меню редактирования
    keyboard = create_edit_field_menu(submission_id)
    await message.answer("✏️ Что еще изменить?", reply_markup=keyboard)
    
    await state.clear()


@router.callback_query(F.data.startswith("save_changes_"))
async def save_changes(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return

    submission_id = int(callback_query.data.replace("save_changes_", ""))
    sub = db.get_submission(submission_id)
    if not sub:
        await callback_query.answer("Заявка не найдена", show_alert=True)
        return

    await callback_query.answer("✅ Изменения сохранены!")
    await _edit_or_send(callback_query, format_submission_message(sub), 
                       reply_markup=create_submission_review_menu(submission_id))


@router.callback_query(F.data == "admin_broadcast")
async def admin_broadcast(callback_query: types.CallbackQuery, state: FSMContext):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    await state.set_state(BroadcastStates.waiting_message)
    await _edit_or_send(callback_query, 
        "Отправьте сообщение для рассылки всем пользователям:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=COMMON["cancel"], callback_data="cancel_admin_broadcast")
        ]])
    )
    await callback_query.answer()


@router.message(BroadcastStates.waiting_message)
async def process_broadcast(message:
    from user_functions import create_main_menu
 types.Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await message.answer(MESSAGES["access_denied"])
        return
    
    with db._get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM users")
        users = [row[0] for row in cursor.fetchall()]
    
    success_count = 0
    fail_count = 0
    
    for user_id in users:
        try:
            if message.photo:
                await message.bot.send_photo(user_id, message.photo[-1].file_id, caption=message.caption)
            elif message.video:
                await message.bot.send_video(user_id, message.video.file_id, caption=message.caption)
            elif message.document:
                await message.bot.send_document(user_id, message.document.file_id, caption=message.caption)
            else:
                await message.bot.send_message(user_id, message.text)
            success_count += 1
            await asyncio.sleep(0.1)
        except:
            fail_count += 1
    
    await state.clear()
    await message.answer(
        f"✅ Рассылка завершена\n\nУспешно: {success_count}\nНе удалось: {fail_count}",
        reply_markup=create_main_menu()
    )


@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    with db._get_connection() as conn:
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM plugins WHERE is_archived = 0")
        total_plugins = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM plugins WHERE is_archived = 1")
        archived_plugins = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(downloads) FROM plugins")
        total_downloads = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT SUM(views) FROM plugins")
        total_views = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT COUNT(*) FROM submissions WHERE state = 'pending'")
        pending_submissions = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM updates WHERE state = 'pending'")
        pending_updates = cursor.fetchone()[0]
    
    text = f"""📊 <b>Статистика библиотеки</b>

👥 <b>Пользователи:</b> {total_users}
📦 <b>Плагины:</b> {total_plugins} (в архиве: {archived_plugins})
📥 <b>Скачиваний:</b> {total_downloads}
👁 <b>Просмотров:</b> {total_views}

⚠️ <b>На модерации:</b>
└ Заявки на загрузку: {pending_submissions}
└ Заявки на обновление: {pending_updates}"""
    
    await _edit_or_send(callback_query, text)
    await callback_query.answer()


@router.callback_query(F.data.startswith("approve_upd_"))
async def approve_update(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    update_id = int(callback_query.data.replace("approve_upd_", ""))
    update_req = db.get_update_request(update_id)
    if not update_req:
        await callback_query.answer("Обновление не найдено", show_alert=True)
        return
    
    success = db.update_plugin(
        update_req["plugin_id"],
        file_id=update_req["file_id"],
        file_name=update_req["file_name"]
    )
    
    if not success:
        await callback_query.answer("Ошибка при обновлении плагина", show_alert=True)
        return
    
    db.update_update_request(update_id, state="approved")
    
    subscribers = db.get_plugin_subscribers(update_req["plugin_id"])
    plugin = db.get_plugin(update_req["plugin_id"])
    
    for subscriber_id in subscribers:
        try:
            text = f"""🔄 <b>Обновление плагина!</b>

Плагин "<b>{plugin.name}</b>" получил обновление!

<b>Автор:</b> @{update_req['username']}
<b>Описание обновления:</b> {update_req.get('description', 'Без описания')}"""
            
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="📥 Перейти к плагину", callback_data=f"plugin_{plugin.plugin_id}")]
            ])
            
            await callback_query.bot.send_message(subscriber_id, text, reply_markup=keyboard)
            await asyncio.sleep(0.1)
        except:
            pass
    
    try:
        await callback_query.bot.send_message(
            update_req["user_id"],
            f"✅ Обновление плагина '{plugin.name}' одобрено и опубликовано!"
        )
    except:
        pass
    
    await callback_query.answer("✅ Обновление одобрено!")
    
    text = f"""✅ <b>Обновление одобрено</b>

<b>ID:</b> {update_id}
<b>Плагин:</b> {plugin.name}
<b>Автор:</b> @{update_req['username']}
<b>Одобрил:</b> @{callback_query.from_user.username}"""
    
    try:
        await callback_query.message.edit_text(text=text)
    except:
        pass


@router.callback_query(F.data.startswith("reject_upd_"))
async def reject_update(callback_query: types.CallbackQuery):
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer(MESSAGES["access_denied"], show_alert=True)
        return
    
    update_id = int(callback_query.data.replace("reject_upd_", ""))
    update_req = db.get_update_request(update_id)
    if not update_req:
        await callback_query.answer("Обновление не найдено", show_alert=True)
        return
    
    db.update_update_request(update_id, state="rejected")
    
    try:
        await callback_query.bot.send_message(
            update_req["user_id"],
            f"❌ Обновление плагина '{update_req['plugin_name']}' отклонено. Свяжитесь с администратором для уточнения."
        )
    except:
        pass
    
    await callback_query.answer("❌ Обновление отклонено")
    
    text = f"""❌ <b>Обновление отклонено</b>

<b>ID:</b> {update_id}
<b>Плагин:</b> {update_req['plugin_name']}
<b>Автор:</b> @{update_req['username']}
<b>Отклонил:</b> @{callback_query.from_user.username}"""
    
    try:
        await callback_query.message.edit_text(text=text)
    except:
        pass


@router.callback_query(F.data.startswith("back_to_sub_"))
async def back_to_submission(callback_query: types.CallbackQuery):
    submission_id = int(callback_query.data.replace("back_to_sub_", ""))
    sub = db.get_submission(submission_id)
    if sub:
        await _edit_or_send(callback_query, format_submission_message(sub), 
                           reply_markup=create_submission_review_menu(submission_id))
    await callback_query.answer()


@router.callback_query(F.data == "cancel_admin_broadcast")
async def cancel_admin_broadcast(callback_query: types.CallbackQuery):
    await callback_query.answer("Рассылка отменена")
    await callback_query.message.delete()


import user_functions
